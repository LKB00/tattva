export type SensitiveKind = "card" | "key" | "password" | "email" | "phone";

export interface SensitiveFinding {
  id: string;
  kind: SensitiveKind;
  /** Where it is in the text, so it can be taken out. */
  start: number;
  end: number;
  /** A safe preview, such as "•••• 4242". */
  preview: string;
}

// A real card number passes the Luhn check, so a long order number does not count. A phone number is 10 digits, or
// 10 to 13 written the way phone numbers are (a + or spaces), so an order number is not one either.
const luhn = (digits: string) => {
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = Number(digits[digits.length - 1 - i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return sum % 10 === 0;
};

const RULES: { kind: SensitiveKind; re: RegExp; ok?: (m: string) => boolean; preview: (m: string) => string }[] = [
  { kind: "card", re: /\b(?:\d[ -]?){13,19}\b/g, ok: (m) => luhn(m.replace(/\D/g, "")), preview: (m) => `•••• ${m.replace(/\D/g, "").slice(-4)}` },
  { kind: "key", re: /\b(?:sk|pk|rk|ghp|gho|xox[abp]|AKIA)[-_A-Za-z0-9]{12,}\b/g, preview: (m) => `${m.slice(0, 4)}••••` },
  { kind: "password", re: /\b(?:password|passcode|pwd)\s*(?:is|:|=)\s*\S+/gi, preview: () => "••••••" },
  { kind: "email", re: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g, preview: (m) => `${m[0]}•••@${m.split("@")[1]}` },
  { kind: "phone", re: /(?<!\d)\+?\d[\d ()-]{8,14}\d(?!\d)/g, ok: (m) => { const n = m.replace(/\D/g, "").length; return n >= 10 && n <= 13 && (n === 10 || /[+ ()-]/.test(m)); }, preview: (m) => `•••• ${m.replace(/\D/g, "").slice(-3)}` },
];

/**
 * Finds private details in a message before it is sent: card numbers (Luhn checked), API keys, passwords written
 * as "password: …", email addresses and phone numbers. It runs on the person's device; nothing is sent anywhere.
 * Overlapping matches keep the first, most specific kind (a card number is not also a phone number).
 */
export function findSensitive(text: string, kinds: SensitiveKind[] = ["card", "key", "password", "email", "phone"]): SensitiveFinding[] {
  const out: SensitiveFinding[] = [];
  for (const r of RULES) {
    if (!kinds.includes(r.kind)) continue;
    for (const m of text.matchAll(r.re)) {
      const raw = m[0].replace(/[ -]+$/, ""); // a match never ends in the space after a number
      const start = m.index ?? 0, end = start + raw.length;
      if (r.ok && !r.ok(raw)) continue;
      if (out.some((f) => start < f.end && end > f.start)) continue;
      out.push({ id: `${r.kind}-${start}`, kind: r.kind, start, end, preview: r.preview(raw) });
    }
  }
  return out.sort((a, b) => a.start - b.start);
}

/** The text with the given findings taken out. */
export function removeSensitive(text: string, findings: SensitiveFinding[]): string {
  let out = text;
  for (const f of [...findings].sort((a, b) => b.start - a.start)) out = out.slice(0, f.start) + out.slice(f.end);
  return out.replace(/[ \t]{2,}/g, " ").replace(/\s+([,.;:!?])/g, "$1").trim();
}
