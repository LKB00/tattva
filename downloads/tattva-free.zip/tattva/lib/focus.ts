import { useEffect, useRef, useState, type RefObject } from "react";

/**
 * Keeping keyboard focus and screen reader users in step when a part changes under them: a chip or card that removes
 * itself, buttons that are replaced by a result, options that arrive later. Parts use these so the app does not have to.
 */

const FOCUSABLE = 'button:not([disabled]), [href], input:not([disabled]):not([type="hidden"]), textarea:not([disabled]), select:not([disabled]), [contenteditable="true"], [tabindex]:not([tabindex="-1"])';
const TYPING = 'textarea:not([disabled]), input:not([disabled]):not([type]), input[type="text"]:not([disabled]), input[type="search"]:not([disabled]), [contenteditable="true"], [role="textbox"]';

const first = (root: Element | null, selector = FOCUSABLE) =>
  root instanceof HTMLElement ? (root.matches(selector) ? root : root.querySelector<HTMLElement>(selector)) : null;

/**
 * Where focus should go when `el` (a chip, a card, a row) is about to go away: the same kind of control in the next
 * item, else in the previous one, else the nearest place to type (the message box or the document), searching
 * outwards from `el`.
 */
export function focusTargetAfter(el: HTMLElement): HTMLElement | null {
  for (const sib of [el.nextElementSibling, el.previousElementSibling]) {
    const t = first(sib);
    if (t) return t;
  }
  for (let p = el.parentElement, i = 0; p && i < 8; p = p.parentElement, i++) {
    const t = [...p.querySelectorAll<HTMLElement>(TYPING)].find((x) => !el.contains(x));
    if (t) return t;
  }
  return null;
}

/** The nearest place to type outside `el`, such as the message box beside a starter gallery. */
export function nearestTyping(el: HTMLElement | null): HTMLElement | null {
  for (let p = el?.parentElement, i = 0; p && i < 8; p = p.parentElement, i++) {
    const t = [...p.querySelectorAll<HTMLElement>(TYPING)].find((x) => !el!.contains(x));
    if (t) return t;
  }
  return null;
}

const lost = () => { const a = document.activeElement; return !a || a === document.body || !a.isConnected; };

/**
 * Call from a handler that may make `el`, or the control just pressed, go away. Once the app has updated, if focus
 * fell to the page, it moves to `target()` when given, else to the first control left in `el`, else to
 * `focusTargetAfter(el)` worked out before anything changed. Focus that landed somewhere real is left alone.
 */
export function keepFocus(el: HTMLElement | null, target?: () => HTMLElement | null | undefined) {
  if (!el) return;
  const fallback = focusTargetAfter(el);
  requestAnimationFrame(() => {
    if (!lost()) return;
    const t = target?.() ?? (el.isConnected ? first(el) : null) ?? fallback;
    if (t?.isConnected) t.focus({ preventScroll: true });
  });
}

/**
 * When `key` changes (a status, the current version) and focus was last inside `root` but has fallen to the page
 * because the control it was on went away, move it to `target()`.
 */
export function useFocusReturn(key: unknown, root: RefObject<HTMLElement | null>, target: () => HTMLElement | null | undefined) {
  const inside = useRef(false);
  const pick = useRef(target);
  pick.current = target;
  useEffect(() => {
    // Focus moving anywhere in the document says whether it is inside the part. A control that is removed while
    // focused moves focus nowhere, so the last answer stands.
    const on = (e: FocusEvent) => { inside.current = !!root.current?.contains(e.target as Node); };
    document.addEventListener("focusin", on);
    return () => document.removeEventListener("focusin", on);
  }, [root]);
  useEffect(() => {
    if (!inside.current || !lost()) return;
    pick.current()?.focus({ preventScroll: true });
  }, [key]);
}

/**
 * A message for a polite live region that is set only when `value` changes after the first render, so nothing is
 * read out when the part appears. `say` returns the words, or "" to stay quiet.
 */
export function useAnnounceChange<T>(value: T, say: (now: T, before: T) => string): string {
  const before = useRef(value);
  const [message, setMessage] = useState("");
  useEffect(() => {
    if (Object.is(before.current, value)) return;
    const m = say(value, before.current);
    before.current = value;
    setMessage(m);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return message;
}
