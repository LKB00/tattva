# Tattva free kit

63 free parts, ready to copy into a React 19 + Tailwind CSS v4 project.

1. Copy this folder to `src/tattva`.
2. Add the tokens: `src/tokens/tokens.css`, imported once in your entry (`import "./tokens/tokens.css";`). Download: https://lkb00.github.io/tattva/downloads/tokens.css
3. Import from the folder: `import { Button, Message } from "./tattva";`

Parts: AIBadge, AIDisclosure, AIMark, AIPresence, AgentStatusIcon, ApprovedByMark, AttentionDot, Avatar, Badge, Button, Callout, Checkbox, CitationMarker, Cluster, CodeBlock, Collapsible, Combobox, Composer, Container, DataFreshness, DatePicker, Dialog, EditScopeChip, Field, FrameScrubber, GhostText, Grid, HeroHeading, IconButton, Illustration, KeyHint, Markdown, Message, MessageList, MeterBar, MicButton, Money, NumberField, Pictogram, Popover, Price, PriceChange, RadioGroup, Reveal, ScrollEdge, SectionLabel, SegmentedControl, Select, ShimmerText, Skeleton, Slider, Spinner, Stack, StatusLine, StatusTicker, Switch, Tabs, TextField, ThinkingBlock, Tooltip, TypingIndicator, Waveform, WorkingEdge.

Internal files used by free parts and not exported as parts: none.

Pro parts (approval prompts, source lists, templates and more) are not in this kit. They come with a Pro or Team plan: https://lkb00.github.io/tattva/#pricing

Docs for every part: https://lkb00.github.io/tattva/llms.txt
