import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface StatusLineProps {
  /** The pieces of the line, in order. A middle dot is drawn between them. */
  items: ReactNode[];
  /** Index of the item that is the current state. It keeps the normal ink and turns medium weight. The others are muted. */
  current?: number;
  /** Accessible name of the group. */
  label?: string;
  className?: string;
}

/** One quiet line for the top of a screen, such as "Case · Flipkart · ₹2,340 · Waiting". It truncates instead of wrapping. */
export function StatusLine({ items, current, label = "Status", className }: StatusLineProps) {
  return (
    <div role="group" aria-label={label} className={cn("min-w-0 truncate text-body leading-6 text-fg", className)}>
      <span className="sr-only">Status: </span>
      {items.map((item, i) => (
        <span key={i}>
          {i > 0 && <span aria-hidden className="mx-1.5 text-fg-subtle">{"·"}</span>}
          <span aria-current={i === current ? "true" : undefined} className={current === undefined ? undefined : i === current ? "font-medium text-fg" : "text-fg-muted"}>{item}</span>
        </span>
      ))}
    </div>
  );
}
