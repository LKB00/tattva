import { useEffect, useRef, useState } from "react";
import { cn } from "../lib/cn";

export interface PriceProps {
  value: number;
  /** ISO 4217 code. */
  currency?: string;
  locale?: string;
  decimals?: number;
  /** A small arrow before the number. It shows the direction of the last change and stays until the next change. */
  showDirection?: boolean;
  /** Tints the background briefly when the value changes. Only with motion allowed. */
  flash?: boolean;
  /** Announces the new value in a hidden polite live region, at most once every 5 seconds. */
  announce?: boolean;
  /** Accessible name, such as "Reliance price". Read before the number. */
  label?: string;
  className?: string;
}

type Dir = "up" | "down" | null;

const FLASH_MS = 600;
const ANNOUNCE_MS = 5000;

/** Formats a price. Falls back to a plain number when the currency or locale is not valid. */
export function formatPrice(value: number, currency: string, locale: string, decimals: number): string {
  if (!Number.isFinite(value)) return "—";
  try {
    return new Intl.NumberFormat(locale, { style: "currency", currency, minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(value);
  } catch {
    return `${value.toFixed(decimals)} ${currency}`;
  }
}

/** A live number. It tints briefly and shows an arrow for the last change. The arrow is the cue, the tint is extra. */
export function Price({ value, currency = "INR", locale = "en-IN", decimals = 2, showDirection = true, flash = true, announce = false, label, className }: PriceProps) {
  const [prev, setPrev] = useState(value);
  const [dir, setDir] = useState<Dir>(null);
  const [flashing, setFlashing] = useState(false);
  const [tick, setTick] = useState(0);

  // Compare during render so the first paint of a new value already carries its direction.
  if (value !== prev) {
    setPrev(value);
    if (Number.isFinite(value) && Number.isFinite(prev) && value !== prev) {
      setDir(value > prev ? "up" : "down");
      setFlashing(true);
      setTick((t) => t + 1);
    }
  }

  useEffect(() => {
    if (!tick) return;
    const t = setTimeout(() => setFlashing(false), FLASH_MS);
    return () => clearTimeout(t);
  }, [tick]);

  const text = formatPrice(value, currency, locale, decimals);

  const [spoken, setSpoken] = useState("");
  const lastSpoken = useRef(0);
  useEffect(() => {
    if (!announce || !tick) return;
    const wait = Math.max(0, lastSpoken.current + ANNOUNCE_MS - Date.now());
    const t = setTimeout(() => { lastSpoken.current = Date.now(); setSpoken(text); }, wait);
    return () => clearTimeout(t);
  }, [announce, tick, text]);

  const arrow = showDirection && dir;
  return (
    <span className={cn(
      "inline-flex items-baseline gap-1 rounded-sm whitespace-nowrap font-mono tabular-nums transition-colors duration-[var(--dur-slow)]",
      flash && flashing && dir === "up" && "motion-safe:bg-up-soft",
      flash && flashing && dir === "down" && "motion-safe:bg-down-soft",
      className,
    )}>
      {label && <span className="sr-only">{label}: </span>}
      {arrow && (
        <svg aria-hidden viewBox="0 0 10 10" className={cn("size-[0.6em] shrink-0 self-center", arrow === "up" ? "text-up-fg" : "text-down-fg")} fill="currentColor">
          {arrow === "up" ? <path d="M5 1l4 7H1z" /> : <path d="M5 9L1 2h8z" />}
        </svg>
      )}
      {arrow && <span className="sr-only">{arrow === "up" ? "Up " : "Down "}</span>}
      <span>{text}</span>
      {announce && <span aria-live="polite" aria-atomic="true" className="sr-only">{spoken}</span>}
    </span>
  );
}
