import { cn } from "../lib/cn";

export interface PriceChangeProps {
  /** The change as an absolute amount, such as 32.5. The sign sets the direction. */
  change: number;
  /** The change as a percent, such as 1.14. */
  percent?: number;
  currency?: string;
  locale?: string;
  decimals?: number;
  /** What to show: the amount and the percent, only the percent, or only the amount. */
  format?: "both" | "percent" | "amount";
  /** Shown instead of the numbers when both are zero. */
  flatLabel?: string;
  className?: string;
}

type Dir = "up" | "down" | "flat";

function direction(change: number, percent?: number): Dir {
  const n = change !== 0 && Number.isFinite(change) ? change : percent ?? 0;
  return n > 0 ? "up" : n < 0 ? "down" : "flat";
}

function num(abs: number, locale: string, decimals: number, style: "currency" | "percent" | "decimal", currency: string): string {
  try {
    if (style === "percent") return `${new Intl.NumberFormat(locale, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(abs)}%`;
    return new Intl.NumberFormat(locale, { style: "currency", currency, minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(abs);
  } catch {
    return abs.toFixed(decimals);
  }
}

/** A signed change with an arrow. Direction is shown by the arrow and the sign, never by colour alone. */
export function PriceChange({ change, percent, currency = "INR", locale = "en-IN", decimals = 2, format = "both", flatLabel, className }: PriceChangeProps) {
  const amountOk = Number.isFinite(change);
  const percentOk = percent !== undefined && Number.isFinite(percent);
  const wantAmount = format !== "percent";
  const wantPercent = format !== "amount";
  const usable = (wantAmount && amountOk) || (wantPercent && percentOk);
  if (!usable) return <span className={cn("font-mono tabular-nums whitespace-nowrap", className)}>{"—"}</span>;

  const dir = direction(amountOk ? change : 0, percentOk ? percent : undefined);
  const sign = dir === "up" ? "+" : dir === "down" ? "−" : "";
  const parts: string[] = [];
  if (wantAmount && amountOk) parts.push(`${sign}${num(Math.abs(change), locale, decimals, "currency", currency)}`);
  if (wantPercent && percentOk) parts.push(`${sign}${num(Math.abs(percent), locale, decimals, "percent", currency)}`);
  const text = parts.length === 2 ? `${parts[0]} (${parts[1]})` : parts[0];
  const showFlat = dir === "flat" && flatLabel;

  return (
    <span className={cn("inline-flex items-center gap-1 whitespace-nowrap font-mono tabular-nums", dir === "up" && "text-up-fg", dir === "down" && "text-down-fg", dir === "flat" && "text-fg-muted", className)}>
      <span className="sr-only">{dir === "up" ? "Up " : dir === "down" ? "Down " : "Unchanged "}</span>
      <svg aria-hidden viewBox="0 0 10 10" className="size-[0.6em] shrink-0" fill={dir === "flat" ? "none" : "currentColor"} stroke={dir === "flat" ? "currentColor" : "none"} strokeWidth={1.5} strokeLinecap="round">
        {dir === "up" && <path d="M5 1l4 7H1z" />}
        {dir === "down" && <path d="M5 9L1 2h8z" />}
        {dir === "flat" && <path d="M1.5 5h7" />}
      </svg>
      <span>{showFlat ? flatLabel : text}</span>
    </span>
  );
}
