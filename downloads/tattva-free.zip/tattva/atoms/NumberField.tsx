import { useState } from "react";
import type { KeyboardEvent } from "react";
import { cn } from "../lib/cn";
import { PlusIcon } from "../lib/icons";

export interface NumberFieldProps {
  value: number | null;
  onChange: (value: number | null) => void;
  /** Accessible name. The buttons are named from it too. */
  label: string;
  min?: number;
  max?: number;
  /** Amount for the buttons and Arrow keys. */
  step?: number;
  /** Decimals shown and kept. Defaults to the decimals in step. */
  precision?: number;
  /** Text after the number, such as "lots". */
  unit?: string;
  invalid?: boolean;
  disabled?: boolean;
  /** md is 40px tall, sm is 32px. Both are 44px on coarse pointers. */
  size?: "sm" | "md";
  id?: string;
  "aria-describedby"?: string;
  /** Also marks the field invalid. Field passes this when it has an error. */
  "aria-invalid"?: boolean;
  required?: boolean;
  className?: string;
}

const decimals = (n: number) => (String(n).split(".")[1] ?? "").length;

/** A number input with minus and plus buttons. Typing is free; the value is checked on blur and Enter. */
export function NumberField({ value, onChange, label, min, max, step = 1, precision, unit, invalid, disabled, size = "md", id, required, className, "aria-invalid": ariaInvalid, ...rest }: NumberFieldProps) {
  const bad = invalid || ariaInvalid;
  const places = precision ?? decimals(step);
  const [draft, setDraft] = useState<string | null>(null);
  const clamp = (n: number) => Number(Math.min(max ?? Infinity, Math.max(min ?? -Infinity, n)).toFixed(places));
  const parse = (t: string): number | null | undefined => {
    const s = t.trim().replace(/,/g, "");
    if (s === "") return null;
    const n = Number(s);
    return Number.isFinite(n) ? clamp(n) : undefined; // undefined: not a number, keep the old value
  };
  const commit = () => {
    if (draft === null) return;
    const next = parse(draft);
    setDraft(null);
    if (next !== undefined && next !== value) onChange(next);
  };
  const current = draft !== null ? (parse(draft) ?? value) : value;
  const move = (dir: 1 | -1, mult = 1) => {
    setDraft(null);
    const next = current == null ? clamp(min ?? 0) : clamp(current + dir * step * mult);
    if (next !== value) onChange(next);
  };
  const jump = (n: number) => { setDraft(null); if (n !== value) onChange(clamp(n)); };
  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    const big = e.shiftKey ? 10 : 1;
    if (e.key === "ArrowUp") move(1, big);
    else if (e.key === "ArrowDown") move(-1, big);
    else if (e.key === "PageUp") move(1, 10);
    else if (e.key === "PageDown") move(-1, 10);
    else if (e.key === "Home" && min !== undefined) jump(min);
    else if (e.key === "End" && max !== undefined) jump(max);
    else if (e.key === "Enter") commit();
    else return;
    if (e.key !== "Enter") e.preventDefault();
  };
  const shown = draft ?? (value === null ? "" : value.toFixed(places));
  const atMin = current != null && min !== undefined && current <= min;
  const atMax = current != null && max !== undefined && current >= max;
  const btn = cn(
    "flex shrink-0 cursor-pointer items-center justify-center self-stretch rounded-lg px-2 text-fg-muted transition-colors duration-[var(--dur-fast)] hover:bg-hover hover:text-fg",
    "disabled:cursor-not-allowed disabled:text-disabled-fg disabled:hover:bg-transparent pointer-coarse:min-w-11",
  );
  return (
    <span className={cn(
      "inline-flex items-center gap-1 rounded-field border px-1 text-body leading-5 text-fg transition-colors duration-[var(--dur-fast)]",
      size === "sm" ? "min-h-8" : "min-h-10", "pointer-coarse:min-h-11",
      "has-[input:focus-visible]:outline-(length:--focus-width) has-[input:focus-visible]:outline-solid has-[input:focus-visible]:outline-offset-2 has-[input:focus-visible]:outline-[color:var(--focus-ring)]",
      bad ? "border-danger" : "border-line hover:border-line-strong",
      disabled ? "cursor-not-allowed border-disabled-line bg-disabled text-disabled-fg [&_input]:text-disabled-fg" : "bg-surface",
      className,
    )}>
      <button type="button" tabIndex={-1} aria-label={`Decrease ${label}`} disabled={disabled || atMin} onClick={() => move(-1)} className={btn}>
        <svg aria-hidden viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round"><path d="M5 12h14" /></svg>
      </button>
      <input {...rest} id={id} type="text" inputMode={min !== undefined && min >= 0 ? "decimal" : "text"} role="spinbutton" autoComplete="off" aria-label={label}
        aria-valuenow={current ?? undefined} aria-valuemin={min} aria-valuemax={max}
        aria-valuetext={current == null ? undefined : `${current.toFixed(places)}${unit ? ` ${unit}` : ""}`}
        aria-invalid={bad || undefined} required={required} disabled={disabled} value={shown}
        onChange={(e) => setDraft(e.target.value)} onBlur={commit} onKeyDown={onKeyDown}
        className="w-16 min-w-0 flex-1 bg-transparent py-1 text-center tabular-nums outline-none focus-visible:outline-none disabled:cursor-not-allowed" />
      {unit && <span className="shrink-0 text-fg-muted">{unit}</span>}
      <button type="button" tabIndex={-1} aria-label={`Increase ${label}`} disabled={disabled || atMax} onClick={() => move(1)} className={btn}>
        <PlusIcon />
      </button>
    </span>
  );
}
