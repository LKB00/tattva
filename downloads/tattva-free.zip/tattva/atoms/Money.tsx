import { useId } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface MoneyProps {
  value: number;
  /** ISO 4217 code. */
  currency?: string;
  locale?: string;
  /** Short form. INR uses lakh and crore (1.2 L, 3.4 Cr). Other currencies use K, M and so on. */
  compact?: boolean;
  /** Prefix + for a positive number. A negative number always shows the true minus sign. */
  showSign?: boolean;
  /** Adds an arrow and the up or down colour for a number that is not zero. The sign is always shown with it. */
  direction?: boolean;
  /** Marks the number as worked out by code. Pass a string to replace the default screen reader phrase. */
  calculated?: boolean | string;
  className?: string;
}

const MONO = "font-mono tabular-nums";

export interface MonoProps {
  children: ReactNode;
  className?: string;
}

/** Mono text with tabular figures, for a date or id that code worked out. */
export function Mono({ children, className }: MonoProps) {
  return <span className={cn(MONO, className)}>{children}</span>;
}

function format(value: number, currency: string, locale: string, compact: boolean): string {
  const abs = Math.abs(value);
  const full = new Intl.NumberFormat(locale, { style: "currency", currency, minimumFractionDigits: Number.isInteger(abs) ? 0 : 2, maximumFractionDigits: 2 });
  if (!compact) return full.format(abs);
  if (currency === "INR") {
    const symbol = full.formatToParts(0).find((p) => p.type === "currency")?.value ?? "₹";
    const one = new Intl.NumberFormat(locale, { maximumFractionDigits: 1 });
    if (abs >= 1e7) return `${symbol}${one.format(abs / 1e7)} Cr`;
    if (abs >= 1e5) return `${symbol}${one.format(abs / 1e5)} L`;
    return full.format(abs);
  }
  return new Intl.NumberFormat(locale, { style: "currency", currency, notation: "compact", maximumFractionDigits: 1 }).format(abs);
}

/** An amount that code calculated, in mono with tabular figures, so it reads as worked out and not guessed. */
export function Money({ value, currency = "INR", locale = "en-IN", compact = false, showSign = false, direction = false, calculated, className }: MoneyProps) {
  const noteId = useId();
  if (!Number.isFinite(value)) return <span className={cn(MONO, className)}>{"—"}</span>;
  const dir = direction && value !== 0 ? (value > 0 ? "up" : "down") : null;
  const sign = value < 0 ? "−" : (showSign || dir) && value > 0 ? "+" : "";
  let text: string;
  try { text = format(value, currency, locale, compact); } catch { text = `${Math.abs(value)} ${currency}`; }
  const note = calculated ? (typeof calculated === "string" ? calculated : "Calculated by code") : null;
  return (
    <span aria-describedby={note ? noteId : undefined}
      className={cn(MONO, dir === "up" && "text-up-fg", dir === "down" && "text-down-fg", note && "underline decoration-fg-subtle decoration-dotted underline-offset-4", className)}>
      {dir && <span className="sr-only">{dir === "up" ? "Up " : "Down "}</span>}
      {dir && <span aria-hidden className="mr-1 inline-block text-[0.7em] align-[0.1em]">{dir === "up" ? "▲" : "▼"}</span>}
      {sign}{text}
      {note && <span id={noteId} className="sr-only">. {note}</span>}
    </span>
  );
}
