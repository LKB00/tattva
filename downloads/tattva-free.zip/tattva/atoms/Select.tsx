import type { ComponentProps } from "react";
import { cn } from "../lib/cn";

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps extends Omit<ComponentProps<"select">, "size"> {
  /** The choices. Use this or pass <option> elements as children. */
  options?: SelectOption[];
  /** Shown while value is empty. It is a disabled first option, so it cannot be picked again. */
  placeholder?: string;
  invalid?: boolean;
  /** md is 40px tall, sm is 32px. Both are 44px on coarse pointers. */
  size?: "sm" | "md";
  /** Classes for the wrapper around the select. */
  className?: string;
}

/** A native select with a drawn chevron. The menu stays the browser's own, so it works with every screen reader and phone. */
export function Select({ options, placeholder, invalid, size = "md", className, children, value, defaultValue, ...rest }: SelectProps) {
  const empty = value === "" || (value === undefined && (defaultValue === undefined || defaultValue === ""));
  return (
    <span className={cn("relative block w-full", className)}>
      <select {...rest} value={value} defaultValue={value === undefined ? (defaultValue ?? (placeholder ? "" : undefined)) : undefined}
        aria-invalid={invalid || rest["aria-invalid"] || undefined}
        className={cn(
          "w-full appearance-none rounded-field border bg-surface pr-9 pl-3 text-body leading-5 transition-colors duration-[var(--dur-fast)] cursor-pointer",
          size === "sm" ? "h-8" : "h-10", "pointer-coarse:h-11",
          empty && placeholder ? "text-fg-subtle" : "text-fg",
          invalid || rest["aria-invalid"] ? "border-danger" : "border-line hover:border-line-strong",
          "disabled:cursor-not-allowed disabled:border-disabled-line disabled:bg-disabled disabled:text-disabled-fg",
        )}>
        {placeholder && <option value="" disabled hidden>{placeholder}</option>}
        {options?.map((o) => <option key={o.value} value={o.value} disabled={o.disabled} className="text-fg">{o.label}</option>)}
        {children}
      </select>
      <svg aria-hidden viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round"
        className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-fg-muted"><path d="M6 9l6 6 6-6" /></svg>
    </span>
  );
}
