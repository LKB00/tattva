import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { cn } from "../lib/cn";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { ShimmerText } from "./ShimmerText";

export interface StatusTickerProps {
  /** The step the AI run is on right now, such as "Reading 3 files". The app passes the real step; when done, pass the final line, such as "Done in 12s". */
  current: string;
  /** Every step text the run may show. Used only to reserve the width of the widest one, so the box never grows. */
  steps?: string[];
  /** The run has finished. The line stops shimmering, aria-busy is removed and the line is announced at once. */
  done?: boolean;
  /** Accessible name of the line, such as "Assistant status". */
  label?: string;
  /** A text whose width the box keeps from the start, such as the longest step you expect. */
  reserve?: string;
  className?: string;
}

/** Screen readers hear a new step at most this often. The latest step wins. */
const ANNOUNCE_GAP = 2000;

/** One line that shows the real current step of an AI run. It keeps the width of the widest text it has shown, so nothing beside it moves. */
export function StatusTicker({ current, steps, done = false, label = "AI status", reserve, className }: StatusTickerProps) {
  const reduced = useReducedMotion();
  const [prev, setPrev] = useState<{ text: string; key: number } | null>(null);
  const [shown, setShown] = useState({ text: current, key: 0 });
  const [minWidth, setMinWidth] = useState(0);
  const [spoken, setSpoken] = useState(current);
  const textRef = useRef<HTMLSpanElement>(null);
  const lastSpoke = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  // Swap the line during render so the old text and the new one are drawn in the same frame.
  if (current !== shown.text) {
    setPrev(reduced ? null : { text: shown.text, key: shown.key });
    setShown({ text: current, key: shown.key + 1 });
  }

  // Remember the widest text shown so far; the box never shrinks below it.
  useLayoutEffect(() => {
    const w = textRef.current?.getBoundingClientRect().width ?? 0;
    setMinWidth((m) => (w > m ? w : m));
  }, [shown.key]);

  // Throttle the live region: speak at once if the last announcement was long enough ago, else speak the latest step when the gap ends.
  useEffect(() => {
    clearTimeout(timer.current);
    const speak = () => { lastSpoke.current = Date.now(); setSpoken(current); };
    const wait = ANNOUNCE_GAP - (Date.now() - lastSpoke.current);
    if (done || wait <= 0) speak();
    else timer.current = setTimeout(speak, wait);
    return () => clearTimeout(timer.current);
  }, [current, done]);

  const ghosts = [reserve, ...(steps ?? [])].filter((s): s is string => !!s);
  const working = !done && !reduced;

  return (
    <span className={cn("inline-flex max-w-full min-w-0 align-middle", className)}>
      <span role="group" aria-label={label} aria-busy={!done} style={{ minWidth: `min(${minWidth}px, 100%)` }} className="relative inline-grid min-w-0 max-w-full text-body leading-6 text-fg-muted">
        {ghosts.map((g, i) => (
          <span key={i} aria-hidden className="invisible col-start-1 row-start-1 truncate">{g}</span>
        ))}
        {prev && (
          <span key={`p${prev.key}`} aria-hidden onAnimationEnd={() => setPrev(null)}
            className="pointer-events-none absolute inset-0 truncate animate-fade-out">{prev.text}</span>
        )}
        <span key={shown.key} ref={textRef} className={cn("col-start-1 row-start-1 w-fit max-w-full truncate", !reduced && shown.key > 0 && "animate-blur-in", done && "text-fg")}>
          {working ? <ShimmerText className="leading-6">{shown.text}</ShimmerText> : shown.text}
        </span>
      </span>
      <span role="status" aria-live="polite" className="sr-only">{spoken}</span>
    </span>
  );
}
