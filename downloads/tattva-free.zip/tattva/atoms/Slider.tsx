import { useId } from "react";
import type { CSSProperties } from "react";
import { cn } from "../lib/cn";

export interface SliderProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  /** Accessible name. */
  label: string;
  /** Shows the current value as text to the right. */
  showValue?: boolean;
  /** Turns the number into text, for example "40%". Used for the visible value and for aria-valuetext. */
  formatValue?: (value: number) => string;
  disabled?: boolean;
  id?: string;
  className?: string;
}

// Class strings are written out in full so Tailwind can see them. Both engines get the same drawing:
// the track paints the filled part up to --fill, and the thumb is a 20px ring.
const webkit = "[&::-webkit-slider-runnable-track]:h-1.5 [&::-webkit-slider-runnable-track]:rounded-full [&::-webkit-slider-runnable-track]:border-0 [&::-webkit-slider-runnable-track]:bg-[linear-gradient(to_right,var(--color-accent)_var(--fill),var(--color-line-strong)_var(--fill))] [&::-webkit-slider-runnable-track]:forced-colors:bg-none [&::-webkit-slider-runnable-track]:forced-colors:bg-[ButtonText] [&::-webkit-slider-thumb]:-mt-1.75 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:size-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-accent [&::-webkit-slider-thumb]:bg-surface [&::-webkit-slider-thumb]:shadow-sm [&::-webkit-slider-thumb]:forced-colors:border-[ButtonText] [&::-webkit-slider-thumb]:forced-colors:bg-[Canvas]";
const moz = "[&::-moz-range-track]:h-1.5 [&::-moz-range-track]:rounded-full [&::-moz-range-track]:border-0 [&::-moz-range-track]:bg-[linear-gradient(to_right,var(--color-accent)_var(--fill),var(--color-line-strong)_var(--fill))] [&::-moz-range-track]:forced-colors:bg-none [&::-moz-range-track]:forced-colors:bg-[ButtonText] [&::-moz-range-thumb]:size-5 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-accent [&::-moz-range-thumb]:bg-surface [&::-moz-range-thumb]:shadow-sm [&::-moz-range-thumb]:forced-colors:border-[ButtonText] [&::-moz-range-thumb]:forced-colors:bg-[Canvas]";

/** Controlled single-thumb slider on a native range input. Arrow keys, Home, End and Page keys come from the browser. */
export function Slider({ value, onChange, min = 0, max = 100, step = 1, label, showValue, formatValue, disabled, id, className }: SliderProps) {
  const auto = useId();
  const inputId = id ?? auto;
  const text = formatValue ? formatValue(value) : String(value);
  const fill = max > min ? Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100)) : 0;
  return (
    <div className={cn("flex items-center gap-3", disabled && "opacity-(--disabled-opacity)", className)}>
      <input id={inputId} type="range" min={min} max={max} step={step} value={value} disabled={disabled}
        aria-label={label} aria-valuetext={formatValue ? text : undefined}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ "--fill": `${fill}%` } as CSSProperties}
        className={cn("m-0 h-5 min-w-0 flex-1 cursor-pointer appearance-none bg-transparent pointer-coarse:h-11 disabled:cursor-not-allowed",
          webkit, moz)} />
      {showValue && <output htmlFor={inputId} className="min-w-[3ch] text-right text-body leading-5 text-fg-muted tabular-nums">{text}</output>}
    </div>
  );
}
