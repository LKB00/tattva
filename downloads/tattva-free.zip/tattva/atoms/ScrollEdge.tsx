import type { CSSProperties, ReactNode } from "react";
import { cn } from "../lib/cn";

export interface ScrollEdgeProps {
  /** Which edge softens. */
  edge?: "top" | "bottom" | "both";
  /** Height of the fade zone, in px. */
  size?: number;
  /** The content that scrolls. */
  children?: ReactNode;
  /** Accessible name of the scrolling region. */
  label?: string;
  /** Classes for the outer box. Give it a height, or place it in a flex or grid cell that has one. */
  className?: string;
  /** Classes for the element that scrolls. */
  contentClassName?: string;
}

// Stops run from 0% (the content side) to 100% (the screen edge) because --se-dir points towards the edge.
// Each blur layer owns an overlapping slice, so the strength ramps up instead of showing as a band.
// Blur doubles: 0.75, 1.5, 3, 6, 12px.
const LAYERS = [
  "[backdrop-filter:blur(0.75px)] [-webkit-backdrop-filter:blur(0.75px)] [mask-image:linear-gradient(var(--se-dir),transparent_0%,black_20%,black_40%,transparent_60%)] [-webkit-mask-image:linear-gradient(var(--se-dir),transparent_0%,black_20%,black_40%,transparent_60%)]",
  "[backdrop-filter:blur(1.5px)] [-webkit-backdrop-filter:blur(1.5px)] [mask-image:linear-gradient(var(--se-dir),transparent_20%,black_40%,black_60%,transparent_80%)] [-webkit-mask-image:linear-gradient(var(--se-dir),transparent_20%,black_40%,black_60%,transparent_80%)]",
  "[backdrop-filter:blur(3px)] [-webkit-backdrop-filter:blur(3px)] [mask-image:linear-gradient(var(--se-dir),transparent_40%,black_60%,black_80%,transparent_100%)] [-webkit-mask-image:linear-gradient(var(--se-dir),transparent_40%,black_60%,black_80%,transparent_100%)]",
  "[backdrop-filter:blur(6px)] [-webkit-backdrop-filter:blur(6px)] [mask-image:linear-gradient(var(--se-dir),transparent_60%,black_80%,black_100%)] [-webkit-mask-image:linear-gradient(var(--se-dir),transparent_60%,black_80%,black_100%)]",
  "[backdrop-filter:blur(12px)] [-webkit-backdrop-filter:blur(12px)] [mask-image:linear-gradient(var(--se-dir),transparent_80%,black_100%)] [-webkit-mask-image:linear-gradient(var(--se-dir),transparent_80%,black_100%)]",
];

const TINT = "[background-image:linear-gradient(var(--se-dir),transparent_0%,color-mix(in_srgb,var(--bg)_35%,transparent)_55%,color-mix(in_srgb,var(--bg)_90%,transparent)_100%)]";
const SOLID = "[background-image:linear-gradient(var(--se-dir),transparent_0%,var(--bg)_100%)]";

function Edge({ side, size }: { side: "top" | "bottom"; size: number }) {
  const style = { height: size, "--se-dir": side === "top" ? "to top" : "to bottom" } as CSSProperties;
  return (
    <div aria-hidden style={style} className={cn("pointer-events-none absolute inset-x-0", side === "top" ? "top-0" : "bottom-0")}>
      {/* Plain gradient: where backdrop-filter is missing. */}
      <div className={cn("absolute inset-0 supports-[backdrop-filter]:hidden", SOLID)} />
      {/* Plain gradient: when the person asked for less transparency. */}
      <div className={cn("absolute inset-0 hidden [@media(prefers-reduced-transparency:reduce)]:block", SOLID)} />
      <div className="absolute inset-0 hidden supports-[backdrop-filter]:block">
        <div className="absolute inset-0 [@media(prefers-reduced-transparency:reduce)]:hidden">
          {LAYERS.map((l, i) => <div key={i} className={cn("pointer-events-none absolute inset-0", l)} />)}
          <div className={cn("absolute inset-0", TINT)} />
        </div>
      </div>
    </div>
  );
}

/**
 * A scrolling area whose top and/or bottom edge softens progressively, so content passing under it fades out
 * instead of meeting a hard panel line. The edge layers are decorative, ignore the pointer and never take focus.
 * The scroller is a focusable region, so keyboard people can scroll it with the arrow keys.
 */
export function ScrollEdge({ edge = "both", size = 48, children, label = "Scrollable content", className, contentClassName }: ScrollEdgeProps) {
  return (
    <div className={cn("relative min-h-0 overflow-hidden", className)}>
      <div role="region" aria-label={label} tabIndex={0}
        className={cn("h-full overflow-y-auto overscroll-contain focus-visible:[outline-offset:-2px]", contentClassName)}>
        {children}
      </div>
      {(edge === "top" || edge === "both") && <Edge side="top" size={size} />}
      {(edge === "bottom" || edge === "both") && <Edge side="bottom" size={size} />}
    </div>
  );
}
