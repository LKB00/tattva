import { cloneElement, useEffect, useId, useRef, useState, type ReactElement } from "react";
import { cn } from "../lib/cn";

export interface TooltipProps {
  /** Plain text only. Never put essential information or anything clickable here. */
  content: string;
  /** The trigger. It must be focusable (a button or a link) and accept aria-describedby. */
  children: ReactElement<{ "aria-describedby"?: string }>;
  side?: "top" | "bottom" | "left" | "right";
  /** Milliseconds to wait before a hover shows it. Focus shows it at once. */
  delay?: number;
  className?: string;
}

const place = {
  top: "bottom-full left-1/2 -translate-x-1/2 pb-1.5",
  bottom: "top-full left-1/2 -translate-x-1/2 pt-1.5",
  left: "right-full top-1/2 -translate-y-1/2 pr-1.5",
  right: "left-full top-1/2 -translate-y-1/2 pl-1.5",
};

/** A short text label for a control, shown on hover and on keyboard focus. Touch users never see it from a tap. */
export function Tooltip({ content, children, side = "top", delay = 400, className }: TooltipProps) {
  const id = useId();
  const [open, setOpen] = useState(false);
  const timer = useRef<number | undefined>(undefined);
  const clear = () => window.clearTimeout(timer.current);
  useEffect(() => clear, []);

  useEffect(() => {
    if (!open) return;
    // Escape closes the tooltip and leaves focus where it is. While focus is inside, the wrapper below also stops the key
    // so it does not close a dialog or page around the tooltip; this listener covers a tooltip opened by hover.
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  const enter = () => {
    // Touch emulates mouseenter on tap; coarse pointers must not depend on hover.
    if (window.matchMedia("(pointer: coarse)").matches) return;
    clear();
    timer.current = window.setTimeout(() => setOpen(true), delay);
  };
  const hide = () => { clear(); setOpen(false); };
  const existing = children.props["aria-describedby"];

  return (
    <span className="relative inline-flex" onMouseEnter={enter} onMouseLeave={hide} onFocus={() => { clear(); setOpen(true); }} onBlur={hide}
      onKeyDown={(e) => { if (e.key === "Escape" && open) { e.stopPropagation(); setOpen(false); } }}>
      {cloneElement(children, { "aria-describedby": existing ? `${existing} ${id}` : id })}
      {/* The outer span carries transparent padding as the gap, so the pointer can move onto the tip without it closing. */}
      <span hidden={!open} className={cn("absolute z-40", place[side])}>
        <span id={id} role="tooltip"
          className={cn("block w-max max-w-64 rounded-md bg-inverse px-2 py-1 text-small leading-4 text-inverse-fg shadow-md motion-safe:animate-fade forced-colors:border forced-colors:border-[CanvasText]", className)}>
          {content}
        </span>
      </span>
    </span>
  );
}
