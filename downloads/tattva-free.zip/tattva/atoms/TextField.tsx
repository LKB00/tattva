import type { ComponentProps, ReactNode } from "react";
import { cn } from "../lib/cn";

export interface TextFieldProps extends Omit<ComponentProps<"input">, "size" | "type"> {
  type?: "text" | "email" | "password" | "search" | "url" | "tel";
  /** Marks the field as invalid: danger border and aria-invalid. Say what is wrong in text too (see Field). */
  invalid?: boolean;
  /** Content before the text, such as an icon. Decorative: it is not read out. */
  leading?: ReactNode;
  /** Content after the text, such as a unit like "₹". */
  trailing?: ReactNode;
  /** md is 40px tall, sm is 32px. Both are 44px on coarse pointers. */
  size?: "sm" | "md";
  /** Classes for the outer box, so width and margins apply to it. */
  className?: string;
}

/**
 * A single-line text input in a bordered box. The focus ring is drawn on the box (not the bare input) so it wraps the
 * icon and unit slots too. It uses the global focus colour and shows for keyboard focus only.
 */
export function TextField({ type = "text", invalid, leading, trailing, size = "md", className, disabled, readOnly, ...rest }: TextFieldProps) {
  return (
    <span className={cn(
      "flex w-full items-center gap-2 rounded-field border px-3 text-body leading-5 text-fg transition-colors duration-[var(--dur-fast)]",
      size === "sm" ? "min-h-8" : "min-h-10", "pointer-coarse:min-h-11",
      "has-[input:focus-visible]:outline-(length:--focus-width) has-[input:focus-visible]:outline-solid has-[input:focus-visible]:outline-offset-2 has-[input:focus-visible]:outline-[color:var(--focus-ring)]",
      invalid || rest["aria-invalid"] ? "border-danger" : "border-line hover:border-line-strong",
      disabled ? "cursor-not-allowed border-disabled-line bg-disabled text-disabled-fg [&_input]:text-disabled-fg" : readOnly ? "bg-sunken" : "bg-surface",
      className,
    )}>
      {leading && <span aria-hidden className="flex shrink-0 text-fg-muted">{leading}</span>}
      <input {...rest} type={type} disabled={disabled} readOnly={readOnly} aria-invalid={invalid || rest["aria-invalid"] || undefined}
        className="min-w-0 flex-1 bg-transparent py-1 text-fg outline-none placeholder:text-fg-subtle focus-visible:outline-none disabled:cursor-not-allowed" />
      {trailing && <span className="flex shrink-0 text-fg-muted">{trailing}</span>}
    </span>
  );
}
