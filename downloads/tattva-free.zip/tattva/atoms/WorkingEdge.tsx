import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "../lib/cn";

export type WorkingEdgeRadius = "card" | "overlay" | "control" | "field" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "4xl" | "full";

export interface WorkingEdgeProps extends Omit<HTMLAttributes<HTMLDivElement>, "children"> {
  /** True only while the AI is really working on this surface. The ring shows while true. */
  active: boolean;
  /** The surface the ring goes around, such as a card or a field. */
  children: ReactNode;
  /** Said once by screen readers when active turns true. */
  label?: string;
  /** Set false when the caller announces the change itself, and the surface must not hold a status region (such as a listbox option). */
  announce?: boolean;
  /** Corner radius. Match the corner of the surface inside. "card" (the default) follows the shape setting like every card. */
  radius?: WorkingEdgeRadius;
  className?: string;
}

const RADIUS: Record<WorkingEdgeRadius, string> = {
  card: "rounded-card", overlay: "rounded-overlay", control: "rounded-control", field: "rounded-field",
  sm: "rounded-sm", md: "rounded-md", lg: "rounded-lg", xl: "rounded-xl", "2xl": "rounded-2xl", "3xl": "rounded-3xl", "4xl": "rounded-4xl", full: "rounded-full",
};

// The turning highlight needs a registered angle, which a class cannot declare. React hoists and dedupes this sheet by href.
// One slow turn is decorative and loops only while real work runs. Reduced motion gets a still ring; forced colours a plain border.
const CSS = `
@property --sd-edge-angle { syntax: "<angle>"; inherits: false; initial-value: 0deg; }
@keyframes sd-edge-turn { to { --sd-edge-angle: 360deg; } }
.sd-edge-ring {
  position: absolute; inset: 0; border-radius: inherit; pointer-events: none; padding: var(--focus-width);
  background: conic-gradient(from var(--sd-edge-angle), color-mix(in oklab, var(--lime) 30%, transparent), var(--lime) 18%, color-mix(in oklab, var(--lime) 30%, transparent) 36%, color-mix(in oklab, var(--lime) 30%, transparent));
  -webkit-mask: linear-gradient(var(--fg) 0 0) content-box, linear-gradient(var(--fg) 0 0); -webkit-mask-composite: xor;
  mask: linear-gradient(var(--fg) 0 0) content-box exclude, linear-gradient(var(--fg) 0 0);
  animation: sd-edge-turn var(--dur-ambient, 2.4s) linear infinite;
}
.sd-edge-ring[data-active="false"] { animation-play-state: paused; }
@media (prefers-reduced-motion: reduce) { .sd-edge-ring { animation: none; background: var(--lime); } }
@media (forced-colors: active) { .sd-edge-ring { animation: none; background: none; -webkit-mask: none; mask: none; padding: 0; border: var(--focus-width) solid CanvasText; } }
`;

/** Wraps a surface and draws a calm moving ring in the AI colour around it, only while the AI is working on it. */
export function WorkingEdge({ active, children, label = "AI is working on this", radius = "card", announce = true, className, ...rest }: WorkingEdgeProps) {
  return (
    <div {...rest} className={cn("relative", RADIUS[radius], className)}>
      <style href="tattva-working-edge" precedence="default">{CSS}</style>
      {children}
      <span aria-hidden data-active={active}
        className={cn("sd-edge-ring transition-opacity", active ? "opacity-100 duration-[var(--dur-base)] ease-[var(--ease-arrive)]" : "opacity-0 duration-[var(--dur-fast)] ease-[var(--ease-in)]")} />
      {announce && <span role="status" aria-live="polite" className="sr-only">{active ? label : ""}</span>}
    </div>
  );
}
