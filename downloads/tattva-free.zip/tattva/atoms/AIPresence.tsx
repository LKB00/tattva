import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { cn } from "../lib/cn";

export type AIPresenceState = "idle" | "listening" | "thinking" | "speaking" | "error";
export type AIPresenceSize = "sm" | "md" | "lg";

export interface AIPresenceProps {
  /** What the assistant is doing. Changes are announced once in a polite status region. */
  state?: AIPresenceState;
  size?: AIPresenceSize;
  /**
   * Optional audio amplitude from 0 to 1, for example from a microphone analyser.
   * The component smooths it over several frames, so pass the raw value. It is ignored under reduced motion.
   */
  level?: number;
  /** Show the state as visible text beside the mark. The status region for assistive technology is always present. */
  showLabel?: boolean;
  /** Override the text for each state, for localisation. */
  labels?: Partial<Record<AIPresenceState, string>>;
  className?: string;
}

const DEFAULT_LABELS: Record<AIPresenceState, string> = {
  idle: "Ready", listening: "Listening", thinking: "Thinking", speaking: "Speaking", error: "Something went wrong",
};

/**
 * One continuous parameter set. Each state is a row of targets the animation eases toward, so moving between
 * states never restarts anything: the mark just changes how it moves.
 */
interface Params {
  breathHz: number; breathAmp: number; // slow swell of the halo
  halo: number;      // how much of the soft halo shows
  ripple: number;    // opacity of the rings that spread while listening
  arc: number;       // opacity of the arc that circles while thinking
  turn: number;      // how fast the arc turns, degrees per second
  gain: number;      // how much the audio level moves things
}
const TARGETS: Record<AIPresenceState, Params> = {
  idle:      { breathHz: 0.25, breathAmp: 0.04, halo: 1,   ripple: 0, arc: 0, turn: 0,   gain: 0 },
  listening: { breathHz: 0.6,  breathAmp: 0.03, halo: 1,   ripple: 1, arc: 0, turn: 0,   gain: 0.5 },
  thinking:  { breathHz: 0.4,  breathAmp: 0.02, halo: 1,   ripple: 0, arc: 1, turn: 220, gain: 0 },
  speaking:  { breathHz: 1.4,  breathAmp: 0.05, halo: 1,   ripple: 0, arc: 0, turn: 0,   gain: 1 },
  error:     { breathHz: 0,    breathAmp: 0,    halo: 0,   ripple: 0, arc: 0, turn: 0,   gain: 0 },
};

const DIM: Record<AIPresenceSize, string> = { sm: "size-8", md: "size-16", lg: "size-28" };

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(() => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  useEffect(() => {
    if (typeof window.matchMedia !== "function") return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const on = () => setReduced(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return reduced;
}

const DISC = 27;  // the AI-colour disc, in a 100 x 100 box
const HALO = 39;  // the soft halo around it
const ARC = 33;   // the thinking arc runs in the halo, between the disc and the halo's edge
const MARK = "M12.4 1.5Q14.2 9.8 21.5 11.4Q13.8 14.4 11.4 22.5Q9.6 14 2.5 12.6Q9.8 9.8 12.4 1.5Z";

/**
 * The assistant's presence: the Tattva AI mark on a disc in the theme's AI colour, inside a soft halo. Flat, like
 * the rest of the system: no glass, glow or blur, only theme colours. Idle breathes slowly, listening sends rings
 * outward, thinking turns a thin arc round the disc, speaking swells with the audio level, and an error turns the
 * disc to the danger colours and stops. One frame loop eases a set of parameters toward the current state, so
 * changing state never restarts an animation. Under prefers-reduced-motion no frames run: each state is a still
 * drawing plus its label. Place a labelled Stop button beside it. The disc is not a control.
 */
export function AIPresence({ state = "idle", size = "md", level = 0, showLabel = true, labels, className }: AIPresenceProps) {
  const reduced = usePrefersReducedMotion();
  const text = { ...DEFAULT_LABELS, ...labels }[state];
  const halo = useRef<SVGCircleElement>(null);
  const disc = useRef<SVGGElement>(null);
  const arc = useRef<SVGGElement>(null);
  const rip1 = useRef<SVGCircleElement>(null);
  const rip2 = useRef<SVGCircleElement>(null);
  const cur = useRef<Params>({ ...TARGETS[state] });
  const target = useRef<Params>(TARGETS[state]);
  const lvlIn = useRef(0);
  lvlIn.current = Math.min(1, Math.max(0, level));

  const draw = (t: number, lvl: number, angle: number) => {
    const c = cur.current;
    const breath = Math.sin(2 * Math.PI * c.breathHz * t) * c.breathAmp;
    const push = lvl * c.gain;
    halo.current?.setAttribute("r", String(HALO * (1 + breath + push * 0.08)));
    halo.current?.setAttribute("opacity", String(c.halo));
    disc.current?.setAttribute("transform", `translate(50 50) scale(${1 + push * 0.1}) translate(-50 -50)`);
    arc.current?.setAttribute("opacity", String(c.arc));
    arc.current?.setAttribute("transform", `rotate(${angle} 50 50)`);
    // Two rings spread out from the disc and fade, half a cycle apart.
    const p1 = (t * 0.55) % 1, p2 = (t * 0.55 + 0.5) % 1;
    rip1.current?.setAttribute("r", String(DISC + p1 * (HALO + 9 - DISC)));
    rip1.current?.setAttribute("opacity", String(c.ripple * (1 - p1)));
    rip2.current?.setAttribute("r", String(DISC + p2 * (HALO + 9 - DISC)));
    rip2.current?.setAttribute("opacity", String(c.ripple * (1 - p2)));
  };

  useLayoutEffect(() => {
    target.current = TARGETS[state];
    if (reduced) { cur.current = { ...TARGETS[state] }; draw(0, 0, 40); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state, reduced]);

  useEffect(() => {
    if (reduced) return;
    let raf = 0, last = performance.now(), t = 0, angle = 0, lvl = 0;
    const loop = (now: number) => {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000)); last = now; t += dt;
      const ease = 1 - Math.exp(-dt / 0.18);
      const c = cur.current, g = target.current;
      (Object.keys(g) as (keyof Params)[]).forEach((k) => { c[k] += (g[k] - c[k]) * ease; });
      const rate = lvlIn.current > lvl ? 0.35 : 0.12; // fast attack, slow release, per 60fps frame
      lvl += (lvlIn.current - lvl) * (1 - Math.pow(1 - rate, dt * 60));
      angle = (angle + c.turn * dt) % 360;
      draw(t, lvl, angle);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced]);

  const init = TARGETS[state];
  const err = state === "error";
  return (
    <div className={cn("inline-flex items-center gap-3", className)}>
      <svg viewBox="0 0 100 100" aria-hidden="true" focusable="false" className={cn("shrink-0 overflow-visible", DIM[size])}>
        {/* The soft halo, and the rings that spread while listening. */}
        <circle ref={halo} cx="50" cy="50" r={HALO} opacity={init.halo} style={{ fill: "var(--lime-soft)", transition: "opacity var(--dur-base)" }} />
        <circle ref={rip1} cx="50" cy="50" r={DISC} fill="none" strokeWidth="2" opacity="0" style={{ stroke: "var(--lime)" }} />
        <circle ref={rip2} cx="50" cy="50" r={DISC} fill="none" strokeWidth="2" opacity="0" style={{ stroke: "var(--lime)" }} />
        {/* The arc that turns in the halo, round the disc, while thinking. Text colour, so it reads in light and dark. */}
        <g ref={arc} opacity={init.arc}>
          <path d={`M50 ${50 - ARC} A ${ARC} ${ARC} 0 0 1 ${50 + ARC} 50`} fill="none" strokeWidth="2.5" strokeLinecap="round" style={{ stroke: "var(--fg)" }} />
        </g>
        {/* The disc in the AI colour, and the AI mark at its centre. */}
        <g ref={disc}>
          <circle cx="50" cy="50" r={DISC} style={{ fill: err ? "var(--danger-soft)" : "var(--lime)", transition: "fill var(--dur-base)" }} />
          <path d={MARK} transform="translate(50 50) scale(1.5) translate(-12 -12)" style={{ fill: err ? "var(--danger-fg)" : "var(--on-lime)", transition: "fill var(--dur-base)" }} />
        </g>
      </svg>
      {showLabel && <span aria-hidden="true" className={cn("text-small leading-4", err ? "text-danger-fg" : "text-fg-muted")}>{text}</span>}
      <span role="status" className="sr-only">{text}</span>
    </div>
  );
}
