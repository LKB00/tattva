import { useId } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface SwitchProps {
  checked: boolean;
  onChange: (v: boolean) => void;
  /** Accessible name. Used as aria-label only when there are no children. */
  label: string;
  /** Visible label beside the switch. Clicking it toggles the switch, and it becomes the accessible name. */
  children?: ReactNode;
  /** Which side of the switch the children sit on. */
  labelPosition?: "start" | "end";
  /** Blocks toggling and dims the switch. */
  disabled?: boolean;
  /** Extra context announced after the name through aria-describedby. Rendered as screen reader text. */
  description?: string;
  id?: string;
  className?: string;
}

/** Controlled on/off toggle. The track is 20px tall. The button around it is at least 24px tall, and 44px on coarse pointers. */
export function Switch({ checked, onChange, label, children, labelPosition = "end", disabled, description, id, className }: SwitchProps) {
  const descId = useId();
  const textId = useId();
  const hasText = children != null && children !== false && children !== "";
  const control = (
    <button type="button" role="switch" id={id} aria-checked={checked} aria-label={hasText ? undefined : label} aria-labelledby={hasText ? textId : undefined} disabled={disabled}
      aria-describedby={description ? descId : undefined} onClick={() => { if (!disabled) onChange(!checked); }}
      className={cn("inline-flex min-h-6 min-w-9 shrink-0 cursor-pointer items-center justify-center rounded-full disabled:cursor-not-allowed pointer-coarse:min-h-11 pointer-coarse:min-w-11", !hasText && className)}>
      <span aria-hidden className={cn("relative block h-5 w-9 rounded-full border border-transparent forced-colors:border-[CanvasText] transition-colors duration-[var(--dur-fast)]", disabled ? "bg-line" : checked ? "bg-accent" : "bg-line-strong")}>
        <span className={cn("absolute top-px left-px size-4 rounded-full bg-thumb shadow-sm forced-colors:bg-[CanvasText] transition-transform duration-[var(--dur-fast)]", checked && "translate-x-4")} />
      </span>
      {description && <span id={descId} className="sr-only">{description}</span>}
    </button>
  );
  if (!hasText) return control;
  const text = <span id={textId} className={cn("text-body leading-5", disabled ? "text-disabled-fg" : "text-fg")}>{children}</span>;
  return (
    <label className={cn("inline-flex items-center gap-3", disabled ? "cursor-not-allowed" : "cursor-pointer", className)}>
      {labelPosition === "start" && text}
      {control}
      {labelPosition === "end" && text}
    </label>
  );
}
