import { useEffect, useId, useRef, useState } from "react";
import { cn } from "../lib/cn";
import { CopyIcon, EditIcon } from "../lib/icons";
import { Button, IconButton } from "../atoms/Button";
import { VersionPager } from "./VersionPager";

export interface EditableTurnLabels {
  edit?: string;
  copy?: string;
  copied?: string;
  send?: string;
  cancel?: string;
  /** Name of the edit box for screen readers. */
  field?: string;
  /** One line under the edit box. */
  note?: string;
}

export interface EditableTurnProps {
  /** Every version of this message the person has sent, oldest first. */
  versions: string[];
  /** Which version is showing, 1-based. Defaults to the newest. */
  current?: number;
  /** Shows another version (and the replies that followed it). */
  onChangeVersion?: (version: number) => void;
  /** Sends the edited text as a new version. The replies after this message are written again. */
  onResend: (text: string) => void;
  /** Copies the message. The button is hidden when omitted. */
  onCopy?: (text: string) => void;
  labels?: EditableTurnLabels;
  className?: string;
}

/**
 * A message the person sent, which they can edit and send again. Sending an edit starts a new branch: the earlier
 * versions stay, and a small pager (◀ 2 of 2 ▶) moves between them. The Edit and Copy buttons sit under the
 * bubble and are always there, not only on hover, so touch and keyboard users can reach them.
 */
export function EditableTurn({ versions, current, onChangeVersion, onResend, onCopy, labels, className }: EditableTurnProps) {
  const l = {
    edit: "Edit", copy: "Copy", copied: "Copied", send: "Send", cancel: "Cancel", field: "Edit your message",
    note: "Sending this writes the replies after it again. Your earlier version stays.", ...labels,
  };
  const at = Math.min(Math.max(current ?? versions.length, 1), versions.length);
  const text = versions[at - 1] ?? "";
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(text);
  const [copied, setCopied] = useState(false);
  const box = useRef<HTMLTextAreaElement>(null);
  const editBtn = useRef<HTMLButtonElement>(null);
  const uid = useId();
  const back = useRef(false);
  useEffect(() => {
    if (editing) { const el = box.current; el?.focus(); el?.setSelectionRange(el.value.length, el.value.length); }
    else if (back.current) { back.current = false; editBtn.current?.focus(); }
  }, [editing]);
  const start = () => { setDraft(text); setEditing(true); };
  const stop = () => { back.current = true; setEditing(false); };
  const send = () => { const t = draft.trim(); if (!t) return; back.current = true; setEditing(false); if (t !== text.trim()) onResend(t); };
  if (editing) {
    return (
      <div className={cn("flex justify-end", className)}>
        <div className="w-full max-w-[80%] max-sm:max-w-full">
          <label htmlFor={`${uid}-box`} className="sr-only">{l.field}</label>
          <textarea id={`${uid}-box`} ref={box} value={draft} onChange={(e) => setDraft(e.target.value)} rows={3} aria-describedby={`${uid}-note`}
            onKeyDown={(e) => { if (e.key === "Escape") { e.preventDefault(); stop(); } if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } }}
            className="block w-full resize-y rounded-card border border-line-strong bg-surface px-4 py-3 text-body-lg leading-relaxed text-fg" />
          <p id={`${uid}-note`} className="m-0 mt-2 text-small leading-5 text-fg-muted">{l.note}</p>
          <div className="mt-3 flex justify-end gap-2">
            <Button size="sm" variant="ghost" onClick={stop}>{l.cancel}</Button>
            <Button size="sm" onClick={send} disabled={!draft.trim()}>{l.send}</Button>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className={cn("flex flex-col items-end gap-1.5", className)}>
      <div className="max-w-[80%] rounded-card rounded-br-[min(var(--radius-lg),var(--shape-card))] bg-sunken px-5 py-3 text-body-lg leading-relaxed whitespace-pre-wrap text-fg">{text}</div>
      <div className="flex items-center gap-0.5">
        {versions.length > 1 && <VersionPager total={versions.length} current={at} onChange={onChangeVersion} edited={at > 1} label="Versions of your message" />}
        {onCopy && (
          <IconButton size="sm" label={copied ? l.copied : l.copy} onClick={() => { onCopy(text); setCopied(true); window.setTimeout(() => setCopied(false), 1500); }}>
            <CopyIcon width={14} height={14} />
          </IconButton>
        )}
        <IconButton ref={editBtn} size="sm" label={l.edit} onClick={start}><EditIcon width={14} height={14} /></IconButton>
      </div>
    </div>
  );
}
