import { useId } from "react";
import { cn } from "../lib/cn";
import { CheckIcon } from "../lib/icons";

export interface ChoiceChipOption {
  value: string;
  label: string;
}

export interface ChoiceChipsProps {
  /** The question, shown above the chips: "Which nights?" */
  label: string;
  options: ChoiceChipOption[];
  /** The picked value, or values when `multiple`. */
  value: string | string[];
  onChange: (value: string | string[]) => void;
  /** Several chips may be picked. Each is then a checkbox; otherwise the chips are one radio group. */
  multiple?: boolean;
  /** Value of the option the assistant suggests. It is listed first and says "Suggested". */
  recommended?: string;
  /** Hides the question visually; it is still read by screen readers. */
  hideLabel?: boolean;
  /** Turns every chip off, for example after the answer was sent. */
  disabled?: boolean;
  className?: string;
}

/**
 * A short question with its answers as small chips, for one pick or several. Lighter than QuestionSet: one question,
 * inside a message or a form. Built on real radio buttons or checkboxes, so arrow keys, Space and screen readers work
 * as they do for any form; the picked chip shows a tick as well as its colour.
 */
export function ChoiceChips({ label, options, value, onChange, multiple = false, recommended, hideLabel = false, disabled = false, className }: ChoiceChipsProps) {
  const name = useId();
  const picked = Array.isArray(value) ? value : value ? [value] : [];
  const shown = [...options].sort((a, b) => Number(b.value === recommended) - Number(a.value === recommended));
  const toggle = (v: string, on: boolean) => {
    if (!multiple) { onChange(v); return; }
    onChange(on ? [...picked.filter((x) => x !== v), v] : picked.filter((x) => x !== v));
  };
  return (
    <fieldset disabled={disabled} className={cn("m-0 min-w-0 border-0 p-0", className)}>
      <legend className={cn("mb-2 p-0 text-body leading-5 font-medium text-fg", hideLabel && "sr-only")}>
        {label}{multiple && <span className="font-normal text-fg-muted"> (pick any)</span>}
      </legend>
      <div className="flex flex-wrap gap-2">
        {shown.map((o) => {
          const on = picked.includes(o.value);
          return (
            <label key={o.value}
              className={cn(
                "relative inline-flex min-h-8 cursor-pointer items-center gap-1.5 rounded-control border px-3 text-compact leading-5 transition-colors duration-[var(--dur-fast)] pointer-coarse:min-h-11",
                "has-[input:focus-visible]:outline-(length:--focus-width) has-[input:focus-visible]:outline-solid has-[input:focus-visible]:outline-offset-2 has-[input:focus-visible]:outline-[color:var(--focus-ring)]",
                on ? "border-accent bg-accent-soft font-medium text-fg" : "border-line bg-surface text-fg-muted hover:border-line-strong hover:text-fg",
                disabled && "cursor-not-allowed opacity-(--disabled-opacity) hover:border-line hover:text-fg-muted",
                "forced-colors:border-[CanvasText]",
              )}>
              <input type={multiple ? "checkbox" : "radio"} name={name} value={o.value} checked={on} disabled={disabled}
                onChange={(e) => toggle(o.value, e.target.checked)} className="sr-only" />
              {on && <CheckIcon aria-hidden className="size-3.5 shrink-0" strokeWidth={2.5} />}
              <span>{o.label}</span>
              {o.value === recommended && <span className="text-small leading-4 text-fg-muted">Suggested</span>}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
