import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { Skeleton } from "../atoms/Skeleton";

export interface Fact {
  /** What the value is: "Check-in", "Plan". */
  label: string;
  /** The value itself: "3pm", "Pro". Text or a small part such as a Badge. */
  value: ReactNode;
}

export interface FactListProps {
  facts: Fact[];
  /** "split" puts the label and the value side by side; "stacked" puts the label above the value, for narrow places. */
  layout?: "split" | "stacked";
  /** On wide screens, lays the facts out in two columns. */
  columns?: 1 | 2;
  /** Shows placeholder rows while the facts are still arriving. */
  loading?: boolean;
  /** How many placeholder rows to show while loading. */
  loadingRows?: number;
  /** Said when there are no facts. Nothing is drawn when omitted. */
  emptyLabel?: string;
  className?: string;
}

/**
 * Short label and value pairs, such as "Check-in: 3pm" or "Plan: Pro". A description list, so each value is read
 * with its label. Light enough to sit in an answer or a card, and easy to scan on a phone.
 */
export function FactList({ facts, layout = "split", columns = 1, loading = false, loadingRows = 3, emptyLabel, className }: FactListProps) {
  if (loading) {
    return (
      <div aria-busy="true" className={cn("grid gap-2", className)}>
        {Array.from({ length: loadingRows }, (_, i) => (
          <div key={i} className="flex items-center justify-between gap-4"><Skeleton className="h-4 w-24" /><Skeleton className="h-4 w-16" /></div>
        ))}
      </div>
    );
  }
  if (facts.length === 0) return emptyLabel ? <p className={cn("m-0 text-body leading-5 text-fg-muted", className)}>{emptyLabel}</p> : null;
  return (
    <dl className={cn("m-0 grid gap-x-8", columns === 2 && "sm:grid-cols-2", className)}>
      {facts.map((f, i) => (
        <div key={`${f.label}-${i}`}
          className={cn("min-w-0 py-1.5", layout === "split" ? "flex items-baseline justify-between gap-4" : "flex flex-col gap-0.5")}>
          <dt className="shrink-0 text-body leading-5 text-fg-muted">{f.label}</dt>
          <dd className={cn("m-0 min-w-0 text-body leading-5 font-medium text-fg [overflow-wrap:anywhere]", layout === "split" && "text-right")}>{f.value}</dd>
        </div>
      ))}
    </dl>
  );
}
