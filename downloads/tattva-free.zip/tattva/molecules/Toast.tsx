import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { AlertIcon, CheckIcon, InfoIcon, XIcon } from "../lib/icons";
import { IconButton } from "../atoms/Button";
import { useReducedMotion } from "../hooks/useReducedMotion";

export type ToastTone = "neutral" | "success" | "danger" | "info";

export interface ToastOptions {
  title: string;
  description?: string;
  tone?: ToastTone;
  action?: { label: string; onClick: () => void };
  /** Milliseconds before it closes. 0 keeps it until dismissed. By default it follows the content: 4s for a title, 6s with a description, 8s with an action. */
  duration?: number;
}

export interface ToastApi {
  show: (options: ToastOptions) => string;
  dismiss: (id: string) => void;
  /** Changes a toast in place, for example "Saving" to "Saved". Its timer starts again with the new content. */
  update: (id: string, options: Partial<ToastOptions>) => void;
}

/** How long a toast stays when no duration is given: long enough to read, longest when there is something to press. */
export const toastDuration = (o: ToastOptions) => o.duration ?? (o.action ? 8000 : o.description ? 6000 : 4000);

const toneIcon = {
  neutral: null,
  success: <CheckIcon aria-hidden width={18} height={18} className="mt-0.5 shrink-0 text-success-fg" />,
  danger: <AlertIcon aria-hidden width={18} height={18} className="mt-0.5 shrink-0 text-danger-fg" />,
  info: <InfoIcon aria-hidden width={18} height={18} className="mt-0.5 shrink-0 text-info-fg" />,
} satisfies Record<ToastTone, ReactNode>;

export interface ToastProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  title: string;
  description?: string;
  tone?: ToastTone;
  action?: { label: string; onClick: () => void };
  /** Shows the close button. Without it the toast has no close button, so pass it whenever the toast can go away. */
  onDismiss?: () => void;
  /** Shows how much time is left, as a thin bar along the bottom. Pass the length in ms; `paused` holds it. */
  timeLeft?: { duration: number; paused: boolean };
}

/** The toast itself, without any timing. Use it to show a toast in docs or to build your own host. A danger toast has role="alert". */
export function Toast({ title, description, tone = "neutral", action, onDismiss, timeLeft, className, onKeyDown, ...rest }: ToastProps) {
  return (
    <div role={tone === "danger" ? "alert" : undefined} {...rest}
      onKeyDown={(e) => { onKeyDown?.(e); if (e.key === "Escape" && onDismiss && !e.defaultPrevented) { e.stopPropagation(); onDismiss(); } }}
      className={cn("pointer-events-auto relative flex w-full max-w-sm items-start gap-3 overflow-hidden rounded-overlay border border-line bg-raised p-3 pl-4 text-body leading-5 text-fg shadow-lg forced-colors:border-[CanvasText]", className)}>
      {toneIcon[tone]}
      <div className="min-w-0 flex-1 py-0.5">
        <p className="font-medium">{title}</p>
        {description && <p className="mt-0.5 text-fg-muted">{description}</p>}
        {action && (
          <button type="button" onClick={action.onClick}
            className="-ml-2 mt-1.5 inline-flex h-8 cursor-pointer items-center rounded-md px-2 text-compact font-medium text-accent-fg hover:bg-hover pointer-coarse:min-h-11">
            {action.label}
          </button>
        )}
      </div>
      {onDismiss && (
        <IconButton label={`Close notification: ${title}`} size="sm" onClick={onDismiss} className="-mt-0.5 -mr-1 shrink-0 pointer-coarse:size-11">
          <XIcon aria-hidden width={14} height={14} />
        </IconButton>
      )}
      {timeLeft && timeLeft.duration > 0 && (
        <span aria-hidden className="absolute inset-x-0 bottom-0 h-0.5 origin-left bg-line-strong motion-reduce:hidden"
          style={{ animation: `shrink-x ${timeLeft.duration}ms linear both`, animationPlayState: timeLeft.paused ? "paused" : "running" }} />
      )}
    </div>
  );
}

const ToastContext = createContext<ToastApi | null>(null);

/** Returns `{ show, dismiss, update }`. Must be used under a ToastProvider. */
export function useToast(): ToastApi {
  const api = useContext(ToastContext);
  if (!api) throw new Error("useToast must be used inside a ToastProvider.");
  return api;
}

interface Item extends ToastOptions { id: string; version: number; leaving?: boolean }
const MAX_VISIBLE = 3;
const EXIT_MS = 150; // --dur-fast

function ToastItem({ item, onDismiss }: { item: Item; onDismiss: (id: string) => void }) {
  const [hover, setHover] = useState(false);
  const [focus, setFocus] = useState(false);
  const [touch, setTouch] = useState(false);
  // A hidden tab cannot be read, so the clock stops there too.
  const [away, setAway] = useState(() => typeof document !== "undefined" && document.visibilityState === "hidden");
  useEffect(() => {
    const f = () => setAway(document.visibilityState === "hidden");
    document.addEventListener("visibilitychange", f);
    return () => document.removeEventListener("visibilitychange", f);
  }, []);
  const paused = hover || focus || touch || away;
  const duration = toastDuration(item);
  const remaining = useRef(duration);
  const dismiss = useRef(onDismiss);
  dismiss.current = onDismiss;

  // Time left carries over a pause, so hovering does not reset the countdown.
  useEffect(() => {
    if (!duration || paused) return;
    const start = Date.now();
    const t = setTimeout(() => dismiss.current(item.id), remaining.current);
    return () => { clearTimeout(t); remaining.current -= Date.now() - start; };
  }, [paused, duration, item.id]);

  return (
    <li className={cn("pointer-events-none flex w-full justify-center md:justify-end", item.leaving ? "motion-safe:animate-fade-out" : "motion-safe:animate-rise")}>
      <Toast title={item.title} description={item.description} tone={item.tone} action={item.action && { label: item.action.label, onClick: () => { item.action!.onClick(); onDismiss(item.id); } }}
        onDismiss={() => onDismiss(item.id)} timeLeft={item.action && duration ? { duration, paused } : undefined}
        onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
        onTouchStart={() => setTouch(true)} onTouchEnd={() => setTouch(false)} onTouchCancel={() => setTouch(false)}
        onFocus={() => setFocus(true)} onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setFocus(false); }} />
    </li>
  );
}

/**
 * Hosts the toasts. Put it once near the root. The region and its live list stay mounted so screen readers
 * hear new toasts. At most three show at once, newest on top; older ones wait and appear when there is room.
 */
export function ToastProvider({ children, className }: { children: ReactNode; className?: string }) {
  const [items, setItems] = useState<Item[]>([]);
  const counter = useRef(0);
  const reduce = useReducedMotion();
  // A toast fades out (faster than it arrived) before it leaves the list.
  const dismiss = useCallback((id: string) => {
    if (reduce) { setItems((l) => l.filter((t) => t.id !== id)); return; }
    setItems((l) => l.map((t) => (t.id === id ? { ...t, leaving: true } : t)));
    window.setTimeout(() => setItems((l) => l.filter((t) => t.id !== id)), EXIT_MS);
  }, [reduce]);
  const show = useCallback((options: ToastOptions) => {
    counter.current += 1;
    const id = `toast-${counter.current}`;
    setItems((l) => [...l, { ...options, id, version: 0 }]);
    return id;
  }, []);
  const update = useCallback((id: string, options: Partial<ToastOptions>) => {
    setItems((l) => l.map((t) => (t.id === id ? { ...t, ...options, version: t.version + 1 } : t)));
  }, []);
  const api = useMemo(() => ({ show, dismiss, update }), [show, dismiss, update]);
  const visible = [...items].reverse().slice(0, MAX_VISIBLE);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <section role="region" aria-label="Notifications" className={cn("pointer-events-none fixed inset-x-0 bottom-0 z-50 p-4 pb-[max(1rem,var(--safe-bottom))]", className)}>
        <ol aria-live="polite" aria-relevant="additions text" className="m-0 flex list-none flex-col gap-2 p-0">
          {visible.map((t) => <ToastItem key={`${t.id}-${t.version}`} item={t} onDismiss={dismiss} />)}
        </ol>
      </section>
    </ToastContext.Provider>
  );
}
