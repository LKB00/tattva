import { useEffect, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { Kbd } from "../atoms/Kbd";
import { Popover } from "../atoms/Popover";

export type MenuEntry =
  | { type?: "item"; id: string; label: string; icon?: ReactNode; shortcut?: string; disabled?: boolean; danger?: boolean; onSelect: () => void }
  | { type: "separator" }
  | { type: "label"; label: string };

export interface MenuProps {
  /** Content of the trigger button. For an icon alone, also set triggerLabel. */
  trigger: ReactNode;
  /** Accessible name of the trigger button. Required when the trigger is only an icon. */
  triggerLabel?: string;
  /** Accessible name of the menu itself. Defaults to triggerLabel, then "Menu". */
  label?: string;
  items: MenuEntry[];
  align?: "start" | "end";
  side?: "bottom" | "top";
  /** Draw the menu on the page itself so a scrolling or clipped parent cannot cut it off. Use inside lists and side bars. */
  portal?: boolean;
  /** On a phone the menu opens as a bottom sheet within thumb reach. Set false to keep a small floating menu there too. */
  phoneSheet?: boolean;
  className?: string;
}

const ENABLED = '[role="menuitem"]:not([aria-disabled="true"])';

/** Action menu opened from a button, following the WAI-ARIA menu button pattern. Built on Popover. */
export function Menu({ trigger, triggerLabel, label, items, align = "start", side = "bottom", portal, phoneSheet, className }: MenuProps) {
  const [open, setOpen] = useState(false);
  const list = useRef<HTMLDivElement>(null);
  const openAt = useRef<"first" | "last">("first");
  const buffer = useRef({ text: "", timer: 0 });

  // Popover focuses the first item. ArrowUp from the trigger asks for the last one instead.
  useEffect(() => {
    if (!open) return;
    if (openAt.current === "last") {
      const all = list.current?.querySelectorAll<HTMLElement>(ENABLED);
      all?.[all.length - 1]?.focus();
    }
    openAt.current = "first";
  }, [open]);
  useEffect(() => () => window.clearTimeout(buffer.current.timer), []);

  const typeAhead = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key.length !== 1 || e.ctrlKey || e.metaKey || e.altKey || (e.key === " " && !buffer.current.text)) return;
    const all = Array.from(list.current?.querySelectorAll<HTMLElement>(ENABLED) ?? []);
    if (!all.length) return;
    e.preventDefault();
    const b = buffer.current;
    window.clearTimeout(b.timer);
    b.text += e.key.toLowerCase();
    b.timer = window.setTimeout(() => { b.text = ""; }, 600);
    const cur = all.findIndex((el) => el === document.activeElement);
    // One repeated letter cycles through matches; a longer word keeps the current match if it still fits.
    const start = b.text.length === 1 ? cur + 1 : Math.max(cur, 0);
    for (let k = 0; k < all.length; k++) {
      const el = all[(start + k) % all.length];
      if ((el.dataset.label ?? "").toLowerCase().startsWith(b.text)) { el.focus(); return; }
    }
  };

  return (
    <Popover label={label ?? triggerLabel ?? "Menu"} role="menu" align={align} side={side} portal={portal} phoneSheet={phoneSheet} open={open} onOpenChange={setOpen} className={className} panelClassName="min-w-48"
      trigger={({ triggerProps }) => (
        <button type="button" aria-label={triggerLabel} {...triggerProps}
          onClick={() => setOpen(!open)}
          onKeyDown={(e) => {
            if (open || (e.key !== "ArrowDown" && e.key !== "ArrowUp")) return;
            e.preventDefault();
            openAt.current = e.key === "ArrowUp" ? "last" : "first";
            setOpen(true);
          }}
          className="inline-flex min-h-9 min-w-9 cursor-pointer items-center justify-center gap-2 rounded-control border border-line bg-surface px-2.5 text-body font-medium text-fg transition-colors duration-[var(--dur-fast)] hover:bg-hover pointer-coarse:min-h-11 pointer-coarse:min-w-11">
          {trigger}
        </button>
      )}>
      {({ close }) => (
        <div ref={list} onKeyDown={typeAhead}>
          {items.map((it, i) => {
            if (it.type === "separator") return <div key={`s${i}`} role="separator" className="my-1 h-px bg-line forced-colors:bg-[CanvasText]" />;
            if (it.type === "label") return <div key={`l${i}`} role="presentation" className="px-2.5 pt-2 pb-1 text-small leading-4 font-medium text-fg-subtle">{it.label}</div>;
            return (
              <button key={it.id} type="button" role="menuitem" tabIndex={-1} data-label={it.label} aria-disabled={it.disabled || undefined}
                onClick={() => { if (it.disabled) return; it.onSelect(); close(); }}
                className={cn(
                  "flex min-h-9 w-full items-center gap-2.5 rounded-lg px-2.5 text-left text-body focus-visible:outline-offset-[-2px] pointer-coarse:min-h-11",
                  it.disabled ? "cursor-not-allowed opacity-(--disabled-opacity)" : cn("cursor-pointer hover:bg-hover focus-visible:bg-hover", it.danger ? "text-danger-fg" : "text-fg"),
                )}>
                {it.icon && <span aria-hidden className="flex size-4 shrink-0 items-center justify-center">{it.icon}</span>}
                <span className="flex-1">{it.label}</span>
                {it.shortcut && <Kbd>{it.shortcut}</Kbd>}
              </button>
            );
          })}
        </div>
      )}
    </Popover>
  );
}
