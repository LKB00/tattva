import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { Avatar } from "../atoms/Avatar";

export interface MessageProps {
  role: "user" | "assistant";
  /** True while tokens are still arriving. Shows the caret, sets aria-busy and keeps the streaming text out of live announcements. */
  streaming?: boolean;
  /** Announced once, politely, when streaming ends. */
  completeLabel?: string;
  /** How the person's own turn looks. bubble is a right-aligned bubble. plain is left-aligned serif text with no box, like a line in a letter. Only changes user messages. */
  variant?: "bubble" | "plain";
  /** Show the assistant's avatar. Turn it off for settled lines so the mark appears once, on the latest line; the text then sits flush left. */
  showAvatar?: boolean;
  children: ReactNode;
  /** Slot under the bubble: MessageActions, FeedbackBar, SourceList... */
  footer?: ReactNode;
  className?: string;
}

/**
 * User messages are right-aligned bubbles; assistant messages are unboxed prose
 * with an avatar so long answers stay readable.
 */
export function Message({ role, streaming, completeLabel = "Response complete", variant = "bubble", showAvatar = true, children, footer, className }: MessageProps) {
  const [announce, setAnnounce] = useState("");
  const was = useRef(false);
  useEffect(() => {
    if (streaming) setAnnounce("");
    else if (was.current) setAnnounce(completeLabel);
    was.current = !!streaming;
  }, [streaming, completeLabel]);

  if (role === "user" && variant === "plain") {
    return <div className={cn("animate-rise font-serif text-turn text-fg", className)}>{children}</div>;
  }
  if (role === "user") {
    return (
      <div className={cn("flex justify-end animate-rise", className)}>
        <div className="max-w-[80%] rounded-card rounded-br-[min(var(--radius-lg),var(--shape-card))] bg-sunken px-5 py-3 text-body-lg leading-relaxed">{children}</div>
      </div>
    );
  }
  return (
    <div className={cn("flex animate-rise", showAvatar && "gap-3", className)} aria-busy={streaming || undefined}>
      {showAvatar && <Avatar kind="ai" />}
      <div className="min-w-0 flex-1 space-y-3 pt-0.5">
        {/* aria-live is off while tokens arrive, so screen readers are not interrupted per token. */}
        <div aria-live={streaming ? "off" : undefined} className="space-y-4 text-body-lg leading-7 text-fg">
          {children}
          {streaming && <span aria-hidden className="ml-0.5 inline-block h-4 w-0.5 translate-y-0.5 bg-fg animate-caret" />}
        </div>
        {footer}
        <span role="status" className="sr-only">{announce}</span>
      </div>
    </div>
  );
}
