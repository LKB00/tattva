import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { SparkleIcon } from "../lib/icons";

export interface MessageProps {
  role: "user" | "assistant";
  /** True while tokens are still arriving. Shows the caret, sets aria-busy and keeps the streaming text out of live announcements. */
  streaming?: boolean;
  /** Announced once, politely, when streaming ends. */
  completeLabel?: string;
  /** How the person's own turn looks. bubble is a right-aligned bubble. plain is left-aligned serif text with no box, like a line in a letter. Only changes user messages. */
  variant?: "bubble" | "plain";
  /**
   * The AI mark on an assistant reply. none (the default) shows no mark: the reply uses the full width and its place in
   * the thread says who wrote it, as in most chat products. top shows a small mark and the name above the reply: use it
   * once, on the first reply of a thread, or on every reply when more than one assistant or agent speaks.
   */
  mark?: "none" | "top";
  /** The name shown with the mark and read by screen readers before the reply. Defaults to "Assistant". */
  name?: string;
  /** @deprecated Use mark. true shows the mark above the reply; the mark no longer sits beside it. */
  showAvatar?: boolean;
  children: ReactNode;
  /** Slot under the bubble: MessageActions, FeedbackBar, SourceList... */
  footer?: ReactNode;
  className?: string;
}

/**
 * User messages are right-aligned bubbles; assistant messages are unboxed prose across the full width, so long answers
 * stay readable and short ones do not leave a column of marks down the thread. Screen readers hear the name first.
 */
export function Message({ role, streaming, completeLabel = "Response complete", variant = "bubble", mark, name = "Assistant", showAvatar, children, footer, className }: MessageProps) {
  const top = (mark ?? (showAvatar ? "top" : "none")) === "top";
  const [announce, setAnnounce] = useState("");
  const was = useRef(false);
  useEffect(() => {
    if (streaming) setAnnounce("");
    else if (was.current) setAnnounce(completeLabel);
    was.current = !!streaming;
  }, [streaming, completeLabel]);

  if (role === "user" && variant === "plain") {
    return <div className={cn("animate-rise font-serif text-turn text-fg", className)}>{children}</div>;
  }
  if (role === "user") {
    return (
      <div className={cn("flex justify-end animate-rise", className)}>
        <div className="max-w-[80%] rounded-card rounded-br-[min(var(--radius-lg),var(--shape-card))] bg-sunken px-5 py-3 text-body-lg leading-relaxed">{children}</div>
      </div>
    );
  }
  return (
    <div className={cn("animate-rise min-w-0 space-y-3", className)} aria-busy={streaming || undefined}>
      {top && (
        <p className="flex items-center gap-1.5 text-compact font-medium text-fg-muted">
          <span aria-hidden className="grid size-5 place-items-center rounded-full bg-lime text-on-lime"><SparkleIcon width={11} height={11} /></span>{name}
        </p>
      )}
      {/* aria-live is off while tokens arrive, so screen readers are not interrupted per token. */}
      <div aria-live={streaming ? "off" : undefined} className="space-y-4 text-body-lg leading-7 text-fg">
        {!top && <span className="sr-only">{name}: </span>}
        {children}
        {streaming && <span aria-hidden className="ml-0.5 inline-block h-4 w-0.5 translate-y-0.5 bg-fg animate-caret" />}
      </div>
      {footer}
      <span role="status" className="sr-only">{announce}</span>
    </div>
  );
}
