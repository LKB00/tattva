import { cn } from "../lib/cn";
import { headingTag, type HeadingLevel } from "../lib/useFocusAfter";
import { Badge, type Tone } from "../atoms/Badge";
import { Button } from "../atoms/Button";
import { Skeleton } from "../atoms/Skeleton";
import { formatPrice } from "../atoms/Price";
import { FactList, type Fact } from "./FactList";
import { MediaFrame } from "./MediaFrame";

export interface ResultCardPrice {
  value: number;
  /** ISO currency code, such as "EUR". */
  currency?: string;
  locale?: string;
  decimals?: number;
  /** What the price is for: "per night", "a month". */
  note?: string;
}

export interface ResultCardProps {
  /** The thing's name: a hotel, product, place or person. */
  title: string;
  /** One short line under the name: an area, a brand, a role. */
  subtitle?: string;
  /** A picture of the thing. `alt` says what it shows. */
  image?: { src: string; alt: string };
  /** Two to four facts that help choose between results. */
  facts?: Fact[];
  price?: ResultCardPrice;
  /** One short tag, such as "Free cancellation" or "Best match". */
  tag?: { label: string; tone?: Tone };
  /** The one thing to do with this result. */
  action?: { label: string; onClick: () => void };
  /** The answer is still arriving: the card is shown, but its action waits until the answer is complete. */
  streaming?: boolean;
  /** Draws placeholders while the result is loading. */
  loading?: boolean;
  /** Level of the name's heading. Defaults to 3, under an answer's own heading. */
  headingLevel?: HeadingLevel;
  className?: string;
}

/**
 * One thing in an answer, such as a hotel, a product, a place or a person: a picture, its name, a few facts, an
 * optional price and tag, and one action. Lay several out with CardRow, all with the same fields.
 */
export function ResultCard({ title, subtitle, image, facts, price, tag, action, streaming = false, loading = false, headingLevel = 3, className }: ResultCardProps) {
  const H = headingTag(headingLevel);
  if (loading) {
    return (
      <div aria-busy="true" className={cn("flex h-full w-full flex-col gap-3 rounded-card border border-line bg-surface p-3", className)}>
        <Skeleton className="aspect-video w-full rounded-[max(2px,calc(var(--radius-card)-12px))]" />
        <Skeleton className="h-5 w-2/3" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-4 w-full" />
      </div>
    );
  }
  return (
    <article className={cn("flex h-full w-full flex-col overflow-hidden rounded-card border border-line bg-surface", className)} aria-busy={streaming || undefined}>
      {image && (
        <div className="relative">
          <MediaFrame src={image.src} alt={image.alt} ratio="16:9" flush />
          {/* On a picture the tag sits on its corner, so the name keeps the full width. */}
          {tag && <Badge tone={tag.tone ?? "neutral"} className="absolute top-3 left-3">{tag.label}</Badge>}
        </div>
      )}
      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <H className="m-0 font-sans! text-lead leading-6 font-semibold text-fg [overflow-wrap:anywhere]">{title}</H>
            {subtitle && <p className="m-0 mt-0.5 text-body leading-5 text-fg-muted">{subtitle}</p>}
          </div>
          {tag && !image && <Badge tone={tag.tone ?? "neutral"} className="shrink-0">{tag.label}</Badge>}
        </div>
        {facts && facts.length > 0 && <FactList facts={facts} className="-my-1.5" />}
        {(price || action) && (
          <div className="mt-auto flex flex-wrap items-end justify-between gap-3 pt-1">
            {price ? (
              <p className="m-0 min-w-0">
                <span className="text-lead-lg leading-6 font-semibold text-fg tabular-nums">{formatPrice(price.value, price.currency ?? "USD", price.locale ?? "en-US", price.decimals ?? 0)}</span>
                {price.note && <span className="ml-1 text-body leading-5 text-fg-muted">{price.note}</span>}
              </p>
            ) : <span />}
            {action && (
              <Button size="sm" variant="secondary" onClick={action.onClick} disabled={streaming} aria-label={`${action.label}: ${title}`}>{action.label}</Button>
            )}
          </div>
        )}
      </div>
    </article>
  );
}
