import { useEffect, useRef, useState } from "react";
import type { AnimationItem } from "lottie-web";
import { cn } from "../lib/cn";

/** The 35 Tattva scenes. Each is a Lottie file at `scenes/<name>.json` on the site and in the npm package. */
export const sceneNames = [
  "first-use", "no-results", "error", "permission", "offline", "rate-limit", "success", "upload", "working",
  "sources", "approval", "confidence", "refusal", "memory", "private", "undo", "sensitive",
  "plan", "takeover", "needs-you", "background",
  "variants", "voice", "video", "slides", "music",
  "chart", "generated", "first-run", "download", "connect", "lost", "whats-new", "accessible", "mobile",
] as const;
export type SceneName = (typeof sceneNames)[number];

/** A plain title for each scene, for galleries and as a fallback accessible name. */
export const sceneTitles: Record<SceneName, string> = {
  "first-use": "First message", "no-results": "Nothing found", error: "Something broke", permission: "Asking for access",
  offline: "No connection", "rate-limit": "Slow down", success: "Done", upload: "Add a file", working: "Working on it",
  sources: "Show the sources", approval: "Ask before acting", confidence: "How sure it is", refusal: "A polite no",
  memory: "What it remembers", private: "Private chat", undo: "Take it back", sensitive: "Hide private details",
  plan: "The plan", takeover: "Take over", "needs-you": "Waiting for you", background: "Working while you are away",
  variants: "Pick a version", voice: "Speak to it", video: "Take after take", slides: "Build a deck", music: "Make music",
  chart: "Read the numbers", generated: "Built as it goes", "first-run": "Get started", download: "Download",
  connect: "Connect", lost: "Page not found", "whats-new": "What is new", accessible: "Works for everyone", mobile: "On a phone",
};

export type SceneMotion = "loop" | "once" | "still";
export type SceneSize = "sm" | "md" | "lg" | "fill";

export interface SceneIllustrationProps {
  /** The scene's Lottie data. Pass this or `src`. */
  data?: object;
  /** Address of the scene's Lottie file, for example `${base}scenes/approval.json`. Used when `data` is not given. */
  src?: string;
  /** Accessible name. Leave it out when nearby words already say what the scene shows; the scene is then hidden from assistive tech. */
  label?: string;
  /** `loop` plays the entrance, then a calm loop. `once` plays the entrance and stops. `still` shows the finished picture. Reduced motion always shows the still picture. */
  motion?: SceneMotion;
  /** Width: 12rem, 18rem or 30rem. `fill` takes the width of its container. Height follows at 4:3. */
  size?: SceneSize;
  className?: string;
}

const sizes: Record<SceneSize, string> = { sm: "w-48", md: "w-72", lg: "w-120", fill: "w-full" };

/* Scenes are drawn with three key colours. The theme decides what they become, so scenes follow light and dark mode. */
const themed =
  "[&_[fill='rgb(17,17,17)']]:fill-fg [&_[stroke='rgb(17,17,17)']]:stroke-fg " +
  "[&_[fill='rgb(255,255,255)']]:fill-surface [&_[stroke='rgb(255,255,255)']]:stroke-surface " +
  "[&_[fill='rgb(200,240,74)']]:fill-lime [&_[stroke='rgb(200,240,74)']]:stroke-lime";

interface Marker { tm: number; cm: string; dr: number }

/** Where the entrance ends and the loop runs, read from the file's "intro" and "loop" markers. */
function segments(data: { markers?: Marker[]; op?: number }) {
  const intro = data.markers?.find((m) => m.cm === "intro");
  const loop = data.markers?.find((m) => m.cm === "loop");
  const end = data.op ?? 0;
  const introEnd = intro ? intro.tm + intro.dr : end;
  return { introEnd, loop: loop ? [loop.tm, loop.tm + loop.dr] as [number, number] : null };
}

/**
 * A Tattva scene: a small story told with objects and a lime shape, played from a Lottie file.
 * It plays a short entrance, then a calm loop that carries the meaning, and pauses while off screen.
 */
export function SceneIllustration({ data, src, label, motion = "loop", size = "md", className }: SceneIllustrationProps) {
  const box = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let anim: AnimationItem | null = null;
    let seen: IntersectionObserver | null = null;
    let cancelled = false;
    const still = motion === "still" || window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    (async () => {
      const json = (data ?? (src ? await fetch(src).then((r) => r.json()) : null)) as { markers?: Marker[]; op?: number } | null;
      if (!json || cancelled || !box.current) return;
      const lottie = (await import("lottie-web/build/player/lottie_light")).default;
      if (cancelled || !box.current) return;
      const { introEnd, loop } = segments(json);
      anim = lottie.loadAnimation({
        container: box.current, renderer: "svg", loop: false, autoplay: false,
        animationData: structuredClone(json), rendererSettings: { preserveAspectRatio: "xMidYMid meet" },
      });
      anim.addEventListener("DOMLoaded", () => {
        setReady(true);
        if (still) { anim?.goToAndStop(introEnd, true); return; }
        anim?.playSegments([0, introEnd], true);
      });
      anim.addEventListener("complete", () => {
        if (motion === "loop" && loop && anim) { anim.loop = true; anim.playSegments(loop, true); }
      });
      if (!still) {
        let hidden = false;
        seen = new IntersectionObserver(([e]) => {
          if (!anim) return;
          if (!e.isIntersecting) { hidden = true; anim.pause(); } else if (hidden) { hidden = false; anim.play(); }
        });
        seen.observe(box.current);
      }
    })();

    return () => { cancelled = true; seen?.disconnect(); anim?.destroy(); };
  }, [data, src, motion]);

  return (
    <div
      ref={box}
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      aria-busy={ready ? undefined : true}
      className={cn("aspect-[4/3] max-w-full shrink-0", sizes[size], themed, className)}
    />
  );
}
