import { useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";

export interface CameraFocusProps {
  children: ReactNode;
  /**
   * What to push in on. `target` is a CSS selector inside the content, such as "[data-demo=price]": the camera
   * centres on that element. Or give `x` and `y` as percentages of the content. Null pulls back out.
   */
  focus?: { target: string; scale?: number } | { x: number; y: number; scale?: number } | null;
  className?: string;
}

/**
 * A camera over a faux UI demo: it pushes in on the detail that matters (a price, an approval) and pulls back out.
 * Aim it at a named element, so it stays on target when the layout changes. Use it once or twice in a loop, on the
 * beat the story is about. With reduced motion it stays still.
 */
export function CameraFocus({ children, focus, className }: CameraFocusProps) {
  const box = useRef<HTMLDivElement>(null);
  const [move, setMove] = useState({ x: 0, y: 0 });
  const target = focus && "target" in focus ? focus.target : null;
  const scale = focus?.scale ?? 1.6;

  // Bring the target to the middle of the frame, like a camera, without showing past the content's edges.
  // Measured before zooming, in the content's own (unscaled) coordinates.
  useLayoutEffect(() => {
    if (!focus || !box.current) return;
    const b = box.current.getBoundingClientRect();
    if (!b.width) return;
    let cx = b.width / 2, cy = b.height / 2;
    if ("target" in focus) {
      const el = box.current.querySelector<HTMLElement>(focus.target);
      if (!el) return;
      const r = el.getBoundingClientRect();
      cx = r.left + r.width / 2 - b.left; cy = r.top + r.height / 2 - b.top;
    } else { cx = (focus.x / 100) * b.width; cy = (focus.y / 100) * b.height; }
    const clamp = (v: number, size: number) => Math.min(0, Math.max(size - size * scale, v));
    setMove({ x: clamp(b.width / 2 - cx * scale, b.width), y: clamp(b.height / 2 - cy * scale, b.height) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, focus && "x" in focus ? focus.x : null, focus && "y" in focus ? focus.y : null, !!focus, scale]);

  return (
    <div ref={box} className={cn("size-full [transition:transform_var(--dur-demo)_cubic-bezier(.4,0,.2,1)] motion-reduce:transform-none! motion-reduce:transition-none", className)}
      style={{ transformOrigin: "0 0", transform: focus ? `translate(${move.x}px, ${move.y}px) scale(${scale})` : "translate(0, 0) scale(1)" }}>
      {children}
    </div>
  );
}
