import { useId, useState } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { CheckIcon, ChevronIcon } from "../lib/icons";

export interface ReceiptProps {
  /** What was settled, such as "Confirmed the facts". */
  title: string;
  /** Right side of the row, such as a date or an amount. */
  meta?: ReactNode;
  /** Replaces the default check. Decorative. */
  icon?: ReactNode;
  /** The full card, shown when opened. */
  children: ReactNode;
  defaultOpen?: boolean;
  /** Controlled open state. */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Mount the children even while closed (hidden), for example to keep form state. */
  keepMounted?: boolean;
  className?: string;
}

/**
 * A settled card folded into one line so the thread stays short. Every decision card in a thread becomes a
 * Receipt once the person has acted. Opening it shows the original card in place; nothing traps focus.
 */
export function Receipt({ title, meta, icon, children, defaultOpen = false, open, onOpenChange, keepMounted, className }: ReceiptProps) {
  const uid = useId();
  const [inner, setInner] = useState(defaultOpen);
  const isOpen = open ?? inner;
  const toggle = () => { const v = !isOpen; if (open === undefined) setInner(v); onOpenChange?.(v); };
  return (
    <div className={cn("rounded-card border border-line bg-surface", className)}>
      <button type="button" id={`${uid}-b`} aria-expanded={isOpen} aria-controls={`${uid}-r`} onClick={toggle}
        className="flex min-h-10 w-full cursor-pointer items-center gap-3 rounded-card px-4 py-2 text-left text-body leading-5 hover:bg-hover pointer-coarse:min-h-11">
        <span aria-hidden className="flex shrink-0 text-success-fg">{icon ?? <CheckIcon width={16} height={16} />}</span>
        <span className="min-w-0 flex-1 break-words font-medium">{title}</span>
        {meta && <span className="shrink-0 text-small leading-4 text-fg-muted">{meta}</span>}
        <ChevronIcon aria-hidden className={cn("shrink-0 text-fg-subtle transition-transform duration-[var(--dur-fast)]", isOpen && "rotate-90")} />
      </button>
      <div id={`${uid}-r`} role="region" aria-labelledby={`${uid}-b`} hidden={!isOpen} className="border-t border-line p-3">
        {(isOpen || keepMounted) && children}
      </div>
    </div>
  );
}
