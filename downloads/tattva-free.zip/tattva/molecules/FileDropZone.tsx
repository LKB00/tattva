import { useId, useRef, useState } from "react";
import { cn } from "../lib/cn";
import { AlertIcon, PaperclipIcon } from "../lib/icons";
import { Button } from "../atoms/Button";

export interface FileDropZoneLabels {
  title?: string;
  browse?: string;
  drop?: string;
  /** Receives the accepted kinds and the size limit, already in words. */
  hint?: (kinds: string, size: string) => string;
  /** Receives the file name. */
  wrongKind?: (name: string) => string;
  /** Receives the file name and the limit. */
  tooBig?: (name: string, size: string) => string;
}

export interface FileDropZoneProps {
  /** Called with the files that passed the checks. */
  onFiles: (files: File[]) => void;
  /** Accepted extensions, such as ["pdf", "docx", "png"]. Any file when omitted. */
  accept?: string[];
  /** Largest file in megabytes. */
  maxSizeMb?: number;
  multiple?: boolean;
  disabled?: boolean;
  labels?: FileDropZoneLabels;
  className?: string;
}

/**
 * Where people add files for the AI to read: drop them on the area or press Browse. It says up front which kinds
 * and sizes work, and when a file does not, it says which one and why, instead of failing quietly. Browse is a real
 * button, so keyboard and screen reader users never need to drag.
 */
export function FileDropZone({ onFiles, accept, maxSizeMb, multiple = true, disabled, labels, className }: FileDropZoneProps) {
  const l = {
    title: "Add files", browse: "Browse files", drop: "Drop to add",
    hint: (k: string, s: string) => [k, s].filter(Boolean).join(". ") + (k || s ? "." : ""),
    wrongKind: (n: string) => `${n} is a kind of file that cannot be read here.`,
    tooBig: (n: string, s: string) => `${n} is larger than ${s}.`, ...labels,
  };
  const [over, setOver] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const input = useRef<HTMLInputElement>(null);
  const uid = useId();
  const sizeText = maxSizeMb ? `${maxSizeMb} MB` : "";
  const kindsText = accept?.length ? `${accept.map((a) => a.toUpperCase()).join(", ")}` : "";
  const take = (list: FileList | null) => {
    if (!list || disabled) return;
    const ok: File[] = [], bad: string[] = [];
    for (const f of [...list].slice(0, multiple ? undefined : 1)) {
      const ext = f.name.split(".").pop()?.toLowerCase() ?? "";
      if (accept?.length && !accept.map((a) => a.toLowerCase()).includes(ext)) bad.push(l.wrongKind(f.name));
      else if (maxSizeMb && f.size > maxSizeMb * 1024 * 1024) bad.push(l.tooBig(f.name, sizeText));
      else ok.push(f);
    }
    setErrors(bad);
    if (ok.length) onFiles(ok);
  };
  return (
    <div className={cn("space-y-2", className)}>
      <div
        onDragOver={(e) => { if (disabled) return; e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); take(e.dataTransfer.files); }}
        className={cn("flex flex-col items-center gap-3 rounded-card border-2 border-dashed px-4 py-8 text-center transition-colors duration-(--dur-fast) motion-reduce:transition-none",
          over ? "border-selected-line bg-selected" : "border-line-strong bg-bg", disabled && "opacity-(--disabled-opacity)")}>
        <PaperclipIcon aria-hidden width={22} height={22} className="text-fg-muted" />
        <p className="m-0 text-body leading-5 font-medium text-fg">{over ? l.drop : l.title}</p>
        {(kindsText || sizeText) && <p id={`${uid}-hint`} className="m-0 text-small leading-5 text-fg-muted">{l.hint(kindsText, sizeText ? `Up to ${sizeText}` : "")}</p>}
        <Button size="sm" variant="secondary" disabled={disabled} onClick={() => input.current?.click()} aria-describedby={kindsText || sizeText ? `${uid}-hint` : undefined}>{l.browse}</Button>
        <input ref={input} type="file" multiple={multiple} hidden tabIndex={-1} accept={accept?.map((a) => `.${a}`).join(",")}
          onChange={(e) => { take(e.target.files); e.target.value = ""; }} />
      </div>
      <div role="alert">
        {errors.map((e) => (
          <p key={e} className="m-0 flex items-start gap-1.5 text-small leading-5 text-danger-fg"><AlertIcon aria-hidden width={14} height={14} className="mt-0.5 shrink-0" />{e}</p>
        ))}
      </div>
    </div>
  );
}
