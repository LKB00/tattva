import { useEffect, useId, useRef, useState } from "react";
import type { FocusEvent, KeyboardEvent, PointerEvent, ReactNode } from "react";
import { Button } from "../atoms/Button";
import { cn } from "../lib/cn";

export interface InlineConfirmProps {
  /** The first button's label, for example "Delete chat". */
  children: ReactNode;
  /** Label of the button that does the action. */
  confirmLabel?: string;
  /** Label of the safe button that goes back. It gets focus when the question shows. */
  cancelLabel?: string;
  /** The question shown in place of the button. Defaults to the confirm label plus " this?". */
  question?: string;
  /** Called once when the confirm button is pressed. */
  onConfirm: () => void;
  /** danger draws the confirm button in the danger colour. */
  tone?: "danger" | "default";
  /** Milliseconds before the question quietly goes back to the first button. 0 turns this off. */
  timeout?: number;
  className?: string;
}

type Pause = "hover" | "focus" | "touch" | "hidden";

/** A button that asks "Are you sure?" in its own place instead of opening a dialog. */
export function InlineConfirm({ children, confirmLabel = "Delete", cancelLabel = "Keep it", question, onConfirm, tone = "default", timeout = 6000, className }: InlineConfirmProps) {
  const [asking, setAsking] = useState(false);
  const questionId = useId();
  const root = useRef<HTMLSpanElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const cancel = useRef<HTMLButtonElement>(null);
  // "trigger" or "cancel": where focus goes after the next swap. Visibility must change before focus can land.
  const focusNext = useRef<"trigger" | "cancel" | null>(null);

  const pauses = useRef(new Set<Pause>());
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const left = useRef(timeout);
  const startedAt = useRef(0);

  const close = (focusTrigger: boolean) => {
    clearTimeout(timer.current);
    timer.current = undefined;
    // Hover and touch are still true after a close; they are tracked all the time.
    pauses.current.delete("focus");
    pauses.current.delete("hidden");
    focusNext.current = focusTrigger ? "trigger" : null;
    setAsking(false);
  };

  // Runs the timer only while nothing pauses it, and keeps the time left across pauses.
  const sync = () => {
    if (!asking || timeout <= 0) return;
    if (pauses.current.size === 0 && timer.current === undefined) {
      startedAt.current = Date.now();
      timer.current = setTimeout(() => {
        timer.current = undefined;
        // Only take focus back if it was inside, so a timeout never pulls focus from elsewhere.
        close(!!root.current?.contains(document.activeElement));
      }, left.current);
    } else if (pauses.current.size > 0 && timer.current !== undefined) {
      clearTimeout(timer.current);
      timer.current = undefined;
      left.current -= Date.now() - startedAt.current;
    }
  };
  const pause = (p: Pause, on: boolean) => {
    if (on) pauses.current.add(p); else pauses.current.delete(p);
    sync();
  };

  useEffect(() => {
    if (asking) left.current = timeout;
    const target = focusNext.current === "cancel" ? cancel.current : focusNext.current === "trigger" ? trigger.current : null;
    focusNext.current = null;
    target?.focus();
    if (!asking) return;
    const onVis = () => pause("hidden", document.visibilityState === "hidden");
    onVis();
    sync();
    document.addEventListener("visibilitychange", onVis);
    return () => { document.removeEventListener("visibilitychange", onVis); clearTimeout(timer.current); timer.current = undefined; };
  }, [asking]);

  const ask = () => { focusNext.current = "cancel"; setAsking(true); };
  const confirm = () => { close(true); onConfirm(); };

  const onKeyDown = (e: KeyboardEvent) => {
    if (asking && e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(true); }
  };
  // Keyboard focus pauses the timer. Focus moved there after a mouse press does not, so the question still times out.
  const onFocusIn = (e: FocusEvent) => { if (asking) pause("focus", (e.target as HTMLElement).matches(":focus-visible")); };
  const onFocusOut = (e: FocusEvent) => { if (!root.current?.contains(e.relatedTarget as Node | null)) pause("focus", false); };
  const onEnter = (e: PointerEvent) => { if (e.pointerType === "mouse") pause("hover", true); };
  const onLeave = (e: PointerEvent) => { if (e.pointerType === "mouse") pause("hover", false); };

  const q = question ?? `${confirmLabel} this?`;

  return (
    <span
      ref={root}
      onKeyDown={onKeyDown}
      onFocus={onFocusIn}
      onBlur={onFocusOut}
      onPointerEnter={onEnter}
      onPointerLeave={onLeave}
      onTouchStart={() => pause("touch", true)}
      onTouchEnd={() => pause("touch", false)}
      onTouchCancel={() => pause("touch", false)}
      // Two columns: the first holds the button and, stacked on it, the question and Cancel. Confirm sits in the
      // second, so it can never appear under the pointer that pressed the first button.
      className={cn("inline-grid grid-cols-[auto_auto] items-center gap-x-2 align-middle", className)}
    >
      <span className={cn("col-start-1 row-start-1 justify-self-start", asking && "invisible")}>
        <Button ref={trigger} variant="secondary" size="sm" onClick={ask}>{children}</Button>
      </span>
      <span className={cn("col-start-1 row-start-1 flex items-center gap-2", asking ? "motion-safe:animate-fade" : "invisible")}>
        <span id={questionId} className="text-compact text-fg">{q}</span>
        <Button ref={cancel} variant="secondary" size="sm" onClick={() => close(true)}>{cancelLabel}</Button>
      </span>
      <span className={cn("col-start-2 row-start-1", asking ? "motion-safe:animate-fade" : "invisible")}>
        <Button variant={tone === "danger" ? "danger" : "primary"} size="sm" onClick={confirm} aria-describedby={questionId}>{confirmLabel}</Button>
      </span>
      <span role="status" aria-live="polite" className="sr-only">{asking ? q : ""}</span>
    </span>
  );
}
