import { useRef, useState, type KeyboardEvent, type PointerEvent } from "react";
import { cn } from "../lib/cn";

export interface SplitterProps {
  /** horizontal draws a vertical bar between left and right panes. vertical draws a horizontal bar between top and bottom panes. */
  direction: "horizontal" | "vertical";
  /** Size of the first pane in px. */
  value: number;
  onChange: (px: number) => void;
  min: number;
  max: number;
  /** Accessible name, for example "Resize sidebar". */
  label: string;
  /** Called on double click and on Enter. Use it to collapse or restore the first pane. */
  onToggle?: () => void;
  /** Keyboard step in px. Shift multiplies it by 4. */
  step?: number;
  className?: string;
}

/**
 * Only the draggable bar. Your layout draws the two panes and sizes the first one from `value`.
 * The bar is 12px across (44px on touch screens, through an invisible larger hit area).
 */
export function Splitter({ direction, value, onChange, min, max, label, onToggle, step = 16, className }: SplitterProps) {
  const [dragging, setDragging] = useState(false);
  const start = useRef({ pos: 0, size: 0 });
  const horizontal = direction === "horizontal";
  const clamp = (n: number) => Math.round(Math.min(max, Math.max(min, n)));

  const down = (e: PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    start.current = { pos: horizontal ? e.clientX : e.clientY, size: value };
    setDragging(true);
  };
  const move = (e: PointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    const delta = (horizontal ? e.clientX : e.clientY) - start.current.pos;
    const next = clamp(start.current.size + delta);
    if (next !== value) onChange(next);
  };
  const up = (e: PointerEvent<HTMLDivElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
    setDragging(false);
  };

  const key = (e: KeyboardEvent<HTMLDivElement>) => {
    const s = step * (e.shiftKey ? 4 : 1);
    const grow = horizontal ? "ArrowRight" : "ArrowDown";
    const shrink = horizontal ? "ArrowLeft" : "ArrowUp";
    let next: number | undefined;
    if (e.key === grow) next = value + s;
    else if (e.key === shrink) next = value - s;
    else if (e.key === "Home") next = min;
    else if (e.key === "End") next = max;
    else if (e.key === "Enter" && onToggle) { e.preventDefault(); onToggle(); return; }
    if (next === undefined) return;
    e.preventDefault();
    onChange(clamp(next));
  };

  return (
    <div role="separator" tabIndex={0} aria-label={label} aria-orientation={horizontal ? "vertical" : "horizontal"}
      aria-valuenow={clamp(value)} aria-valuemin={min} aria-valuemax={max}
      onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onDoubleClick={onToggle} onKeyDown={key}
      className={cn(
        "group relative shrink-0 touch-none select-none",
        horizontal ? "h-full w-3 cursor-col-resize" : "h-3 w-full cursor-row-resize",
        className,
      )}>
      {/* Larger invisible target on touch screens. */}
      <span aria-hidden className={cn("absolute hidden pointer-coarse:block", horizontal ? "inset-y-0 -inset-x-4" : "inset-x-0 -inset-y-4")} />
      <span aria-hidden className={cn(
        "absolute transition-colors duration-[var(--dur-fast)] forced-colors:bg-[CanvasText]",
        horizontal ? cn("inset-y-0 left-1/2 -translate-x-1/2", dragging ? "w-0.5" : "w-px") : cn("inset-x-0 top-1/2 -translate-y-1/2", dragging ? "h-0.5" : "h-px"),
        dragging ? "bg-accent" : "bg-line group-hover:bg-line-strong group-focus-visible:bg-line-strong",
      )} />
    </div>
  );
}
