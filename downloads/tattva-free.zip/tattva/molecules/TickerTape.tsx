import { useEffect, useRef, useState } from "react";
import type { Ref } from "react";
import { cn } from "../lib/cn";
import { useReducedMotion } from "../hooks/useReducedMotion";
import { PriceChange } from "../atoms/PriceChange";

export interface TickerItem {
  symbol: string;
  price: number;
  /** Absolute change. */
  change: number;
  /** Change in percent. */
  percent: number;
}

export interface TickerTapeProps {
  items: TickerItem[];
  /** Accessible name of the strip, such as "Market ticker". */
  label: string;
  /** Scroll speed in pixels per second. */
  speed?: number;
  /** Controlled pause state. Leave out to let the strip manage it. */
  paused?: boolean;
  onPausedChange?: (paused: boolean) => void;
  className?: string;
}

function plain(n: number): string {
  if (!Number.isFinite(n)) return "—";
  return new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
}

function Row({ items, hidden, rowRef }: { items: TickerItem[]; hidden?: boolean; rowRef?: Ref<HTMLUListElement> }) {
  return (
    <ul ref={rowRef} aria-hidden={hidden || undefined} inert={hidden} className="m-0 flex shrink-0 list-none items-center p-0">
      {items.map((it) => (
        <li key={it.symbol} className="flex items-baseline gap-2 border-r border-line px-4 py-2 text-body leading-5 whitespace-nowrap">
          <span className="font-medium text-fg">{it.symbol}</span>
          <span className="font-mono tabular-nums text-fg">{plain(it.price)}</span>
          <PriceChange change={it.change} percent={it.percent} format="both" className="text-small leading-4" />
        </li>
      ))}
    </ul>
  );
}

function PauseIcon({ paused }: { paused: boolean }) {
  return (
    <svg aria-hidden viewBox="0 0 16 16" className="size-4" fill="currentColor">
      {paused ? <path d="M5 3l8 5-8 5z" /> : <path d="M4.5 3h2.5v10H4.5zM9 3h2.5v10H9z" />}
    </svg>
  );
}

/** A looping strip of prices. It stops when paused, hovered or focused, and does not move at all with reduced motion. */
export function TickerTape({ items, label, speed = 40, paused, onPausedChange, className }: TickerTapeProps) {
  const reduced = useReducedMotion();
  const [inner, setInner] = useState(false);
  const isControlled = paused !== undefined;
  const pausedNow = isControlled ? paused : inner;
  const [hover, setHover] = useState(false);
  const [focus, setFocus] = useState(false);
  const trackRef = useRef<HTMLDivElement>(null);
  const copyRef = useRef<HTMLUListElement>(null);
  const offset = useRef(0);

  const moving = !reduced && !pausedNow && !hover && !focus && items.length > 0;
  const loops = !reduced && items.length > 0;

  useEffect(() => {
    if (!moving) return;
    let raf = 0;
    let last = performance.now();
    const step = (t: number) => {
      const width = copyRef.current?.offsetWidth ?? 0;
      const dt = Math.min(t - last, 100) / 1000;
      last = t;
      if (width > 0) {
        offset.current = (offset.current + speed * dt) % width;
        if (trackRef.current) trackRef.current.style.transform = `translateX(${-offset.current}px)`;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [moving, speed]);

  // Reduced motion: drop the transform so the strip can be scrolled by hand.
  useEffect(() => {
    if (reduced && trackRef.current) { trackRef.current.style.transform = ""; offset.current = 0; }
  }, [reduced]);

  const toggle = () => { if (!isControlled) setInner(!pausedNow); onPausedChange?.(!pausedNow); };
  const name = pausedNow ? "Play ticker" : "Pause ticker";

  return (
    <div role="region" aria-label={label} className={cn("flex items-stretch overflow-hidden rounded-card border border-line bg-surface", className)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onFocus={() => setFocus(true)} onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setFocus(false); }}>
      <div tabIndex={reduced ? 0 : undefined} className={cn("min-w-0 flex-1", reduced ? "overflow-x-auto" : "overflow-hidden")}>
        <div ref={trackRef} className="flex w-max will-change-transform">
          <Row items={items} rowRef={copyRef} />
          {loops && <Row items={items} hidden />}
        </div>
      </div>
      <button type="button" onClick={toggle} aria-label={name} title={name}
        className="inline-flex min-h-9 min-w-9 shrink-0 cursor-pointer items-center justify-center gap-1.5 border-l border-line px-3 text-small leading-4 font-medium text-fg-muted transition-colors duration-[var(--dur-fast)] hover:bg-hover hover:text-fg pointer-coarse:min-h-11 pointer-coarse:min-w-11">
        <PauseIcon paused={pausedNow} />
        <span className="hidden sm:inline">{pausedNow ? "Play" : "Pause"}</span>
      </button>
    </div>
  );
}
