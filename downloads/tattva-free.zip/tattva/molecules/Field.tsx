import { useId } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { AlertIcon } from "../lib/icons";

export interface FieldControlProps {
  id: string;
  "aria-describedby"?: string;
  "aria-invalid"?: boolean;
  required?: boolean;
}

export interface FieldProps {
  /** Visible label, joined to the control with htmlFor. */
  label: string;
  /** Help text under the control. */
  hint?: string;
  /** Error message. Setting it marks the control invalid. */
  error?: string;
  required?: boolean;
  /** Shows "(optional)" after the label. */
  optional?: boolean;
  /** Receives the id and aria props to spread onto the control. */
  children: (control: FieldControlProps) => ReactNode;
  className?: string;
}

/** Label, control, hint and error in one wrapper, with the ids wired for you. */
export function Field({ label, hint, error, required, optional, children, className }: FieldProps) {
  const uid = useId();
  const id = `${uid}-control`, hintId = `${uid}-hint`, errorId = `${uid}-error`;
  const describedBy = [hint && hintId, error && errorId].filter(Boolean).join(" ") || undefined;
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <label htmlFor={id} className="text-body leading-5 font-medium text-fg">
        {label}
        {required && <span aria-hidden className="ml-0.5 text-fg-muted">*</span>}
        {optional && !required && <span className="ml-1 font-normal text-fg-muted">(optional)</span>}
      </label>
      {children({ id, "aria-describedby": describedBy, "aria-invalid": error ? true : undefined, required: required || undefined })}
      {hint && <p id={hintId} className="text-small leading-4 text-fg-muted">{hint}</p>}
      {/* Always mounted so screen readers pick up the message when it appears. */}
      <div id={errorId} aria-live="polite" className="empty:-mt-1.5">
        {error && <p className="flex items-start gap-1.5 text-small leading-4 text-danger-fg"><AlertIcon className="mt-px shrink-0" width={14} height={14} />{error}</p>}
      </div>
    </div>
  );
}
