import { cn } from "../lib/cn";
import { Skeleton } from "../atoms/Skeleton";

export interface ShareDatum {
  label: string;
  value: number;
}

export interface ShareBarProps {
  /** The parts of the whole, largest first reads best. Past five, the smallest fold into "Other". */
  data: ShareDatum[];
  /** Name of the whole, for example "Spend by model, October". Read before the shares. */
  ariaLabel: string;
  /** Formats each value in the list, for example as money. Percentages are always shown too. */
  formatValue?: (n: number) => string;
  /** Label of the one part to emphasise; the others draw in the neutral colour. */
  highlight?: string;
  /** Label for the folded parts. */
  otherLabel?: string;
  /** Shows placeholders while the numbers arrive. */
  loading?: boolean;
  /** Said when every value is zero or there is no data. */
  emptyText?: string;
  className?: string;
}

const MAX = 5;
const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

/** Rounds shares to whole percentages that add up to exactly 100, largest remainder first. */
export function sharePercents(values: number[]): number[] {
  const total = values.reduce((a, b) => a + b, 0);
  if (total <= 0) return values.map(() => 0);
  const raw = values.map((v) => (v / total) * 100);
  const out = raw.map(Math.floor);
  let left = 100 - out.reduce((a, b) => a + b, 0);
  for (const i of raw.map((r, i) => [r - Math.floor(r), i] as const).sort((a, b) => b[0] - a[0]).map(([, i]) => i)) {
    if (left <= 0) break;
    out[i] += 1; left -= 1;
  }
  return out;
}

/**
 * Shares of one whole as a single bar: one segment per part, in the chart colours, and a list under it that gives
 * each part's value and percentage. Reads better than a pie, and the numbers are always written out, so nothing
 * depends on colour.
 */
export function ShareBar({ data, ariaLabel, formatValue = (n) => n.toLocaleString(), highlight, otherLabel = "Other", loading = false, emptyText = "Nothing to show yet.", className }: ShareBarProps) {
  if (loading) {
    return (
      <div aria-busy="true" aria-label={ariaLabel} className={cn("grid gap-3", className)}>
        <Skeleton className="h-3 w-full" />
        <div className="flex flex-wrap gap-4"><Skeleton className="h-4 w-24" /><Skeleton className="h-4 w-20" /><Skeleton className="h-4 w-16" /></div>
      </div>
    );
  }
  const clean = data.filter((d) => d.value > 0);
  const parts = clean.length > MAX
    ? [...clean.slice(0, MAX - 1), { label: otherLabel, value: clean.slice(MAX - 1).reduce((a, d) => a + d.value, 0) }]
    : clean;
  if (parts.length === 0) return <p className={cn("m-0 text-body leading-5 text-fg-muted", className)}>{emptyText}</p>;
  const pct = sharePercents(parts.map((p) => p.value));
  const total = parts.reduce((a, p) => a + p.value, 0);
  const colorOf = (i: number, label: string) => highlight ? (label === highlight ? COLORS[0] : "var(--chart-neutral)") : COLORS[i];
  return (
    <figure className={cn("m-0 grid min-w-0 gap-3", className)}>
      <figcaption className="sr-only">{ariaLabel}</figcaption>
      <div aria-hidden className="flex h-3 w-full gap-0.5 overflow-hidden rounded-full forced-colors:border forced-colors:border-[CanvasText]">
        {parts.map((p, i) => (
          <span key={p.label} className="h-full min-w-1 shrink first:rounded-l-full last:rounded-r-full" style={{ width: `${(p.value / total) * 100}%`, background: colorOf(i, p.label) }} />
        ))}
      </div>
      <ul className="m-0 flex list-none flex-wrap gap-x-5 gap-y-1.5 p-0">
        {parts.map((p, i) => (
          <li key={p.label} className={cn("flex min-w-0 items-baseline gap-1.5 text-compact leading-5", highlight && p.label !== highlight ? "text-fg-muted" : "text-fg")}>
            <span aria-hidden className="size-2.5 shrink-0 translate-y-px self-center rounded-xs" style={{ background: colorOf(i, p.label) }} />
            <span className="min-w-0">{p.label}</span>
            <span className="font-medium tabular-nums">{pct[i]}%</span>
            <span className="text-fg-muted tabular-nums">{formatValue(p.value)}</span>
          </li>
        ))}
      </ul>
    </figure>
  );
}
