import { cn } from "../lib/cn";
import { AlertIcon } from "../lib/icons";
import { MeterBar } from "../atoms/MeterBar";

export interface CountdownProps {
  /** ISO date, such as 2026-10-27. Only the calendar day is used. */
  deadline: string;
  /** ISO date to count from. Defaults to today on this device. Pass it in docs and tests. */
  today?: string;
  /** What the date is, such as "They must reply by". */
  label: string;
  /** ISO date the clock started. Turns on the time bar. */
  start?: string;
  /** Only days for now. */
  unit?: "days";
  /** Shown with an icon once the deadline has passed. */
  missedLabel?: string;
  /** Turns an ISO date into the large text. Defaults to a long en-IN date. */
  formatDate?: (iso: string) => string;
  /** Amber treatment for a deadline that is due or missed and needs a person to act. Never on by default. */
  needsAction?: boolean;
  /** Text of the amber chip. */
  actionText?: string;
  className?: string;
}

const DAY = 86_400_000;

/** Whole days since 1970 for the calendar day in an ISO string. Plain UTC maths, so time zones and daylight saving cannot shift it. */
function dayNumber(iso: string): number {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) return NaN;
  return Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / DAY);
}

function localToday(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

const longDate = (iso: string) => {
  const n = dayNumber(iso);
  return Number.isNaN(n) ? "—" : new Date(n * DAY).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
};

const plural = (n: number) => `${n} ${n === 1 ? "day" : "days"}`;

/** The deadline, first and biggest: the date in large text, the days left in words, and an optional bar of time used. */
export function Countdown({ deadline, today, label, start, missedLabel = "Deadline passed", formatDate = longDate, needsAction, actionText = "Needs action", className }: CountdownProps) {
  const end = dayNumber(deadline);
  const now = dayNumber(today ?? localToday());
  const left = end - now;
  const valid = !Number.isNaN(left);
  const missed = valid && left < 0;
  const begin = start ? dayNumber(start) : NaN;
  const total = end - begin;
  const showBar = valid && total > 0;
  const used = showBar ? Math.max(0, Math.min(total, now - begin)) : 0;
  const attention = needsAction && valid && left <= 0;
  const words = !valid ? "" : missed ? `${plural(-left)} past` : left === 0 ? "Due today" : `${plural(left)} left`;
  return (
    <div role="group" aria-label={label} className={cn("min-w-0 rounded-card border bg-surface p-4", attention ? "border-attention" : "border-line", className)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-small leading-5 text-fg-muted">{label}</p>
        {needsAction && <span className="inline-flex shrink-0 items-center gap-1 rounded-control bg-attention-soft px-2 py-0.5 text-micro leading-4 font-medium text-attention-fg"><AlertIcon width={12} height={12} />{actionText}</span>}
      </div>
      <p className="mt-1 text-title-lg leading-9 font-semibold tracking-snug tabular-nums text-fg [overflow-wrap:anywhere]">
        {valid ? <time dateTime={deadline.slice(0, 10)}>{formatDate(deadline.slice(0, 10))}</time> : "—"}
      </p>
      {valid && (
        <p className="mt-1 flex flex-wrap items-center gap-x-2 text-body leading-6 text-fg">
          {missed && <span className="inline-flex items-center gap-1 font-medium"><AlertIcon aria-hidden width={14} height={14} className="shrink-0" />{missedLabel}</span>}
          <span className={cn("tabular-nums", missed ? "text-fg-muted" : "font-medium")}>{missed && <span aria-hidden>{"· "}</span>}{words}</span>
        </p>
      )}
      {showBar && (
        <MeterBar className="mt-3" label="Time used" value={used} max={total} warnAt={attention ? 0 : undefined}
          valueText={`${used} of ${total} days used`} />
      )}
    </div>
  );
}
