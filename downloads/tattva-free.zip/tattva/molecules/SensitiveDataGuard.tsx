import { useId } from "react";
import { cn } from "../lib/cn";
import { headingTag, type HeadingLevel } from "../lib/useFocusAfter";
import { LockIcon } from "../lib/icons";
import type { SensitiveFinding, SensitiveKind } from "../lib/sensitive";
import { Button } from "../atoms/Button";

export interface SensitiveDataGuardLabels {
  /** Receives how many details were found. */
  heading?: (n: number) => string;
  body?: string;
  kinds?: Partial<Record<SensitiveKind, string>>;
  remove?: string;
  removeAll?: string;
  sendAnyway?: string;
}

export interface SensitiveDataGuardProps {
  /** What was found, from findSensitive(text). Nothing shows when the list is empty. */
  findings: SensitiveFinding[];
  /** Takes one detail out of the message. */
  onRemove: (id: string) => void;
  /** Takes every detail out. */
  onRemoveAll: () => void;
  /** Sends the message as it is. */
  onSendAnyway: () => void;
  labels?: SensitiveDataGuardLabels;
  /** Level of the part's heading, so it fits the page outline. Default 3. */
  headingLevel?: HeadingLevel;
  className?: string;
}

const KIND: Record<SensitiveKind, string> = { card: "Card number", key: "API key", password: "Password", email: "Email address", phone: "Phone number" };

/**
 * Sits just above the message box when a message about to be sent holds a private detail: a card number, an API key,
 * a password, an email address or a phone number. It names each one with a safe preview, offers to take it out, and
 * still lets the person send as it is. Taking it out is the main action. Use findSensitive() to fill it.
 */
export function SensitiveDataGuard({ findings, onRemove, onRemoveAll, onSendAnyway, labels, headingLevel = 3, className }: SensitiveDataGuardProps) {
  const l = {
    heading: (n: number) => (n === 1 ? "This message has a private detail" : `This message has ${n} private details`),
    body: "The assistant does not need these to help. Take them out, or send as it is.",
    remove: "Take out", removeAll: "Take them out", sendAnyway: "Send anyway", ...labels,
    kinds: { ...KIND, ...labels?.kinds },
  };
  const uid = useId();
  const H = headingTag(headingLevel);
  if (!findings.length) return null;
  return (
    <section role="status" aria-labelledby={`${uid}-h`} className={cn("rounded-card border border-attention-line bg-attention-soft p-4", className)}>
      <div className="flex items-start gap-2.5">
        <LockIcon aria-hidden width={18} height={18} className="mt-0.5 shrink-0 text-attention-fg" />
        <div className="min-w-0 flex-1">
          <H id={`${uid}-h`} className="m-0 text-body leading-5 font-semibold text-fg">{l.heading(findings.length)}</H>
          <p className="m-0 mt-1 text-small leading-5 text-fg-muted">{l.body}</p>
          <ul className="mt-3 space-y-1.5">
            {findings.map((f) => (
              <li key={f.id} className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="text-small leading-5 text-fg">{l.kinds[f.kind]}</span>
                <span className="font-mono text-small leading-5 text-fg-muted">{f.preview}</span>
                {findings.length > 1 && <Button size="sm" variant="ghost" onClick={() => onRemove(f.id)} aria-label={`${l.remove}: ${l.kinds[f.kind]} ${f.preview}`}>{l.remove}</Button>}
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" onClick={findings.length > 1 ? onRemoveAll : () => onRemove(findings[0].id)}>{findings.length > 1 ? l.removeAll : l.remove}</Button>
            <Button size="sm" variant="ghost" onClick={onSendAnyway}>{l.sendAnyway}</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
