import { useEffect, useId, useRef, useState } from "react";
import type { KeyboardEvent, ReactNode } from "react";
import { Button } from "../atoms/Button";
import { TextField } from "../atoms/TextField";
import { cn } from "../lib/cn";
import { AlertIcon, EditIcon } from "../lib/icons";

export interface InlineEditProps {
  /** Visible label, small and muted. Also the accessible name of the input. */
  label: string;
  value: string;
  /** Called with the new text when the edit is saved. */
  onChange: (value: string) => void;
  /** How to show the value when not editing, such as a Money. Defaults to the text. */
  display?: ReactNode;
  /** Forces the "Edited" tag on or off. When left out, the part compares value with originalValue. */
  edited?: boolean;
  /** The value before anyone changed it. Defaults to the value this part first received. */
  originalValue?: string;
  inputMode?: "text" | "numeric" | "decimal" | "tel" | "email" | "url" | "search";
  /** Returns an error message, or null when the value is fine. On an error the edit stays open. */
  validate?: (value: string) => string | null;
  /** Accessible name of the Edit button. */
  editLabel?: string;
  className?: string;
}

/**
 * "Verify, don't fill in". A value reads as plain text with a visible Edit button. Pressing it turns the value into an
 * input in place. Enter or Done saves, Escape cancels, and a saved change gets an "Edited" tag.
 */
export function InlineEdit({ label, value, onChange, display, edited, originalValue, inputMode, validate, editLabel, className }: InlineEditProps) {
  const uid = useId();
  const labelId = `${uid}-label`, errorId = `${uid}-error`;
  const first = useRef(value);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState("");
  const editBtn = useRef<HTMLButtonElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const back = useRef(false);

  useEffect(() => { if (editing) { input.current?.focus(); input.current?.select(); } }, [editing]);
  // The input is gone after save or cancel, so focus goes back to the Edit button that opened it.
  useEffect(() => { if (!editing && back.current) { back.current = false; editBtn.current?.focus(); } }, [editing]);

  const isEdited = edited ?? value !== (originalValue ?? first.current);

  const start = () => { setDraft(value); setError(null); setSaved(""); setEditing(true); };
  const cancel = () => { back.current = true; setError(null); setEditing(false); };
  const save = () => {
    const err = validate?.(draft) ?? null;
    if (err) { setError(err); input.current?.focus(); return; }
    if (draft !== value) { onChange(draft); setSaved("Saved"); }
    back.current = true;
    setEditing(false);
  };
  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") { e.preventDefault(); save(); }
    else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cancel(); }
  };

  return (
    <div className={cn("border-b border-line py-3 last:border-b-0", className)}>
      <div className="flex items-center gap-2">
        <span id={labelId} className="text-small leading-4 text-fg-muted">{label}</span>
        {isEdited && <span className="rounded-control bg-sunken px-2 py-0.5 text-small leading-4 font-medium text-fg-muted forced-colors:border forced-colors:border-[CanvasText]">Edited</span>}
      </div>
      {editing ? (
        <div className="mt-1.5 flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <TextField ref={input} className="flex-1" aria-labelledby={labelId} aria-describedby={error ? errorId : undefined} invalid={!!error} inputMode={inputMode} value={draft}
              onChange={(e) => { setDraft(e.target.value); if (error) setError(null); }} onKeyDown={onKeyDown} />
            <Button size="sm" className="pointer-coarse:h-11" onClick={save}>Done</Button>
            <Button size="sm" variant="ghost" className="pointer-coarse:h-11" onClick={cancel}>Cancel</Button>
          </div>
          <div id={errorId} aria-live="polite" className="empty:hidden">
            {error && <p className="flex items-start gap-1.5 text-small leading-4 text-danger-fg"><AlertIcon className="mt-px shrink-0" width={14} height={14} />{error}</p>}
          </div>
        </div>
      ) : (
        <div className="mt-0.5 flex items-center justify-between gap-3">
          <div className="min-w-0 text-lead leading-6 font-medium text-fg">{display ?? (value || <span className="font-normal text-fg-muted">Not set</span>)}</div>
          <button ref={editBtn} type="button" aria-label={editLabel ?? `Edit ${label}`} onClick={start}
            className="inline-flex min-h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-control px-3 text-body leading-5 font-medium text-fg underline underline-offset-4 transition-colors duration-[var(--dur-fast)] hover:bg-hover tap">
            <EditIcon width={14} height={14} />Edit
          </button>
        </div>
      )}
      <p role="status" aria-live="polite" className="sr-only">{saved}</p>
    </div>
  );
}
