import { useEffect, useId, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { ChevronIcon } from "../lib/icons";
import { usePresence } from "../hooks/usePresence";

export interface CollapsibleProps {
  header: ReactNode;
  children: ReactNode;
  defaultOpen?: boolean;
  className?: string;
}

/**
 * A header that shows and hides what is under it. The content grows open in --dur-base and closes faster in --dur-fast.
 * Closed content is hidden from everyone, not just from sight. Under reduced motion it simply appears.
 */
export function Collapsible({ header, children, defaultOpen = false, className }: CollapsibleProps) {
  const [open, setOpen] = useState(defaultOpen);
  const id = useId();
  const { present } = usePresence(open);
  // `shown` turns on one frame after the content mounts, so the height has a closed state to grow from.
  const [shown, setShown] = useState(defaultOpen);
  // Clipping is only needed while the height moves; once open, focus rings inside are not cut off.
  const [settled, setSettled] = useState(defaultOpen);
  useEffect(() => {
    setSettled(false);
    if (!open) { setShown(false); return; }
    const r = requestAnimationFrame(() => setShown(true));
    return () => cancelAnimationFrame(r);
  }, [open]);
  return (
    <div className={className}>
      <button type="button" aria-expanded={open} aria-controls={id} onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-2 text-left">
        <ChevronIcon className={cn("shrink-0 text-fg-subtle transition-transform duration-[var(--dur-fast)]", open && "rotate-90")} />
        {header}
      </button>
      <div id={id} hidden={!present} onTransitionEnd={(e) => { if (e.target === e.currentTarget && open) setSettled(true); }}
        className={cn("grid transition-[grid-template-rows,opacity] ease-(--ease-arrive)", shown ? "grid-rows-[1fr] opacity-100 duration-(--dur-base)" : "grid-rows-[0fr] opacity-0 duration-(--dur-fast)")}>
        <div className={cn("min-h-0", !(shown && settled) && "overflow-hidden")}>{children}</div>
      </div>
    </div>
  );
}
