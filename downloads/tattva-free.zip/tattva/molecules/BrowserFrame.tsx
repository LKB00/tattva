import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface BrowserFrameProps {
  children: ReactNode;
  /** "browser" shows an address; "app" a title, for a desktop app; "plain" no bar, for a quiet card. */
  variant?: "browser" | "app" | "plain";
  /** The address or window title, short: "acme.app/chat". */
  title?: string;
  className?: string;
}

/**
 * A quiet window around a faux product: a thin bar with the address or title, a border, and nothing that lifts.
 * It frames the product without shrinking a whole app into a card: show the one screen the story needs.
 */
export function BrowserFrame({ children, variant = "browser", title, className }: BrowserFrameProps) {
  return (
    <div className={cn("flex w-full flex-col overflow-hidden rounded-card border border-line bg-surface", className)}>
      {variant !== "plain" && (
        <div className="flex h-9 shrink-0 items-center gap-3 border-b border-line px-3">
          <span aria-hidden="true" className="flex gap-1.5">{[0, 1, 2].map((i) => <span key={i} className="size-2 rounded-full bg-line-strong" />)}</span>
          {title && (variant === "browser"
            ? <span className="mx-auto min-w-0 truncate rounded-control bg-sunken px-3 py-0.5 text-small leading-4 text-fg-muted">{title}</span>
            : <span className="mx-auto min-w-0 truncate text-small leading-4 font-medium text-fg-muted">{title}</span>)}
          <span aria-hidden="true" className="w-9" />
        </div>
      )}
      <div className="relative min-h-0 flex-1">{children}</div>
    </div>
  );
}
