import { useId, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { headingTag, subHeadingTag, type HeadingLevel } from "../lib/useFocusAfter";
import { AlertIcon, EditIcon, EyeIcon, SendIcon } from "../lib/icons";
import { Badge } from "../atoms/Badge";
import { Button } from "../atoms/Button";
import { InlineConfirm } from "./InlineConfirm";

export type AccessLevel = "read" | "write" | "send" | "delete";

export interface ConnectorAccess {
  id: string;
  /** What it can do, in plain words: "Read your email". */
  label: string;
  level: AccessLevel;
}

export interface ConnectorPermissionLabels {
  status?: Partial<Record<"connected" | "off" | "expired", string>>;
  canHeading?: string;
  levels?: Partial<Record<AccessLevel, string>>;
  connect?: string;
  reconnect?: string;
  disconnect?: string;
  /** Receives the app name. */
  disconnectQuestion?: (app: string) => string;
  keep?: string;
  /** Receives when it was last used. */
  lastUsed?: (when: string) => string;
}

export interface ConnectorPermissionProps {
  /** The app's name, such as Gmail. */
  app: string;
  /** The app's logo, about 24px. */
  icon?: ReactNode;
  /** Which account it is connected to. */
  account?: string;
  status: "connected" | "off" | "expired";
  /** What the assistant can do with it, one line each. */
  access: ConnectorAccess[];
  /** When the assistant last used it, such as "2 hours ago". */
  lastUsed?: string;
  onConnect?: () => void;
  onDisconnect?: () => void;
  labels?: ConnectorPermissionLabels;
  /** Level of the part's heading, so it fits the page outline. Default 3. */
  headingLevel?: HeadingLevel;
  className?: string;
}

const LEVEL_ICON: Record<AccessLevel, typeof EyeIcon> = { read: EyeIcon, write: EditIcon, send: SendIcon, delete: AlertIcon };

/**
 * One connected app, and exactly what the assistant can do with it. Each line says the action in plain words with a
 * mark for how far it reaches (see, change, send, delete); deleting stands out. Disconnecting asks once, in place.
 * An expired connection says so and offers to reconnect, instead of failing quietly.
 */
export function ConnectorPermission({ app, icon, account, status, access, lastUsed, onConnect, onDisconnect, labels, headingLevel = 3, className }: ConnectorPermissionProps) {
  const l = {
    canHeading: "The assistant can", connect: "Connect", reconnect: "Reconnect", disconnect: "Disconnect", keep: "Keep it",
    disconnectQuestion: (a: string) => `Disconnect ${a}?`, lastUsed: (w: string) => `Last used ${w}`, ...labels,
    status: { connected: "Connected", off: "Not connected", expired: "Needs you to sign in again", ...labels?.status },
    levels: { read: "See", write: "Change", send: "Send", delete: "Delete", ...labels?.levels },
  };
  const uid = useId();
  const H = headingTag(headingLevel);
  const H2 = subHeadingTag(headingLevel);
  const tone = status === "connected" ? "success" : status === "expired" ? "warning" : "neutral";
  return (
    <section aria-labelledby={`${uid}-h`} className={cn("rounded-card border border-line bg-surface p-4", className)}>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        {icon && <span aria-hidden className="grid size-9 shrink-0 place-items-center rounded-control border border-line bg-bg">{icon}</span>}
        <div className="min-w-0 flex-1">
          <H id={`${uid}-h`} className="m-0 text-body leading-5 font-semibold text-fg">{app}</H>
          {account && <p className="m-0 truncate text-small leading-5 text-fg-muted">{account}</p>}
        </div>
        <Badge tone={tone}>{l.status[status]}</Badge>
      </div>
      {status !== "off" && access.length > 0 && (
        <div className="mt-4">
          <H2 className="m-0 text-small leading-4 font-medium text-fg-muted">{l.canHeading}</H2>
          <ul className="mt-2 space-y-2">
            {access.map((a) => {
              const Icon = LEVEL_ICON[a.level];
              return (
                <li key={a.id} className="flex items-start gap-2.5">
                  <Icon aria-hidden width={16} height={16} className={cn("mt-0.5 shrink-0", a.level === "delete" ? "text-danger-fg" : "text-fg-muted")} />
                  <span className="min-w-0 flex-1 text-body leading-6 text-fg">{a.label}</span>
                  <span className={cn("shrink-0 text-small leading-6", a.level === "delete" ? "font-medium text-danger-fg" : "text-fg-muted")}>{l.levels[a.level]}</span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      {lastUsed && status === "connected" && <p className="m-0 mt-4 text-small leading-5 text-fg-muted">{l.lastUsed(lastUsed)}</p>}
      <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-2">
        {status === "connected" && onDisconnect && (
          <InlineConfirm onConfirm={onDisconnect} confirmLabel={l.disconnect} cancelLabel={l.keep} question={l.disconnectQuestion(app)} tone="danger">{l.disconnect}</InlineConfirm>
        )}
        {status !== "connected" && onConnect && <Button size="sm" onClick={onConnect}>{status === "expired" ? l.reconnect : l.connect}</Button>}
      </div>
    </section>
  );
}
