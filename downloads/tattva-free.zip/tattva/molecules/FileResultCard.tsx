import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { AlertIcon, DownloadIcon, FileIcon, ImageIcon } from "../lib/icons";
import { Button } from "../atoms/Button";
import { Spinner } from "../atoms/Spinner";

export type FileKind = "document" | "sheet" | "slides" | "pdf" | "image" | "code" | "file";

export interface FileResultCardLabels {
  kinds?: Partial<Record<FileKind, string>>;
  open?: string;
  download?: string;
  retry?: string;
  /** Receives the file name. */
  making?: (name: string) => string;
  failed?: string;
}

export interface FileResultCardProps {
  /** The file's name, with its extension: "Q3 report.docx". */
  name: string;
  /** What kind of file it is. Worked out from the extension when omitted. */
  kind?: FileKind;
  /** Size or length, such as "24 KB" or "8 slides". */
  detail?: string;
  /** A small picture of the first page or the image itself. */
  preview?: ReactNode;
  status?: "ready" | "making" | "failed";
  /** Opens the file in the app (a canvas or a viewer). The button is hidden when omitted. */
  onOpen?: () => void;
  /** Downloads the file. The button is hidden when omitted. */
  onDownload?: () => void;
  /** Tries again after a failure. */
  onRetry?: () => void;
  labels?: FileResultCardLabels;
  className?: string;
}

const BY_EXT: Record<string, FileKind> = {
  doc: "document", docx: "document", md: "document", txt: "document", rtf: "document", odt: "document",
  xls: "sheet", xlsx: "sheet", csv: "sheet", ods: "sheet",
  ppt: "slides", pptx: "slides", key: "slides", odp: "slides",
  pdf: "pdf",
  png: "image", jpg: "image", jpeg: "image", gif: "image", webp: "image", svg: "image",
  js: "code", ts: "code", tsx: "code", py: "code", json: "code", html: "code", css: "code", sql: "code",
};
const KIND: Record<FileKind, string> = { document: "Document", sheet: "Spreadsheet", slides: "Slides", pdf: "PDF", image: "Image", code: "Code", file: "File" };

/** What kind of file a name is, from its extension. */
export const fileKindOf = (name: string): FileKind => BY_EXT[name.split(".").pop()?.toLowerCase() ?? ""] ?? "file";

/**
 * A file the AI made: a report, a spreadsheet, slides or an image. It shows what kind of file it is in words, a
 * small preview when there is one, and Open and Download. While the file is being made it says so; if making it
 * failed, it says so and offers to try again, instead of a broken link.
 */
export function FileResultCard({ name, kind, detail, preview, status = "ready", onOpen, onDownload, onRetry, labels, className }: FileResultCardProps) {
  const l = {
    open: "Open", download: "Download", retry: "Try again", making: (n: string) => `Making ${n}`, failed: "Could not make this file.", ...labels,
    kinds: { ...KIND, ...labels?.kinds },
  };
  const k = kind ?? fileKindOf(name);
  const Icon = k === "image" ? ImageIcon : FileIcon;
  return (
    <div className={cn("flex w-full max-w-md items-center gap-3 rounded-card border border-line bg-surface p-3", className)} aria-busy={status === "making" || undefined}>
      <div aria-hidden className="grid size-14 shrink-0 place-items-center overflow-hidden rounded-control border border-line bg-bg text-fg-muted">
        {status === "making" ? <Spinner label="" /> : preview ?? <Icon width={22} height={22} />}
      </div>
      <div className="min-w-0 flex-1">
        <p className="m-0 truncate text-body leading-5 font-medium text-fg" title={name}>{name}</p>
        <p className={cn("m-0 mt-0.5 text-small leading-5", status === "failed" ? "text-danger-fg" : "text-fg-muted")} role={status === "making" || status === "failed" ? "status" : undefined}>
          {status === "making" ? l.making(name) : status === "failed"
            ? <span className="inline-flex items-center gap-1"><AlertIcon aria-hidden width={13} height={13} />{l.failed}</span>
            : [l.kinds[k], detail].filter(Boolean).join(" · ")}
        </p>
      </div>
      {status === "ready" && (onOpen || onDownload) && (
        <div className="flex shrink-0 flex-wrap justify-end gap-1.5">
          {onOpen && <Button size="sm" variant="secondary" onClick={onOpen} aria-label={`${l.open} ${name}`}>{l.open}</Button>}
          {onDownload && <Button size="sm" variant="ghost" onClick={onDownload} aria-label={`${l.download} ${name}`} leading={<DownloadIcon aria-hidden width={14} height={14} />}>{l.download}</Button>}
        </div>
      )}
      {status === "failed" && onRetry && <Button size="sm" variant="secondary" onClick={onRetry} className="shrink-0">{l.retry}</Button>}
    </div>
  );
}
