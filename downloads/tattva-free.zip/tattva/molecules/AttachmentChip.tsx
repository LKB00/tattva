import { useRef, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { keepFocus, useAnnounceChange } from "../lib/focus";
import { FileIcon, ImageIcon, XIcon } from "../lib/icons";
import { Button, IconButton } from "../atoms/Button";
import { MeterBar } from "../atoms/MeterBar";

export type AttachmentStatus = "ready" | "uploading" | "error";

export interface AttachmentChipProps {
  /** File name. */
  name: string;
  /** Display size such as "2.4 MB". */
  size?: string;
  /** Picks the default icon when no thumbnail is given. */
  kind?: "file" | "image";
  /** Replaces the default icon, for example an img element. Keep it decorative. */
  thumbnail?: ReactNode;
  status?: AttachmentStatus;
  /** Upload progress from 0 to 100. Used while status is "uploading". */
  progress?: number;
  /** Text shown when status is "error". */
  errorMessage?: string;
  /** Shows a Retry button in the error state. */
  onRetry?: () => void;
  /** Shows the remove button. The button is named after the file. */
  onRemove?: () => void;
  /** Where keyboard focus goes after Remove. By default the next attachment, else the previous one, else the message box. */
  focusAfterRemove?: () => HTMLElement | null;
  /** What screen readers hear when the upload finishes. Defaults to "(name) uploaded". */
  readyMessage?: string;
  className?: string;
}

/** File or image chip for the composer. Shows upload progress as a meter and a retry action when the upload fails. */
export function AttachmentChip({ name, size, kind = "file", thumbnail, status = "ready", progress = 0, errorMessage = "Upload failed", onRetry, onRemove, focusAfterRemove, readyMessage, className }: AttachmentChipProps) {
  const ref = useRef<HTMLDivElement>(null);
  // Uploads finishing or failing are read out; the chip appearing is not.
  const said = useAnnounceChange(status, (now) => (now === "ready" ? readyMessage ?? `${name} uploaded` : now === "error" ? `${name}: ${errorMessage}` : ""));
  const pct = Math.round(Math.max(0, Math.min(100, progress)));
  const Icon = kind === "image" ? ImageIcon : FileIcon;
  return (
    <div ref={ref} className={cn("flex w-64 max-w-full items-center gap-2.5 rounded-card border bg-surface p-2", status === "error" ? "border-danger-line" : "border-line", className)}>
      <span className="flex size-10 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-sunken text-fg-muted">
        {thumbnail ?? <Icon width={18} height={18} />}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-compact font-medium text-fg" title={name}>{name}</span>
        {status === "ready" && size && <span className="block text-small leading-4 text-fg-muted">{size}</span>}
        {status === "uploading" && (
          <span className="mt-1 block">
            <MeterBar value={pct} label={`Uploading ${name}`} valueText={`${pct}% uploaded`} />
            <span className="mt-1 block text-small leading-4 text-fg-muted tabular-nums">Uploading {pct}%{size ? ` of ${size}` : ""}</span>
          </span>
        )}
        {status === "error" && <span className="block truncate text-small leading-4 text-danger-fg">{errorMessage}</span>}
      </span>
      {status === "error" && onRetry && <Button size="sm" variant="secondary" onClick={onRetry} aria-label={`Retry upload of ${name}`}>Retry</Button>}
      {onRemove && (
        <IconButton label={`Remove ${name}`} size="sm" onClick={() => { onRemove(); keepFocus(ref.current, focusAfterRemove); }}><XIcon width={14} height={14} /></IconButton>
      )}
      <span role="status" aria-live="polite" className="sr-only">{said}</span>
    </div>
  );
}
