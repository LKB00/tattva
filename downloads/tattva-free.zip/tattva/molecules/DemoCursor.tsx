import { cn } from "../lib/cn";

export interface DemoCursorProps {
  /** Where the tip is, as a percentage of the nearest positioned box (0 to 100). */
  x: number;
  y: number;
  /** Pressing: the cursor dips and a soft ring shows the click. */
  pressed?: boolean;
  /** Arrow over the page, pointer over something clickable. */
  shape?: "arrow" | "pointer";
  hidden?: boolean;
  className?: string;
}

/**
 * A cursor for faux UI demos. It glides to where the script sends it on a shallow curve (across and down move on
 * different easings), and presses visibly, so every change on screen has a cause the viewer can see. Drawn in the
 * ink colour with a paper outline, so it reads on light and dark grounds.
 */
export function DemoCursor({ x, y, pressed = false, shape = "arrow", hidden = false, className }: DemoCursorProps) {
  return (
    <span aria-hidden="true"
      className={cn("pointer-events-none absolute z-10 block size-6 [transition:left_var(--dur-demo)_cubic-bezier(.2,.7,.3,1),top_var(--dur-demo)_cubic-bezier(.6,0,.4,1),opacity_var(--dur-base)] motion-reduce:transition-none", hidden && "opacity-0", className)}
      style={{ left: `${x}%`, top: `${y}%` }}>
      {pressed && <span className="absolute -top-2.5 -left-2.5 size-5 animate-ping rounded-full border-2 border-fg opacity-60 motion-reduce:animate-none" />}
      <svg viewBox="0 0 24 24" className={cn("size-6 transition-transform duration-[var(--dur-fast)]", pressed && "scale-90")} style={{ transformOrigin: "2px 2px" }}>
        {shape === "arrow"
          ? <path d="M3 2l15 9-6.5 1.6L8.6 19z" fill="var(--fg)" stroke="var(--bg)" strokeWidth="1.5" strokeLinejoin="round" />
          : <path d="M9 3.5a1.5 1.5 0 013 0V10l.6-.2a1.6 1.6 0 012.1 1.2l.1.3.7-.2a1.6 1.6 0 012 1.4l.7-.1a1.5 1.5 0 011.7 1.5V17a5 5 0 01-5 5h-1.6a5 5 0 01-4-2l-3.1-4.2a1.6 1.6 0 012.4-2.1L9 14z" fill="var(--fg)" stroke="var(--bg)" strokeWidth="1.3" strokeLinejoin="round" />}
      </svg>
    </span>
  );
}
