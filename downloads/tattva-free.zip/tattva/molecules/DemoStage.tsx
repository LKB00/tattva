import type { ReactNode, Ref } from "react";
import { cn } from "../lib/cn";

export interface DemoStageProps {
  children: ReactNode;
  /** Shape of the stage. */
  ratio?: "16:9" | "4:3" | "1:1" | "4:5";
  /** The ground behind the product: the sunken page colour, the card surface, or the soft AI wash. */
  tone?: "sunken" | "surface" | "wash";
  /** Let the framed product run off the bottom edge, so it reads as part of something bigger. */
  bleed?: boolean;
  /** One line that says what the demo shows, for people who cannot see it. */
  label: string;
  ref?: Ref<HTMLDivElement>;
  className?: string;
}

const RATIO = { "16:9": "aspect-video", "4:3": "aspect-[4/3]", "1:1": "aspect-square", "4:5": "aspect-[4/5]" };
const TONE = { sunken: "bg-sunken", surface: "bg-surface", wash: "bg-[var(--ai-wash-1)]" };

/**
 * The canvas a faux UI demo sits on: a fixed shape, a quiet ground and room around the product. The product inside
 * is simplified to what the viewer needs. The stage is a figure: it carries a label, and its inner workings are
 * hidden from screen readers so the demo is described once, in words.
 */
export function DemoStage({ children, ratio = "16:9", tone = "sunken", bleed = false, label, ref, className }: DemoStageProps) {
  return (
    <figure ref={ref} className={cn("relative m-0 w-full overflow-hidden rounded-card", RATIO[ratio], TONE[tone], className)}>
      <div aria-hidden="true" className={cn("absolute inset-0 flex justify-center px-[6%]", bleed ? "items-start pt-[6%]" : "items-center py-[6%]")}>
        {children}
      </div>
      <figcaption className="sr-only">{label}</figcaption>
    </figure>
  );
}
