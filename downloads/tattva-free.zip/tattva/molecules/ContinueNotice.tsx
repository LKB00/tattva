import { cn } from "../lib/cn";
import { InfoIcon, AlertIcon } from "../lib/icons";
import { Button } from "../atoms/Button";

export interface ContinueNoticeLabels {
  length?: string;
  stopped?: string;
  lost?: string;
  continue?: string;
  retry?: string;
}

export interface ContinueNoticeProps {
  /** Why the reply ended early: it hit the length limit, the person pressed Stop, or the connection dropped. */
  reason: "length" | "stopped" | "lost";
  /** Picks up where the reply ended (or, after a lost connection, tries again). */
  onContinue: () => void;
  /** True while the continuation is starting. The button keeps its place and ignores presses. */
  busy?: boolean;
  labels?: ContinueNoticeLabels;
  className?: string;
}

/**
 * One quiet line under a reply that ended early, saying why in plain words and offering to carry on. A reply cut
 * off by the length limit otherwise just stops mid-sentence, and people cannot tell whether it finished.
 */
export function ContinueNotice({ reason, onContinue, busy, labels, className }: ContinueNoticeProps) {
  const l = {
    length: "The reply stopped at the length limit.", stopped: "You stopped this reply.", lost: "The connection dropped before the reply finished.",
    continue: "Continue", retry: "Try again", ...labels,
  };
  const Icon = reason === "lost" ? AlertIcon : InfoIcon;
  return (
    <div className={cn("flex flex-wrap items-center gap-x-3 gap-y-2", className)}>
      <p className="m-0 inline-flex items-center gap-1.5 text-small leading-5 text-fg-muted">
        <Icon aria-hidden width={14} height={14} className="shrink-0" />{l[reason]}
      </p>
      <Button size="sm" variant="secondary" busy={busy} busyLabel={reason === "lost" ? l.retry : l.continue} onClick={onContinue}>{reason === "lost" ? l.retry : l.continue}</Button>
    </div>
  );
}
