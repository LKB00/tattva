import { useId } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface RadioOption {
  value: string;
  label: ReactNode;
  /** Visible hint under the label. */
  description?: string;
  disabled?: boolean;
}

export interface RadioGroupProps {
  options: RadioOption[];
  value: string;
  onChange: (value: string) => void;
  /** Name of the group, shown as the legend. */
  label: string;
  /** Hides the legend visually. Screen readers still hear it. */
  hideLabel?: boolean;
  orientation?: "vertical" | "horizontal";
  /** Marks every radio as having an error (red border, aria-invalid). Show the error text yourself. */
  invalid?: boolean;
  disabled?: boolean;
  /** Shared by all radios, which is what gives the browser its arrow-key behaviour. Defaults to a generated one. */
  name?: string;
  className?: string;
}

/** Controlled group of native radios in a fieldset. The browser handles Tab and the arrow keys. */
export function RadioGroup({ options, value, onChange, label, hideLabel, orientation = "vertical", invalid, disabled, name, className }: RadioGroupProps) {
  const auto = useId();
  const groupName = name ?? auto;
  return (
    <fieldset disabled={disabled} className={cn("min-w-0 border-0 p-0 m-0", className)}>
      <legend className={cn("mb-2 p-0 text-body leading-5 font-medium text-fg", hideLabel && "sr-only")}>{label}</legend>
      <div className={cn("flex gap-x-6 gap-y-2", orientation === "vertical" ? "flex-col" : "flex-row flex-wrap")}>
        {options.map((o) => <Radio key={o.value} name={groupName} option={o} checked={o.value === value} invalid={invalid} onSelect={onChange} />)}
      </div>
    </fieldset>
  );
}

function Radio({ name, option, checked, invalid, onSelect }: { name: string; option: RadioOption; checked: boolean; invalid?: boolean; onSelect: (v: string) => void }) {
  const labelId = useId();
  const descId = useId();
  return (
    <label className={cn("inline-flex items-start gap-3 text-body leading-5 text-fg pointer-coarse:min-h-11 pointer-coarse:items-center", option.disabled ? "cursor-not-allowed opacity-(--disabled-opacity)" : "cursor-pointer")}>
      <span className="relative mt-0.5 inline-grid size-5 shrink-0 place-items-center pointer-coarse:mt-0">
        <input type="radio" name={name} value={option.value} checked={checked} disabled={option.disabled}
          aria-invalid={invalid || undefined} aria-labelledby={labelId} aria-describedby={option.description ? descId : undefined}
          onChange={() => onSelect(option.value)}
          className={cn("peer size-5 shrink-0 appearance-none rounded-full border bg-surface transition-colors duration-[var(--dur-fast)] checked:border-accent forced-colors:border-[ButtonText] forced-colors:checked:border-[Highlight]",
            invalid ? "border-danger" : "border-line-strong", option.disabled ? "cursor-not-allowed" : "cursor-pointer")} />
        <span aria-hidden className="pointer-events-none absolute size-2.5 scale-0 rounded-full bg-accent transition-transform duration-[var(--dur-fast)] peer-checked:scale-100 forced-colors:bg-[Highlight]" />
      </span>
      <span className="flex min-w-0 flex-col">
        <span id={labelId}>{option.label}</span>
        {option.description && <span id={descId} className="text-fg-muted">{option.description}</span>}
      </span>
    </label>
  );
}
