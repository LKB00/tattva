import type { ReactNode } from "react";
import { cn } from "../lib/cn";

export interface PhoneFrameProps {
  children: ReactNode;
  /** The time in the status bar. */
  time?: string;
  className?: string;
}

/**
 * A phone around a faux mobile screen: a rounded body, a status bar and the screen. Put it on a DemoStage with bleed
 * to crop it at the bottom edge, so the viewer reads it as a phone without the whole device in view.
 */
export function PhoneFrame({ children, time = "9:41", className }: PhoneFrameProps) {
  return (
    <div className={cn("w-[min(100%,300px)] shrink-0 rounded-(--radius-device) border border-line-strong bg-surface p-2", className)}>
      <div className="overflow-hidden rounded-(--radius-device-inner) border border-line bg-bg">
        <div className="flex h-7 items-center justify-between px-5 text-micro font-semibold tabular-nums text-fg">
          <span>{time}</span>
          <span aria-hidden="true" className="flex items-center gap-1"><span className="h-2 w-3 rounded-2xs bg-fg" /><span className="h-2 w-4 rounded-2xs border border-fg" /></span>
        </div>
        <div className="relative">{children}</div>
      </div>
    </div>
  );
}
