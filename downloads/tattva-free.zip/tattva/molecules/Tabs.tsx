import { useEffect, useId, useRef, type KeyboardEvent, type ReactNode } from "react";
import { useScrollEdges } from "../hooks/useScrollEdges";
import { useIndicator } from "../hooks/useIndicator";
import { cn } from "../lib/cn";

export interface TabItem {
  id: string;
  label: ReactNode;
  /** A number shown after the label, such as unread items. */
  count?: number;
  disabled?: boolean;
  /** Content for this tab. Only the active tab's panel is rendered. */
  panel?: ReactNode;
}

export interface TabsProps {
  tabs: TabItem[];
  /** Id of the active tab. */
  value: string;
  onChange: (id: string) => void;
  /** Accessible name of the tab list. */
  label: string;
  variant?: "underline" | "pill";
  /** auto selects a tab when arrow keys reach it. manual only moves focus; Enter or Space selects. */
  activation?: "auto" | "manual";
  /** Tabs share the full width instead of sizing to their label. */
  fill?: boolean;
  className?: string;
}

/**
 * WAI-ARIA tabs. One tab stop (the active tab), arrow keys, Home and End move between tabs. On narrow screens the
 * list scrolls sideways with no visible scrollbar and keeps the active tab in view. Only the active panel is mounted.
 */
export function Tabs({ tabs, value, onChange, label, variant = "underline", activation = "auto", fill, className }: TabsProps) {
  const uid = useId();
  const list = useRef<HTMLDivElement>(null);
  const tabId = (id: string) => `${uid}-tab-${id}`;
  const panelId = (id: string) => `${uid}-panel-${id}`;
  const edges = useScrollEdges(list);
  const mark = useIndicator(list, '[role="tab"][aria-selected="true"]', value);
  const enabled = tabs.filter((t) => !t.disabled);
  const active = tabs.find((t) => t.id === value);
  // If value matches nothing, the first enabled tab takes the tab stop so the list stays reachable.
  const stop = active && !active.disabled ? active.id : enabled[0]?.id;

  useEffect(() => {
    const l = list.current;
    const el = l?.querySelector<HTMLElement>('[aria-selected="true"]');
    if (!l || !el) return;
    const a = l.getBoundingClientRect(); const b = el.getBoundingClientRect();
    if (b.left < a.left) l.scrollLeft += b.left - a.left;
    else if (b.right > a.right) l.scrollLeft += b.right - a.right;
  }, [value]);

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key) || !enabled.length) return;
    const cur = enabled.findIndex((t) => tabId(t.id) === (document.activeElement as HTMLElement | null)?.id);
    const n = enabled.length;
    const j = e.key === "Home" ? 0 : e.key === "End" ? n - 1 : e.key === "ArrowRight" ? (cur + 1) % n : (cur < 0 ? 0 : (cur - 1 + n) % n);
    e.preventDefault();
    const next = enabled[j];
    document.getElementById(tabId(next.id))?.focus();
    if (activation === "auto") onChange(next.id);
  };

  return (
    <div className={className}>
      <div ref={list} role="tablist" aria-label={label} onKeyDown={onKey} style={edges}
        className={cn("relative flex overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden", variant === "underline" ? "gap-1 border-b border-line sm:gap-4" : "gap-1")}>
        {mark && (
          <span aria-hidden style={variant === "underline" ? { ...mark, top: undefined, bottom: 0, height: 2 } : mark}
            className={cn("pointer-events-none forced-colors:hidden", variant === "underline" ? "rounded-full bg-fg" : "rounded-control bg-accent")} />
        )}
        {tabs.map((t) => {
          const on = t.id === value;
          return (
            <button key={t.id} type="button" role="tab" id={tabId(t.id)} aria-selected={on} disabled={t.disabled}
              aria-controls={on && t.panel !== undefined ? panelId(t.id) : undefined} tabIndex={t.id === stop ? 0 : -1}
              onClick={() => { if (!t.disabled) onChange(t.id); }}
              className={cn(
                "relative inline-flex shrink-0 cursor-pointer items-center justify-center gap-1.5 whitespace-nowrap text-body font-medium transition-colors duration-[var(--dur-fast)] focus-visible:outline-offset-[-2px] disabled:cursor-not-allowed disabled:text-disabled-fg pointer-coarse:h-11",
                fill && "flex-1",
                variant === "underline"
                  ? cn("h-10 border-b-2 px-3", on ? cn(mark ? "border-transparent" : "border-fg", "text-fg forced-colors:border-[Highlight] forced-colors:text-[Highlight]") : "border-transparent text-fg-muted hover:text-fg forced-colors:border-transparent")
                  : cn("h-9 rounded-control px-4", on ? cn(!mark && "bg-accent", "text-on-accent forced-colors:bg-[Highlight] forced-colors:text-[HighlightText]") : "text-fg-muted hover:bg-hover hover:text-fg"),
              )}>
              {t.label}
              {t.count !== undefined && <span className="text-small leading-4 tabular-nums opacity-80">{t.count}</span>}
            </button>
          );
        })}
      </div>
      {active?.panel !== undefined && (
        <div key={active.id} role="tabpanel" id={panelId(active.id)} aria-labelledby={tabId(active.id)} tabIndex={0} className="animate-panel-in pt-4">{active.panel}</div>
      )}
    </div>
  );
}
