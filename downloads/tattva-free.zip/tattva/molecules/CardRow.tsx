import { Children, type ReactNode } from "react";
import { cn } from "../lib/cn";

export interface CardRowProps {
  /** Names the group for screen readers: "Hotels in Paris". */
  label: string;
  /** Two or more ResultCards with the same fields. */
  children: ReactNode;
  /** Narrowest a card may get on wide screens before the row wraps, in the spacing scale (60 is 240px). */
  minCardWidth?: 52 | 60 | 72;
  className?: string;
}

const MIN: Record<NonNullable<CardRowProps["minCardWidth"]>, string> = {
  52: "sm:grid-cols-[repeat(auto-fill,minmax(calc(var(--spacing)*52),1fr))]",
  60: "sm:grid-cols-[repeat(auto-fill,minmax(calc(var(--spacing)*60),1fr))]",
  72: "sm:grid-cols-[repeat(auto-fill,minmax(calc(var(--spacing)*72),1fr))]",
};

/**
 * Two or more results of the same kind side by side: a grid on wide screens and a row that swipes sideways on a
 * phone, with the next card peeking in so people can tell there is more. A list, so its length is announced.
 */
export function CardRow({ label, children, minCardWidth = 60, className }: CardRowProps) {
  const items = Children.toArray(children);
  return (
    <ul aria-label={label} tabIndex={0}
      className={cn(
        "m-0 flex list-none snap-x snap-mandatory gap-3 overflow-x-auto p-0 pb-2 [scrollbar-width:thin] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--focus-ring)]",
        "sm:grid sm:snap-none sm:overflow-visible sm:pb-0", MIN[minCardWidth], className,
      )}>
      {/* On a phone the next card peeks in to show there is more; a single card takes the full width. */}
      {items.map((child, i) => (
        <li key={i} className={cn("flex shrink-0 snap-start sm:w-auto", items.length > 1 ? "w-[85%]" : "w-full")}>{child}</li>
      ))}
    </ul>
  );
}
