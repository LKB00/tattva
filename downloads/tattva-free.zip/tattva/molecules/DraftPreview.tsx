import { useEffect, useId, useRef, useState } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { ChevronIcon } from "../lib/icons";

export interface DraftHeader {
  label: string;
  value: ReactNode;
}

export interface DraftPreviewProps {
  /** Rows like To, From and Subject, drawn as a labelled list above the body. */
  headers?: DraftHeader[];
  /** The body text. */
  children: ReactNode;
  /** Shown in the expand button, such as "Read all 95 words". */
  wordCount?: number;
  /** How many lines show before the text fades out. */
  previewLines?: number;
  defaultOpen?: boolean;
  /** Controlled open state. Pair with onOpenChange. */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Text of the expand button. */
  expandLabel?: (words: number | undefined) => string;
  /** Text of the collapse button. */
  collapseLabel?: string;
  /** A line under the message, such as "Nothing goes out without your tap." */
  footer?: ReactNode;
  className?: string;
}

const LINE = 1.625;
const defaultExpand = (words: number | undefined) => (words === undefined ? "Read all" : `Read all ${words} words`);

/** A drafted message shown as what it is, with headers and a body, so no one approves text they have not read. It never opens by itself. */
export function DraftPreview({ headers, children, wordCount, previewLines = 4, defaultOpen = false, open, onOpenChange, expandLabel = defaultExpand, collapseLabel = "Show less", footer, className }: DraftPreviewProps) {
  const [inner, setInner] = useState(defaultOpen);
  const isOpen = open ?? inner;
  const [overflows, setOverflows] = useState(true);
  const bodyRef = useRef<HTMLDivElement>(null);
  const id = useId();

  useEffect(() => {
    const el = bodyRef.current;
    if (!el || isOpen) return;
    const measure = () => setOverflows(el.scrollHeight > el.clientHeight + 1);
    measure();
    const ro = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    ro?.observe(el);
    return () => ro?.disconnect();
  }, [isOpen, previewLines, children]);

  const toggle = () => { const next = !isOpen; if (open === undefined) setInner(next); onOpenChange?.(next); };
  const clamped = !isOpen && overflows;
  return (
    <section className={cn("min-w-0 overflow-hidden rounded-card border border-line bg-surface forced-colors:border-[CanvasText]", className)}>
      {headers && headers.length > 0 && (
        <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 border-b border-line bg-sunken px-4 py-3 text-body leading-5">
          {headers.map((h) => (
            <div key={h.label} className="col-span-2 grid grid-cols-subgrid items-baseline">
              <dt className="text-fg-muted">{h.label}</dt>
              <dd className="m-0 min-w-0 text-fg [overflow-wrap:anywhere]">{h.value}</dd>
            </div>
          ))}
        </dl>
      )}
      <div className="px-4 py-3">
        <div className="relative">
          <div ref={bodyRef} id={id} className={cn("text-body leading-5 text-fg [overflow-wrap:anywhere]", !isOpen && "overflow-hidden")}
            style={{ lineHeight: LINE, maxHeight: isOpen ? undefined : `${previewLines * LINE}em` }}>{children}</div>
          {clamped && <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-linear-to-t from-surface to-transparent" />}
        </div>
        {(overflows || isOpen) && (
          <button type="button" aria-expanded={isOpen} aria-controls={id} onClick={toggle}
            className="mt-2 inline-flex min-h-6 cursor-pointer items-center gap-1 rounded-md text-body leading-5 font-medium text-fg underline-offset-4 hover:underline pointer-coarse:min-h-11">
            <ChevronIcon aria-hidden width={14} height={14} className={cn("shrink-0 text-fg-subtle transition-transform duration-[var(--dur-fast)]", isOpen ? "-rotate-90" : "rotate-90")} />
            {isOpen ? collapseLabel : expandLabel(wordCount)}
          </button>
        )}
      </div>
      {footer != null && <div className="border-t border-line px-4 py-2.5 text-small leading-4 text-fg-muted">{footer}</div>}
    </section>
  );
}
