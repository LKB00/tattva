import { useState } from "react";
import { ConversationList } from "../organisms/ConversationList";
import { Avatar } from "../atoms/Avatar";

const items = [
  { id: "1", title: "Why sales grew last quarter", group: "Today" },
  { id: "2", title: "Welcome email draft", group: "Today" },
  { id: "3", title: "Request missing documents", group: "Workflows" },
  { id: "4", title: "Spreadsheet help", group: "Yesterday" },
];

/** Shared rail for the example pages: conversation list plus a user card. */
export function Rail({ activeId = "1" }: { activeId?: string }) {
  const [active, setActive] = useState(activeId);
  return (
    <>
      <div className="flex items-center gap-2 px-1"><Avatar kind="ai" size="sm" /><span className="font-serif text-body-lg">Tattva</span></div>
      <ConversationList items={items} activeId={active} onSelect={setActive} onNew={() => {}} />
      <div className="mt-auto flex items-center gap-2.5 rounded-card bg-sunken p-3">
        <Avatar kind="user" name="Maya Okafor" />
        <div className="min-w-0"><p className="truncate text-small leading-4 font-medium">Maya Okafor</p><p className="truncate text-micro text-fg-subtle">Product team</p></div>
      </div>
    </>
  );
}
