import { useState } from "react";
import { Button } from "../atoms/Button";
import { AppShell } from "../templates/AppShell";
import { ThreadTemplate } from "../templates/ThreadTemplate";
import { AIDisclosure } from "../atoms/AIDisclosure";
import { TypingIndicator } from "../atoms/TypingIndicator";
import { Message } from "../molecules/Message";
import { MessageActions } from "../molecules/MessageActions";
import { ThinkingBlock } from "../molecules/ThinkingBlock";
import { ToolCallCard } from "../molecules/ToolCallCard";
import { FeedbackBar } from "../molecules/FeedbackBar";
import { ConfidenceIndicator } from "../molecules/ConfidenceIndicator";
import { SuggestionChips } from "../molecules/SuggestionChips";
import { Composer } from "../organisms/Composer";
import { Markdown } from "../organisms/Markdown";
import { MessageList } from "../organisms/MessageList";
import { SourceList } from "../organisms/SourceList";
import { useStreamingText } from "../hooks/useStreamingText";
import { Rail } from "./Rail";

const REPLY = `Sales grew **12%** over the last quarter, mostly from big business customers.[1] About 2.1% of customers left, the same as before.[2]

| Customers | Growth |
|---|---|
| Big business | +18% |
| Individuals | +4% |

Two things to watch next quarter:
- Many big customers renew in November
- Fewer individuals signed up in the last two weeks`;

/** A full research answer: reasoning, tool use, cited prose, sources, confidence and feedback. */
export function ThreadPage() {
  const { text, streaming, start, stop } = useStreamingText(REPLY, { speed: 22 });
  const [asked, setAsked] = useState<string[]>([]);
  return (
    <AppShell rail={<Rail />} className="h-180 max-h-dvh">
      <ThreadTemplate header="Why sales grew last quarter" actions={<Button size="sm" variant="secondary">Share</Button>}
        composer={<Composer onAttach={() => {}} generating={streaming} onStop={stop} onSend={(t) => { setAsked([...asked, t]); start(); }} />}
        footnote={<AIDisclosure />}>
        <MessageList>
          <Message role="user">What made sales grow last quarter?</Message>
          <Message role="assistant" streaming={streaming}
            footer={!streaming && (
              <div className="space-y-4">
                <ConfidenceIndicator level="high" />
                <SourceList sources={[
                  { id: 1, title: "Q3 2026 earnings report", url: "https://example.com/q3", domain: "investor.example.com", snippet: "Total sales rose 12% from the quarter before." },
                  { id: 2, title: "Customer numbers update", url: "https://example.com/metrics", domain: "example.com" },
                ]} />
                <MessageActions text={REPLY} onRegenerate={start} />
                <FeedbackBar onSubmit={() => {}} />
              </div>
            )}>
            <ThinkingBlock seconds={4}>Read the earnings report first, then checked the customer numbers against it.</ThinkingBlock>
            <ToolCallCard name="Searched the web" status="success" summary='Looked up "q3 sales growth"' durationMs={1400} input={{ query: "q3 sales growth" }} output="5 results" />
            {text ? <Markdown>{text}</Markdown> : <TypingIndicator />}
          </Message>
          {asked.map((q, i) => <Message key={i} role="user">{q}</Message>)}
        </MessageList>
        {!streaming && <SuggestionChips suggestions={["Break it down by region", "Compare with Q2", "Draft a summary email"]} onPick={(s) => setAsked([...asked, s])} />}
      </ThreadTemplate>
    </AppShell>
  );
}
