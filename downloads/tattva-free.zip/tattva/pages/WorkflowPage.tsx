import { useState } from "react";
import { Button } from "../atoms/Button";
import { AppShell } from "../templates/AppShell";
import { ThreadTemplate } from "../templates/ThreadTemplate";
import { AIDisclosure } from "../atoms/AIDisclosure";
import { Badge } from "../atoms/Badge";
import { ContextChip } from "../molecules/ContextChip";
import { Checklist } from "../organisms/Checklist";
import { ApprovalPrompt } from "../organisms/ApprovalPrompt";
import { StepTimeline } from "../organisms/StepTimeline";
import { Composer } from "../organisms/Composer";
import { Rail } from "./Rail";

/** A running workflow is a thread: heading, checklist, and gates that need a person. */
export function WorkflowPage() {
  const [decision, setDecision] = useState("");
  return (
    <AppShell rail={<Rail activeId="3" />} className="h-180 max-h-dvh">
      <ThreadTemplate header="Request missing documents" actions={<Button size="sm" variant="secondary">Share</Button>}
        composer={<Composer onAttach={() => {}} placeholder="Ask a follow-up…" onSend={() => {}} tools={<ContextChip onClear={() => {}}>5 people</ContextChip>} />}
        footnote={<AIDisclosure />}>
        <section className="space-y-3">
          <h2 className="text-title-lg leading-10">Ask for the missing documents</h2>
          <p className="text-body leading-5 text-fg-muted">3 of 5 done. Here is where things stand:</p>
        </section>
        <Checklist doneSummary="Received from Atlas, Birch and Cedar" items={[
          { id: "1", title: <span className="font-medium">Dana Whitfield</span>, badge: <Badge tone="accent">Form A</Badge>, status: "No reply in 5 days, due in 2", attention: true },
          { id: "2", title: <span className="font-medium">Owen Park</span>, badge: <Badge tone="accent">Form A</Badge>, status: "Reminder sent yesterday" },
        ]} />
        <ApprovalPrompt risk="medium" action="Send a second reminder to Dana Whitfield"
          detail={<>An email from <b>team@example.com</b> with the subject “Documents due Friday” will be sent now.</>}
          onApprove={() => setDecision("Approved")} onDeny={() => setDecision("Denied")} />
        {decision && <p role="status" className="text-body leading-5 text-fg-muted">Decision: {decision}</p>}
        <StepTimeline steps={[
          { id: "a", title: "Find missing documents", detail: "2 people", state: "done" },
          { id: "b", title: "Send reminders", detail: "Waiting for approval", state: "active" },
          { id: "c", title: "Confirm receipt", state: "todo" },
        ]} />
      </ThreadTemplate>
    </AppShell>
  );
}
