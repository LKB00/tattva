import { AppShell } from "../templates/AppShell";
import { HomeTemplate } from "../templates/HomeTemplate";
import { HeroHeading } from "../atoms/HeroHeading";
import { AIDisclosure } from "../atoms/AIDisclosure";
import { TrayRow } from "../molecules/TrayRow";
import { ContextPill } from "../molecules/ContextPill";
import { Tray } from "../organisms/Tray";
import { Composer } from "../organisms/Composer";
import { UsersIcon } from "../lib/icons";
import { Rail } from "./Rail";

/** Landing: the headline answers itself in the tray below it. */
export function HomePage() {
  return (
    <AppShell rail={<Rail />} className="h-180 max-h-dvh">
      <HomeTemplate
        heading={<HeroHeading text="3 tasks need you today. Where should we start?" />}
        footnote={<AIDisclosure />}
      >
        <Tray label="Needs you" action="4 running →" footer={
          <Composer onAttach={() => {}} placeholder="Give me a task or ask a question…" onSend={() => {}}
            tools={<ContextPill icon={<UsersIcon width={14} height={14} />} onClick={() => {}}>All projects</ContextPill>} />
        }>
          <TrayRow attention title="Quarterly report" detail="Approval pending for 6 days" trailing="Open →" />
          <TrayRow attention title="Customer survey" detail="Missing 2 answers, due in 2 days" trailing="Open →" />
          <TrayRow attention title="Launch plan" detail="Needs a decision by Friday" trailing="Open →" />
        </Tray>
      </HomeTemplate>
    </AppShell>
  );
}
