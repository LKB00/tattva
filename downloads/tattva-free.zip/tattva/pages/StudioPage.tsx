import { useState } from "react";
import { Button } from "../atoms/Button";
import { Rail } from "./Rail";
import { AppShell } from "../templates/AppShell";
import { SplitCanvasTemplate } from "../templates/SplitCanvasTemplate";
import { PromptBox } from "../organisms/PromptBox";
import { VariantGrid } from "../organisms/VariantGrid";
import { CanvasPanel } from "../organisms/CanvasPanel";
import { Markdown } from "../organisms/Markdown";
import { AIBadge } from "../atoms/AIBadge";

// Documented exception to the no-hex rule: sample picture tones that stand in for user images. See scripts/check-docs.mjs.
const tones = ["#24282c", "#c2ef72", "#c97b4a", "#919395"];
const DRAFT = ["# Launch announcement", "", "We are introducing **Tattva**, a clearer way to build with AI.", "", "- Answers that appear without the page jumping", "- Sources you can check", "- Your approval before anything that cannot be undone"];

/** Generative studio: prompt and variants on the left, the chosen artifact with version history on the right. */
export function StudioPage() {
  const [busy, setBusy] = useState(false);
  const [sel, setSel] = useState("a");
  const [version, setVersion] = useState(2);
  return (
    <AppShell rail={<Rail activeId="2" />} className="h-180 max-h-dvh">
      <SplitCanvasTemplate header="Welcome email draft" actions={<Button size="sm" variant="secondary">Share</Button>} primaryLabel="Make options" canvasLabel="Draft"
        primary={<>
          <PromptBox busy={busy} examples={["Launch announcement", "Release notes"]} onGenerate={() => { setBusy(true); setTimeout(() => setBusy(false), 1800); }} />
          <VariantGrid selectedId={sel} onSelect={setSel} loadingCount={busy ? 2 : 0}
            variants={["a", "b", "c", "d"].slice(0, busy ? 2 : 4).map((id, i) => ({ id, label: `Option ${id.toUpperCase()}`, node: <div className="size-full" style={{ background: `linear-gradient(135deg, ${tones[i]}, color-mix(in srgb, ${tones[i]} 35%, #f7f6f0))` }} /> }))} />
        </>}
        canvas={
          <CanvasPanel title="Launch announcement.md" version={version} versions={3} onVersionChange={setVersion} onRegenerate={() => {}} onClose={() => {}} actions={<AIBadge />}>
            <div className="space-y-4 text-body-lg leading-7"><Markdown>{DRAFT.join("\n")}</Markdown></div>
            <p className="mt-6 text-small leading-4 text-fg-subtle">Viewing version {version} of 3.</p>
          </CanvasPanel>
        } />
    </AppShell>
  );
}
