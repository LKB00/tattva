import type { ReactNode } from "react";
import { PageBar } from "./PageBar";

export interface ThreadTemplateProps {
  /** Optional title row above the thread. */
  header?: ReactNode;
  /** Controls on the right of the title bar. */
  actions?: ReactNode;
  /** The conversation or workflow body. Scrolls. */
  children: ReactNode;
  /** The composer. Stays pinned to the bottom. */
  composer: ReactNode;
  footnote?: ReactNode;
}

/** Scrolling thread with a pinned composer. Thread and composer share one reading width. */
export function ThreadTemplate({ header, actions, children, composer, footnote }: ThreadTemplateProps) {
  return (
    <>
      <PageBar title={header} actions={actions} />
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto w-full max-w-3xl space-y-8">{children}</div>
      </div>
      <div className="shrink-0 px-4 pb-[max(1rem,var(--safe-bottom))] sm:px-6">
        <div className="mx-auto w-full max-w-3xl space-y-2">{composer}{footnote}</div>
      </div>
    </>
  );
}
