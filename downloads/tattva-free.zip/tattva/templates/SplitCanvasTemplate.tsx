import type { ReactNode } from "react";
import { PageBar } from "./PageBar";

export interface SplitCanvasTemplateProps {
  /** Left: the conversation or controls. */
  primary: ReactNode;
  /** Right: the artifact that outlives a single message (CanvasPanel). Stacks under primary on narrow screens. */
  canvas: ReactNode;
  /** Accessible names for the two regions. */
  primaryLabel?: string;
  canvasLabel?: string;
  /** Title bar text and controls, shared with the other templates. */
  header?: ReactNode;
  actions?: ReactNode;
}

export function SplitCanvasTemplate({ primary, canvas, primaryLabel = "Conversation", canvasLabel = "Canvas", header, actions }: SplitCanvasTemplateProps) {
  return (
    <>
    <PageBar title={header} actions={actions} />
    <div className="grid min-h-0 flex-1 grid-cols-1 gap-6 overflow-y-auto px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)] lg:overflow-hidden">
      <section aria-label={primaryLabel} className="min-h-0 space-y-6 overflow-y-auto">{primary}</section>
      <section aria-label={canvasLabel} className="min-h-90 lg:min-h-0">{canvas}</section>
    </div>
    </>
  );
}
