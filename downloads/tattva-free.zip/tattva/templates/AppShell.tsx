import { useContext, useState, type ReactNode } from "react";
import { Button } from "../atoms/Button";
import { Sheet } from "../organisms/Sheet";
import { EmbeddedContext } from "../lib/embedded";
import { cn } from "../lib/cn";

export interface AppShellProps {
  /** Left rail: conversation list, navigation, user card. Below the md breakpoint it moves into a side sheet opened from a Menu button. */
  rail?: ReactNode;
  children: ReactNode;
  /** Fix the shell to a height (for previews). By default it fills its container. */
  className?: string;
  /** Name of the button that opens the rail on a phone. */
  menuLabel?: string;
}

/** Two-column frame: a narrow rail and one main room. The rail never competes with the main column. */
export function AppShell({ rail, children, className, menuLabel = "Menu" }: AppShellProps) {
  const [menu, setMenu] = useState(false);
  // Inside a documentation preview the landmarks become plain containers so the host page keeps one main.
  const embedded = useContext(EmbeddedContext);
  const Rail = embedded ? "div" : "aside";
  const Main = embedded ? "div" : "main";
  return (
    <div className={cn("flex h-full min-h-0 w-full bg-bg text-fg", className)}>
      {rail && <Rail aria-label={embedded ? undefined : "Sidebar"} className="hidden w-68 shrink-0 flex-col gap-4 overflow-y-auto p-5 md:flex">{rail}</Rail>}
      <Main className="flex min-w-0 flex-1 flex-col">
        {rail && (
          <div className="flex shrink-0 items-center px-4 pt-3 md:hidden">
            <Button variant="secondary" size="sm" aria-haspopup="dialog" onClick={() => setMenu(true)}>{menuLabel}</Button>
          </div>
        )}
        {children}
      </Main>
      {rail && <Sheet open={menu} onClose={() => setMenu(false)} title={menuLabel} side="left" size="sm"><div className="flex flex-col gap-4 pb-4">{rail}</div></Sheet>}
    </div>
  );
}
