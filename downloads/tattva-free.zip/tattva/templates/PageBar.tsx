import type { ReactNode } from "react";

export interface PageBarProps {
  /** Page title, one line. */
  title?: ReactNode;
  /** Quiet controls on the right, such as Share. */
  actions?: ReactNode;
}

/** The top bar every template shares, so pages differ in their body and never in their frame. */
export function PageBar({ title, actions }: PageBarProps) {
  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b border-line px-4 sm:px-6">
      {/* A bar with no title has no heading at all, rather than an empty one. */}
      {title ? <h1 className="font-sans! truncate text-body leading-5 font-medium text-fg">{title}</h1> : <div />}
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </header>
  );
}
