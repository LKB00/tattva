import type { ReactNode } from "react";
import { PageBar } from "./PageBar";

export interface HomeTemplateProps {
  /** The greeting. Use HeroHeading. */
  heading: ReactNode;
  /** The tray that answers the headline (Tray with its Composer as footer). */
  children: ReactNode;
  /** Quiet line under the tray, e.g. AIDisclosure. */
  footnote?: ReactNode;
  /** Title bar text. */
  header?: ReactNode;
  actions?: ReactNode;
}

/** Empty-thread landing: one greeting, one tray, vertically centered. Nothing else competes. */
export function HomeTemplate({ heading, children, footnote, header = "New chat", actions }: HomeTemplateProps) {
  return (
    <>
      <PageBar title={header} actions={actions} />
      <div className="flex min-h-0 flex-1 flex-col items-center justify-start overflow-y-auto px-4 py-8 md:justify-center md:py-10">
        <div className="w-full max-w-3xl space-y-8">
          {heading}
          {children}
          {footnote}
        </div>
      </div>
    </>
  );
}
