import { useLayoutEffect, useState, type CSSProperties, type RefObject } from "react";

/**
 * Position of a sliding selection indicator inside `ref`, following the child that matches `selector`
 * (for example '[aria-selected="true"]'). Returns a style for an absolutely positioned element; the container must be
 * `relative`. The first placement does not animate, so the indicator never slides in from the corner. Pass `key` so it
 * re-measures when the selection changes.
 */
export function useIndicator(ref: RefObject<HTMLElement | null>, selector: string, key: unknown): CSSProperties | null {
  const [box, setBox] = useState<{ x: number; y: number; w: number; h: number; ready: boolean } | null>(null);
  useLayoutEffect(() => {
    const root = ref.current;
    if (!root) return;
    const read = () => {
      const el = root.querySelector<HTMLElement>(selector);
      if (!el) { setBox(null); return; }
      const next = { x: el.offsetLeft, y: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight };
      setBox((p) => (p && p.x === next.x && p.y === next.y && p.w === next.w && p.h === next.h ? p : { ...next, ready: !!p }));
    };
    read();
    const ro = new ResizeObserver(read);
    ro.observe(root);
    root.querySelectorAll("*").forEach((c) => ro.observe(c));
    return () => ro.disconnect();
  }, [ref, selector, key]);
  if (!box) return null;
  return {
    position: "absolute", left: 0, top: box.y, width: box.w, height: box.h,
    transform: `translateX(${box.x}px)`,
    transitionProperty: box.ready ? "transform, width" : "none",
    transitionDuration: "var(--dur-base)", transitionTimingFunction: "var(--ease-arrive)",
  };
}
