import { useEffect, useState } from "react";
import { useReducedMotion } from "./useReducedMotion";

/**
 * Keeps something mounted for a short exit after `open` turns false, so it can fade out instead of vanishing.
 * `leaving` is true during that time. Under reduced motion there is no delay. The default matches --dur-fast.
 */
export function usePresence(open: boolean, exitMs = 150): { present: boolean; leaving: boolean } {
  const reduce = useReducedMotion();
  const [present, setPresent] = useState(open);
  useEffect(() => {
    if (open) { setPresent(true); return; }
    if (!present) return;
    const t = window.setTimeout(() => setPresent(false), reduce ? 0 : exitMs);
    return () => window.clearTimeout(t);
  }, [open, present, reduce, exitMs]);
  return { present: open || present, leaving: !open && present };
}
