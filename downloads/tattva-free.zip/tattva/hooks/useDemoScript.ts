import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "./useReducedMotion";

export interface DemoStep {
  /** When this beat happens, in milliseconds from the start of the loop. */
  at: number;
  /** What changes on this beat, such as moving the cursor or adding a message. */
  run: () => void;
}

export interface DemoScriptOptions {
  /** Length of one loop in milliseconds. After it, `reset` runs and the steps play again. */
  duration: number;
  /** Puts the demo back to its first frame before each loop. */
  reset: () => void;
  /** Play again after the last beat. Default true. */
  loop?: boolean;
}

/**
 * Plays a faux UI demo one beat at a time. The demo is drawn from state; each step changes the state. It starts when
 * the stage scrolls into view and pauses when it leaves. With reduced motion it plays every step at once and stops,
 * so the person sees the finished frame, still. Attach the returned ref to the stage.
 */
export function useDemoScript<T extends HTMLElement = HTMLDivElement>(steps: DemoStep[], { duration, reset, loop = true }: DemoScriptOptions) {
  const ref = useRef<T>(null);
  const reduced = useReducedMotion();
  const [visible, setVisible] = useState(false);
  const latest = useRef({ steps, reset });
  latest.current = { steps, reset };

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") { setVisible(true); return; }
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { threshold: 0.25 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const { steps: s, reset: r } = latest.current;
    if (reduced) { r(); [...s].sort((a, b) => a.at - b.at).forEach((x) => x.run()); return; }
    if (!visible) return;
    let timers: ReturnType<typeof setTimeout>[] = [];
    const play = () => {
      latest.current.reset();
      timers = latest.current.steps.map((x) => setTimeout(() => x.run(), x.at));
      if (loop) timers.push(setTimeout(play, duration));
    };
    play();
    return () => timers.forEach(clearTimeout);
  }, [visible, reduced, duration, loop]);

  return ref;
}
