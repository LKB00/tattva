import { useEffect, useState, type CSSProperties, type RefObject } from "react";

/**
 * For a row that scrolls sideways. Returns a style that softly fades the edge that has more content past it, so a phone user
 * can see there is more to reach. Nothing fades when everything fits. Spread it on the scrolling element.
 * Pass remeasureOn when the element mounts later than the component, so it is measured once it is there.
 */
export function useScrollEdges(ref: RefObject<HTMLElement | null>, remeasureOn?: unknown): CSSProperties {
  const [edge, setEdge] = useState({ start: false, end: false });
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const read = () => {
      const start = el.scrollLeft > 1;
      const end = el.scrollLeft + el.clientWidth < el.scrollWidth - 1;
      setEdge((p) => (p.start === start && p.end === end ? p : { start, end }));
    };
    read();
    el.addEventListener("scroll", read, { passive: true });
    const ro = new ResizeObserver(read);
    ro.observe(el);
    return () => { el.removeEventListener("scroll", read); ro.disconnect(); };
  }, [ref, remeasureOn]);
  if (!edge.start && !edge.end) return {};
  const mask = `linear-gradient(to right, ${edge.start ? "transparent 0, black var(--edge-fade)" : "black 0"}, ${edge.end ? "black calc(100% - var(--edge-fade)), transparent 100%" : "black 100%"})`;
  return { maskImage: mask, WebkitMaskImage: mask };
}
