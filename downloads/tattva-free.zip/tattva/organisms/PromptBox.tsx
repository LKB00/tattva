import { useId, useState } from "react";
import { useAnnounceChange } from "../lib/focus";
import { SparkleIcon } from "../lib/icons";
import { Button } from "../atoms/Button";
import { Spinner } from "../atoms/Spinner";

/** Prompt field with a Generate button and example prompts. Screen readers hear when generating starts and ends. */
export function PromptBox({ onGenerate, busy, placeholder = "Describe what you want to create…", examples = [], busyMessage = "Generating", doneMessage = "Done. The results are ready." }: {
  onGenerate: (prompt: string) => void; busy?: boolean; placeholder?: string; examples?: string[];
  /** What screen readers hear when generating starts. */
  busyMessage?: string;
  /** What screen readers hear when it ends. Say where the results are if that helps, such as "4 images below". */
  doneMessage?: string;
}) {
  const [v, setV] = useState("");
  const said = useAnnounceChange(!!busy, (now) => (now ? busyMessage : doneMessage));
  const inputId = useId();
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (v.trim() && !busy) onGenerate(v.trim()); }} className="space-y-2">
      <div className="rounded-field border border-line-strong bg-surface p-2.5 shadow-sm focus-within:border-fg-subtle has-[textarea:focus-visible]:outline-2 has-[textarea:focus-visible]:outline-offset-2 has-[textarea:focus-visible]:outline-[var(--focus-ring)]">
        <label htmlFor={inputId} className="sr-only">Prompt</label>
        <textarea id={inputId} rows={3} value={v} onChange={(e) => setV(e.target.value)} placeholder={placeholder}
          className="block w-full resize-none bg-transparent p-2 text-body-lg outline-none placeholder:text-fg-subtle [field-sizing:content]" />
        <div className="flex items-center justify-between px-1 pt-1">
          <span className="text-small leading-4 text-fg-subtle">{v.length} characters</span>
          <Button type="submit" variant="lime" size="sm" disabled={!v.trim() || busy} leading={busy ? <Spinner size={14} /> : <SparkleIcon width={14} height={14} />}>{busy ? "Generating…" : "Generate"}</Button>
        </div>
      </div>
      <p role="status" aria-live="polite" className="sr-only">{said}</p>
      {examples.length > 0 && (
        <p className="flex flex-wrap items-center gap-1.5 text-small leading-4 text-fg-muted">Try:
          {examples.map((x) => <button key={x} type="button" onClick={() => setV(x)} className="rounded-control border border-line px-2 py-0.5 hover:bg-hover">{x}</button>)}
        </p>
      )}
    </form>
  );
}
