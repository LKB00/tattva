import { useEffect, useRef, type ReactNode } from "react";
import { keepFocus, useAnnounceChange } from "../lib/focus";
import { RefreshIcon, XIcon } from "../lib/icons";
import { Button, IconButton } from "../atoms/Button";

/**
 * Side panel for generated artifacts (docs, code, designs) that outlive a single chat message. Version changes are
 * read out, the content can be scrolled from the keyboard, and Close returns focus to what opened the panel.
 */
export function CanvasPanel({ title, version, versions = 1, onVersionChange, onClose, onRegenerate, children, actions, versionMessage = (v, n) => `Version ${v} of ${n}`, focusAfterClose }: {
  title: string; version?: number; versions?: number; onVersionChange?: (v: number) => void; onClose?: () => void; onRegenerate?: () => void; children: ReactNode; actions?: ReactNode;
  /** What screen readers hear when the version changes. */
  versionMessage?: (version: number, versions: number) => string;
  /** Where keyboard focus goes after Close. By default the control that had focus when the panel opened. */
  focusAfterClose?: () => HTMLElement | null;
}) {
  const ref = useRef<HTMLElement>(null);
  // Remember what opened the panel, so Close can go back to it.
  const opener = useRef<HTMLElement | null>(null);
  useEffect(() => { const a = document.activeElement; if (a instanceof HTMLElement && a !== document.body && !ref.current?.contains(a)) opener.current = a; }, []);
  const said = useAnnounceChange(version, (v) => (v != null ? versionMessage(v, versions) : ""));
  return (
    <aside ref={ref} aria-label={title} className="flex h-full flex-col overflow-hidden rounded-card border border-line bg-surface shadow-md">
      <header className="flex flex-wrap items-center gap-x-2 gap-y-1 border-b border-line px-3 py-2">
        <h2 className="min-w-32 flex-1 truncate text-body leading-5 font-medium">{title}</h2>
        {versions > 1 && version != null && (
          <div className="flex items-center gap-1 text-small leading-4 text-fg-muted" role="group" aria-label="Version history">
            <Button size="sm" variant="ghost" disabled={version <= 1} onClick={() => onVersionChange?.(version - 1)} aria-label="Previous version">‹</Button>
            <span className="tabular-nums">v{version} of {versions}</span>
            <Button size="sm" variant="ghost" disabled={version >= versions} onClick={() => onVersionChange?.(version + 1)} aria-label="Next version">›</Button>
          </div>
        )}
        {onRegenerate && <IconButton size="sm" label="Regenerate" onClick={onRegenerate}><RefreshIcon /></IconButton>}
        {actions}
        {onClose && <IconButton size="sm" label="Close panel" onClick={() => { onClose(); keepFocus(ref.current, () => focusAfterClose?.() ?? (opener.current?.isConnected ? opener.current : null)); }}><XIcon /></IconButton>}
      </header>
      <p role="status" aria-live="polite" className="sr-only">{said}</p>
      {/* Reachable from the keyboard, so long content can be scrolled with the arrow keys. */}
      <div tabIndex={0} role="region" aria-label={`${title}, content`} className="min-h-0 flex-1 overflow-auto p-4 outline-offset-[-2px]">{children}</div>
    </aside>
  );
}
