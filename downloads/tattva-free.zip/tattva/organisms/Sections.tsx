import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import type { HeadingLevel } from "../lib/useFocusAfter";
import { Collapsible } from "../molecules/Collapsible";

export interface Section {
  /** Stays the same while the answer streams, so a section keeps its open state. */
  id: string;
  title: string;
  /** A short line shown next to the title, such as "3 options". */
  meta?: string;
  content: ReactNode;
}

export interface SectionsProps {
  sections: Section[];
  /** The answer is still arriving. Each new section opens as it arrives; when the answer ends, the first one stays open. */
  streaming?: boolean;
  /** Level of each section's heading. Defaults to 3. */
  headingLevel?: HeadingLevel;
  className?: string;
}

/**
 * A long answer in foldable sections. While the answer streams, each new section opens as it arrives so people can
 * follow along. When it ends, the sections fold back to the first one. Once the person opens or closes a section
 * themselves, the answer stops moving things and leaves their choice alone.
 */
export function Sections({ sections, streaming = false, headingLevel = 3, className }: SectionsProps) {
  const [open, setOpen] = useState<Set<string>>(() => new Set(sections[0] ? [sections[0].id] : []));
  const touched = useRef(false);
  const last = sections[sections.length - 1]?.id;
  const first = sections[0]?.id;

  // While streaming, follow the newest section; when the stream ends, settle on the first. Never after a person acts.
  useEffect(() => {
    if (touched.current) return;
    if (streaming && last) setOpen(new Set([last]));
  }, [streaming, last]);
  useEffect(() => {
    if (touched.current) return;
    if (!streaming && first) setOpen(new Set([first]));
  }, [streaming, first]);

  const toggle = (id: string, value: boolean) => {
    touched.current = true;
    setOpen((o) => { const n = new Set(o); if (value) n.add(id); else n.delete(id); return n; });
  };

  return (
    <div className={cn("divide-y divide-line rounded-card border border-line bg-surface", className)} aria-busy={streaming || undefined}>
      {sections.map((s) => (
        <Collapsible key={s.id} open={open.has(s.id)} onOpenChange={(v) => toggle(s.id, v)} headingLevel={headingLevel}
          className="px-4 py-3"
          header={
            <span className="flex min-w-0 flex-1 items-baseline justify-between gap-3">
              <span className="min-w-0 text-lead leading-6 font-semibold text-fg">{s.title}</span>
              {s.meta && <span className="shrink-0 text-body leading-5 text-fg-muted">{s.meta}</span>}
            </span>
          }>
          <div className="pt-2 pl-6 text-body leading-6 text-fg">{s.content}</div>
        </Collapsible>
      ))}
    </div>
  );
}
