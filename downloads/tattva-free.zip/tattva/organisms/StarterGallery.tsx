import { useRef, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { keepFocus, nearestTyping, useAnnounceChange } from "../lib/focus";
import { Button } from "../atoms/Button";
import { Badge } from "../atoms/Badge";

export interface StarterIntent { id: string; label: string }
export interface StarterTemplate { id: string; title: string; description: string; category?: string }

export interface StarterGalleryProps {
  /** Heading above the statement. */
  heading?: string;
  /** One sentence on what the assistant can and cannot do. */
  statement: ReactNode;
  /** Starter intents. Three to six works best. */
  intents: StarterIntent[];
  onIntent: (id: string) => void;
  templates?: StarterTemplate[];
  onTemplate?: (id: string) => void;
  intentsLabel?: string;
  templatesLabel?: string;
  /** Slot beside the templates heading, usually a Randomize button. When the templates change, screen readers hear it. */
  randomize?: ReactNode;
  /** What screen readers hear when the templates change. */
  templatesChangedMessage?: (count: number) => string;
  /** Where keyboard focus goes after an idea or template is chosen, if the gallery goes away. By default the nearest
   * message box. */
  focusAfterChoose?: () => HTMLElement | null;
  className?: string;
}

/** First-run view. It states scope, offers starter intents next to free text, and lists templates. */
export function StarterGallery({ heading = "What would you like to make?", statement, intents, onIntent, templates = [], onTemplate, intentsLabel = "Start with", templatesLabel = "Templates", randomize, templatesChangedMessage = (n) => `New templates: ${n}`, focusAfterChoose, className }: StarterGalleryProps) {
  const ref = useRef<HTMLElement>(null);
  const choose = (f: ((id: string) => void) | undefined, id: string) => {
    const box = nearestTyping(ref.current);
    f?.(id);
    keepFocus(ref.current, () => focusAfterChoose?.() ?? box);
  };
  const said = useAnnounceChange(templates.map((t) => t.id).join("|"), () => templatesChangedMessage(templates.length));
  return (
    <section ref={ref} aria-label={heading} className={cn("space-y-6", className)}>
      <div className="space-y-2">
        <h2 className="text-title-sm leading-8">{heading}</h2>
        <p className="max-w-xl text-body leading-5 text-fg-muted">{statement}</p>
      </div>
      <div className="space-y-2">
        <h3 className="text-nano font-normal tracking-caps text-fg-muted uppercase font-sans!">{intentsLabel}</h3>
        <ul className="flex flex-wrap gap-2">
          {intents.map((i) => <li key={i.id}><Button variant="secondary" size="sm" onClick={() => choose(onIntent, i.id)}>{i.label}</Button></li>)}
        </ul>
      </div>
      <p role="status" aria-live="polite" className="sr-only">{said}</p>
      {templates.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-nano font-normal tracking-caps text-fg-muted uppercase font-sans!">{templatesLabel}</h3>
            {randomize}
          </div>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {templates.map((t) => (
              <li key={t.id}>
                <button type="button" onClick={() => choose(onTemplate, t.id)}
                  className="flex h-full w-full cursor-pointer flex-col items-start gap-1 rounded-card border border-line bg-surface p-4 text-left transition-colors hover:border-line-strong hover:bg-hover">
                  {t.category && <Badge>{t.category}</Badge>}
                  <span className="text-body leading-5 font-medium">{t.title}</span>
                  <span className="text-small leading-4 text-fg-muted">{t.description}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
