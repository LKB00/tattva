import { useId, useState, type ReactNode } from "react";
import { cn } from "../lib/cn";
import { headingTag, subHeadingTag, type HeadingLevel } from "../lib/useFocusAfter";
import { CheckIcon } from "../lib/icons";
import { Button } from "../atoms/Button";

export interface CompareReply {
  id: string;
  /** Short name for the reply, such as "Reply A". */
  label: string;
  content: ReactNode;
}

export interface ResponseCompareLabels {
  heading?: string;
  hint?: string;
  choose?: string;
  same?: string;
  chosen?: string;
  /** Read out after a choice. Receives the chosen reply's label, or null for "about the same". */
  thanks?: (label: string | null) => string;
}

export interface ResponseCompareProps {
  /** Exactly two replies to the same question. */
  replies: [CompareReply, CompareReply];
  /** Called with the chosen reply's id, or "same". */
  onChoose: (id: string | "same") => void;
  /** The chosen reply's id, or "same". Leave it out to let the part keep its own choice. */
  chosen?: string | "same" | null;
  /** Offer an "About the same" choice. On by default. */
  allowSame?: boolean;
  labels?: ResponseCompareLabels;
  /** Level of the part's heading, so it fits the page outline. Default 3. */
  headingLevel?: HeadingLevel;
  className?: string;
}

/**
 * Two replies to the same question, side by side, and the person picks the better one. The choice is a plain button
 * under each reply, so it works the same with a mouse, a finger, a keyboard or a screen reader. After a choice, the
 * kept reply says so in words and the other steps back; nothing moves.
 */
export function ResponseCompare({ replies, onChoose, chosen: chosenProp, allowSame = true, labels, headingLevel = 3, className }: ResponseCompareProps) {
  const l = {
    heading: "Which reply is better?", hint: "Your choice helps the assistant learn what you prefer.", choose: "Choose this reply", same: "About the same",
    chosen: "You chose this", thanks: (label: string | null) => (label ? `Thanks. You chose ${label}.` : "Thanks. You said they are about the same."), ...labels,
  };
  const [own, setOwn] = useState<string | "same" | null>(null);
  const chosen = chosenProp !== undefined ? chosenProp : own;
  const uid = useId();
  const H = headingTag(headingLevel);
  const H2 = subHeadingTag(headingLevel);
  const pick = (id: string | "same") => { setOwn(id); onChoose(id); };
  const label = chosen && chosen !== "same" ? replies.find((r) => r.id === chosen)?.label ?? null : null;
  return (
    <section aria-labelledby={`${uid}-h`} className={cn("rounded-card border border-line bg-surface p-4 sm:p-5", className)}>
      <H id={`${uid}-h`} className="m-0 text-body leading-5 font-semibold text-fg">{l.heading}</H>
      <p className="mt-1 text-small leading-5 text-fg-muted">{l.hint}</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {replies.map((r) => {
          const isChosen = chosen === r.id;
          const faded = !!chosen && chosen !== "same" && !isChosen;
          return (
            <article key={r.id} aria-labelledby={`${uid}-${r.id}`}
              className={cn("flex min-w-0 flex-col rounded-control border p-4 transition-colors duration-(--dur-fast) motion-reduce:transition-none",
                isChosen ? "border-selected-line bg-selected" : "border-line bg-bg", faded && "opacity-70")}>
              <H2 id={`${uid}-${r.id}`} className="m-0 text-small leading-4 font-medium text-fg-muted">{r.label}</H2>
              <div className="mt-2 min-w-0 flex-1 space-y-3 text-body leading-6 text-fg">{r.content}</div>
              <div className="mt-4">
                {isChosen
                  ? <p className="m-0 inline-flex items-center gap-1.5 text-small leading-5 font-medium text-fg"><CheckIcon aria-hidden width={14} height={14} />{l.chosen}</p>
                  : <Button size="sm" variant="secondary" onClick={() => pick(r.id)} aria-describedby={`${uid}-${r.id}`}>{l.choose}</Button>}
              </div>
            </article>
          );
        })}
      </div>
      {allowSame && chosen !== "same" && (
        <div className="mt-3"><Button size="sm" variant="ghost" onClick={() => pick("same")}>{l.same}</Button></div>
      )}
      <p role="status" className={cn("text-small leading-5 text-fg-muted", chosen ? "mt-3" : "sr-only")}>{chosen ? l.thanks(label) : ""}</p>
    </section>
  );
}
