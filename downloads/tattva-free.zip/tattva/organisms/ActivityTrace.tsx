import { useEffect, useId, useRef, useState } from "react";
import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { CheckIcon, ChevronIcon, XIcon } from "../lib/icons";
import { Badge } from "../atoms/Badge";

export type TraceActor = "ai" | "rule" | "calculated" | "check" | "you";
export type TraceStatus = "pending" | "running" | "done" | "failed";

export interface TraceStep {
  id: string;
  actor: TraceActor;
  title: string;
  detail?: ReactNode;
  /** Default "done". */
  status?: TraceStatus;
}

export interface ActivityTraceProps {
  steps: TraceStep[];
  /** True while steps are still arriving. The list stays open and each new row is announced. */
  streaming?: boolean;
  /** The one line shown when folded, such as "Read your message · 8 steps". */
  summary: string;
  defaultOpen?: boolean;
  /** Controlled open state. */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Rename the tags, for another language or wording. */
  actorLabels?: Partial<Record<TraceActor, string>>;
  className?: string;
}

const defaultLabels: Record<TraceActor, string> = { ai: "AI", rule: "Rule sheet", calculated: "Calculated", check: "Safety check", you: "You" };
const statusWords: Record<TraceStatus, string> = { pending: "Waiting", running: "Running", done: "Done", failed: "Failed" };

function StatusIcon({ status }: { status: TraceStatus }) {
  return (
    <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center">
      {status === "running" ? (
        <svg aria-hidden width={16} height={16} viewBox="0 0 24 24" className="text-fg-muted motion-safe:animate-spin">
          <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
          <path d="M21 12a9 9 0 0 0-9-9" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      ) : status === "done" ? <CheckIcon aria-hidden width={16} height={16} className="text-success-fg" />
        : status === "failed" ? <XIcon aria-hidden width={16} height={16} className="text-danger-fg" />
        : <span aria-hidden className="size-2.5 rounded-full border border-line-strong forced-colors:border-[CanvasText]" />}
      <span className="sr-only">{statusWords[status]}</span>
    </span>
  );
}

/**
 * The agent's work shown step by step, then folded into one line. Each step carries a tag that says who did it:
 * AI (a judgment that can be wrong), Rule sheet (looked up and checked), Calculated (done by code), Safety check
 * (a guardrail), or You. While streaming the list is open; when the work is done the parent sets streaming to false and the person can fold it.
 */
export function ActivityTrace({ steps, streaming, summary, defaultOpen = false, open, onOpenChange, actorLabels, className }: ActivityTraceProps) {
  const uid = useId();
  const [inner, setInner] = useState(defaultOpen);
  const isOpen = streaming || (open ?? inner);
  const labels = { ...defaultLabels, ...actorLabels };
  const toggle = () => { if (streaming) return; const v = !isOpen; if (open === undefined) setInner(v); onOpenChange?.(v); };

  // Announce each new step once. The first render is not announced, so a trace that mounts full stays quiet.
  const seen = useRef(steps.length);
  const [said, setSaid] = useState("");
  useEffect(() => {
    if (steps.length > seen.current && streaming) { const s = steps[steps.length - 1]; setSaid(`${labels[s.actor]}: ${s.title}`); }
    seen.current = steps.length;
    // labels is rebuilt each render; steps.length is the real trigger.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [steps.length, streaming]);

  return (
    <div className={cn("rounded-card border border-line bg-surface", className)}>
      <button type="button" aria-expanded={isOpen} aria-controls={`${uid}-list`} aria-disabled={streaming || undefined} onClick={toggle}
        className={cn("flex min-h-10 w-full items-center gap-2 rounded-card px-4 py-2 text-left text-body leading-5 text-fg-muted pointer-coarse:min-h-11", streaming ? "cursor-default" : "cursor-pointer hover:bg-hover hover:text-fg")}>
        <ChevronIcon aria-hidden className={cn("shrink-0 text-fg-subtle transition-transform duration-[var(--dur-fast)]", isOpen && "rotate-90")} />
        <span className="min-w-0 flex-1 break-words">{summary}</span>
      </button>
      {isOpen && (
        <ol id={`${uid}-list`} className="m-0 list-none space-y-3 border-t border-line px-4 py-3">
          {steps.map((s) => {
            const status = s.status ?? "done";
            return (
              <li key={s.id} className={cn("flex gap-3", streaming && "motion-safe:animate-rise")}>
                <StatusIcon status={status} />
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-body leading-5">
                    <span className={cn("font-medium break-words", status === "pending" && "text-fg-muted", status === "failed" && "text-danger-fg")}>{s.title}</span>
                    <Badge tone={s.actor === "ai" ? "accent" : "neutral"}>{labels[s.actor]}</Badge>
                    {status === "failed" && <span className="text-small leading-4 text-danger-fg">Failed</span>}
                  </p>
                  {s.detail && <div className="mt-0.5 text-small leading-4 text-fg-muted break-words">{s.detail}</div>}
                </div>
              </li>
            );
          })}
        </ol>
      )}
      <p role="status" aria-live="polite" className="sr-only">{said}</p>
    </div>
  );
}
