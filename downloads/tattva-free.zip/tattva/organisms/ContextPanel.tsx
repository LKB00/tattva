import { useId, useRef } from "react";
import { cn } from "../lib/cn";
import { headingTag, subHeadingTag, type HeadingLevel } from "../lib/useFocusAfter";
import { ContextIcon, FileIcon, GlobeIcon, MemoryIcon, NotebookIcon, PlusIcon, ToolIcon, XIcon } from "../lib/icons";
import { Button, IconButton } from "../atoms/Button";
import { MeterBar } from "../atoms/MeterBar";

export type ContextKind = "file" | "app" | "memory" | "page" | "instruction";

export interface ContextItem {
  id: string;
  kind: ContextKind;
  /** Its name, such as "Q3 report.pdf" or "Gmail". */
  label: string;
  /** One short line, such as "12 pages" or "Read only". */
  detail?: string;
  /** Items that cannot be taken out here (an app's own instructions). */
  fixed?: boolean;
}

export interface ContextPanelLabels {
  heading?: string;
  /** Receives how many items there are. */
  count?: (n: number) => string;
  groups?: Partial<Record<ContextKind, string>>;
  /** Receives the item's name. */
  remove?: (label: string) => string;
  /** Read out after an item is taken out. Receives its name. */
  removed?: (label: string) => string;
  add?: string;
  empty?: string;
  /** Receives used and total, already formatted. */
  room?: (used: string, total: string) => string;
  /** Name of the bar for screen readers. */
  roomLabel?: string;
}

export interface ContextPanelProps {
  items: ContextItem[];
  /** Takes an item out of what the assistant can see. */
  onRemove: (id: string) => void;
  /** Opens a way to add files or apps. The button is hidden when omitted. */
  onAdd?: () => void;
  /** How much of the assistant's working memory the items fill, as words or tokens. */
  room?: { used: number; total: number };
  labels?: ContextPanelLabels;
  /** Level of the part's heading, so it fits the page outline. Default 3. */
  headingLevel?: HeadingLevel;
  className?: string;
}

const ORDER: ContextKind[] = ["instruction", "page", "file", "app", "memory"];
const ICON: Record<ContextKind, typeof FileIcon> = { file: FileIcon, app: ToolIcon, memory: MemoryIcon, page: GlobeIcon, instruction: NotebookIcon };
const fmt = (n: number) => n.toLocaleString("en-US");

/**
 * Everything the assistant can see right now, in one place: instructions, the open page, files, connected apps and
 * memories, grouped by kind. Each can be taken out with one press, and focus moves to the next item so a keyboard user
 * never lands on nothing. An optional bar shows how full the assistant's working memory is.
 */
export function ContextPanel({ items, onRemove, onAdd, room, labels, headingLevel = 3, className }: ContextPanelProps) {
  const l = {
    heading: "What the assistant can see", count: (n: number) => (n === 1 ? "1 item" : `${n} items`), remove: (x: string) => `Take out ${x}`,
    removed: (x: string) => `${x} taken out.`, add: "Add", empty: "Nothing is shared yet. The assistant only sees this chat.",
    room: (u: string, t: string) => `Uses ${u} of ${t} tokens`, roomLabel: "Working memory used", ...labels,
    groups: { instruction: "Instructions", page: "Open page", file: "Files", app: "Connected apps", memory: "Memories", ...labels?.groups },
  };
  const uid = useId();
  const H = headingTag(headingLevel);
  const H2 = subHeadingTag(headingLevel);
  const list = useRef<HTMLDivElement>(null);
  const said = useRef<HTMLParagraphElement>(null);
  const take = (item: ContextItem) => {
    // Move focus to the next remove button (or the heading) before the row goes, then say what happened.
    const buttons = [...(list.current?.querySelectorAll<HTMLButtonElement>("[data-remove]") ?? [])];
    const at = buttons.findIndex((b) => b.dataset.remove === item.id);
    const next = buttons[at + 1] ?? buttons[at - 1];
    onRemove(item.id);
    if (said.current) said.current.textContent = l.removed(item.label);
    requestAnimationFrame(() => (next && next.isConnected ? next : document.getElementById(`${uid}-h`))?.focus());
  };
  const groups = ORDER.map((k) => ({ kind: k, items: items.filter((i) => i.kind === k) })).filter((g) => g.items.length);
  return (
    <section aria-labelledby={`${uid}-h`} className={cn("rounded-card border border-line bg-surface p-4", className)}>
      <div className="flex items-center gap-2.5">
        <ContextIcon aria-hidden width={18} height={18} className="shrink-0 text-fg-muted" />
        <H id={`${uid}-h`} tabIndex={-1} className="m-0 min-w-0 flex-1 text-body leading-5 font-semibold text-fg outline-none">{l.heading}</H>
        <span className="text-small leading-5 text-fg-muted">{l.count(items.length)}</span>
      </div>
      <div ref={list} className="mt-3 space-y-4">
        {groups.length === 0 && <p className="m-0 text-small leading-5 text-fg-muted">{l.empty}</p>}
        {groups.map((g) => {
          const Icon = ICON[g.kind];
          return (
            <div key={g.kind}>
              <H2 className="m-0 text-small leading-4 font-medium text-fg-muted">{l.groups[g.kind]}</H2>
              <ul className="mt-1.5 space-y-1">
                {g.items.map((i) => (
                  <li key={i.id} className="flex min-h-10 items-center gap-2.5 rounded-control px-2 py-1 hover:bg-hover">
                    <Icon aria-hidden width={16} height={16} className="shrink-0 text-fg-muted" />
                    <span className="min-w-0 flex-1">
                      <span className="line-clamp-2 block text-body leading-5 text-fg">{i.label}</span>
                      {i.detail && <span className="block truncate text-small leading-4 text-fg-muted">{i.detail}</span>}
                    </span>
                    {!i.fixed && (
                      <IconButton size="sm" label={l.remove(i.label)} data-remove={i.id} onClick={() => take(i)}><XIcon width={14} height={14} /></IconButton>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
      {(room || onAdd) && (
        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-3">
          {room && (
            <div className="min-w-0 flex-1 basis-48">
              <p className="m-0 mb-1.5 text-small leading-4 text-fg-muted">{l.room(fmt(room.used), fmt(room.total))}</p>
              <MeterBar value={room.used} max={room.total} warnAt={0.9} label={l.roomLabel} valueText={l.room(fmt(room.used), fmt(room.total))} />
            </div>
          )}
          {onAdd && <Button size="sm" variant="secondary" leading={<PlusIcon aria-hidden width={14} height={14} />} onClick={onAdd}>{l.add}</Button>}
        </div>
      )}
      <p ref={said} role="status" className="sr-only" />
    </section>
  );
}
