import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { CheckIcon } from "../lib/icons";
import { Badge } from "../atoms/Badge";
import { SectionLabel } from "../atoms/SectionLabel";
import { Sheet } from "./Sheet";

export interface GlanceFact { label: string; value: ReactNode; edited?: boolean }
export interface GlanceRule { title: string; cite?: string; href?: string }
export interface GlanceStep { id: string; label: string; state: "done" | "now" | "next"; detail?: string }

export interface GlancePanelProps {
  /** Names the panel (the landmark) and shows at the top. */
  title?: string;
  /** Set when the panel scrolls, so the keyboard can reach its content. */
  scrollable?: boolean;
  /** The first and biggest thing, usually a Countdown. */
  headline?: ReactNode;
  /** Facts under "What I know". A fact with `edited` gets an Edited tag. */
  facts?: GlanceFact[];
  /** The rule the case rests on. */
  rule?: GlanceRule;
  /** The whole journey, in order, under "Where it's at". */
  steps?: GlanceStep[];
  /** Rename the section headings. */
  headings?: { facts?: string; rule?: string; steps?: string };
  /** Hides the visible title but keeps it as the landmark name. GlanceSheet uses this because the sheet already shows the title. */
  hideTitle?: boolean;
  /** Heading level of the section headings. */
  headingLevel?: 2 | 3 | 4;
  className?: string;
}

const stateWord = { done: "Done", now: "Now", next: "Next" } as const;
const HEADING_TAG = { 2: "h2", 3: "h3", 4: "h4" } as const;

function Section({ heading, level, children }: { heading: string; level: 2 | 3 | 4; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-2 border-t border-line pt-4">
      <SectionLabel as={HEADING_TAG[level]}>{heading}</SectionLabel>
      {children}
    </section>
  );
}

/** The things a worried person keeps coming back to, kept in view beside a chat: the deadline, the facts, the rule and the steps. It has no frame of its own. */
export function GlancePanel({ title = "Case file", headline, facts, rule, steps, headings, hideTitle, headingLevel = 2, scrollable, className }: GlancePanelProps) {
  return (
    <aside aria-label={title} tabIndex={scrollable ? 0 : undefined} className={cn("flex min-w-0 flex-col gap-4 text-body leading-5 text-fg", className)}>
      {!hideTitle && <p className="px-1 text-lead leading-6 font-semibold">{title}</p>}
      {headline}
      {facts && facts.length > 0 && (
        <Section heading={headings?.facts ?? "What I know"} level={headingLevel}>
          <dl className="flex flex-col divide-y divide-line">
            {facts.map((f) => (
              <div key={f.label} className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5 px-1 py-2 first:pt-0 last:pb-0">
                <dt className="text-fg-muted">{f.label}</dt>
                <dd className="flex min-w-0 items-center gap-2 text-right font-medium [overflow-wrap:anywhere]">
                  {f.edited && <Badge>Edited</Badge>}
                  <span>{f.value}</span>
                </dd>
              </div>
            ))}
          </dl>
        </Section>
      )}
      {rule && (
        <Section heading={headings?.rule ?? "The rule"} level={headingLevel}>
          <div className="px-1">
            <p className="font-medium">{rule.href ? <a href={rule.href} className="underline underline-offset-2 hover:no-underline">{rule.title}</a> : rule.title}</p>
            {rule.cite && <p className="mt-0.5 text-small leading-5 text-fg-muted">{rule.cite}</p>}
          </div>
        </Section>
      )}
      {steps && steps.length > 0 && (
        <Section heading={headings?.steps ?? "Where it's at"} level={headingLevel}>
          <ol className="flex flex-col">
            {steps.map((s, i) => (
              <li key={s.id} aria-current={s.state === "now" ? "step" : undefined} className="relative flex gap-3 px-1 pb-4 last:pb-0">
                {i < steps.length - 1 && <span aria-hidden className={cn("absolute top-7 bottom-1 left-3.75 w-px", s.state === "done" ? "bg-success" : "bg-line")} />}
                <span aria-hidden className={cn("relative z-10 flex size-6 shrink-0 items-center justify-center rounded-full border text-small leading-4 forced-colors:border-[CanvasText]",
                  s.state === "done" && "border-success bg-success-soft text-success-fg",
                  s.state === "now" && "border-accent bg-surface font-medium text-fg",
                  s.state === "next" && "border-line-strong bg-surface text-fg-subtle")}>
                  {s.state === "done" ? <CheckIcon width={12} height={12} /> : i + 1}
                  {s.state === "now" && <span className="absolute -inset-1 rounded-full border border-accent motion-safe:animate-pulse-dot" />}
                </span>
                <div className="min-w-0 pt-0.5">
                  <p className={cn("leading-5", s.state === "now" ? "font-medium" : s.state === "next" && "text-fg-muted")}>
                    {s.label}<span className="sr-only">, {stateWord[s.state]}</span>
                  </p>
                  {s.detail && <p className="text-small leading-5 text-fg-muted">{s.detail}</p>}
                </div>
              </li>
            ))}
          </ol>
        </Section>
      )}
    </aside>
  );
}

export interface GlanceSheetProps extends GlancePanelProps {
  open: boolean;
  /** Called when the sheet asks to close. Set `open` to false in response. */
  onClose: () => void;
}

/** The phone version: a bottom Sheet around a GlancePanel. Open it from a button in the page's header. */
export function GlanceSheet({ open, onClose, title = "Case file", className, ...panel }: GlanceSheetProps) {
  return (
    <Sheet open={open} onClose={onClose} title={title} size="lg">
      <GlancePanel {...panel} title={title} hideTitle className={cn("pb-4", className)} />
    </Sheet>
  );
}
