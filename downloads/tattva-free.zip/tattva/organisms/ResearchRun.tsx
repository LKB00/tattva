import { useEffect, useId, useRef, useState } from "react";
import { cn } from "../lib/cn";
import { headingTag, type HeadingLevel } from "../lib/useFocusAfter";
import { AlertIcon, CheckIcon, SearchIcon } from "../lib/icons";
import { Button } from "../atoms/Button";

export interface ResearchPhase {
  id: string;
  /** What happens in this phase, such as "Searching the web". */
  label: string;
  state: "done" | "active" | "waiting";
}

export interface ResearchRunLabels {
  heading?: string;
  /** Receives the number of sources read. */
  sources?: (n: number) => string;
  /** Receives the time so far, such as "4 min". */
  elapsed?: (t: string) => string;
  stop?: string;
  open?: string;
  /** Receives sources read and the time taken. */
  doneSummary?: (n: number, t: string) => string;
  stopped?: string;
  failed?: string;
  retry?: string;
  phaseNow?: (label: string) => string;
}

export interface ResearchRunProps {
  /** What is being researched, in the person's words. */
  question: string;
  status: "running" | "done" | "stopped" | "failed";
  phases: ResearchPhase[];
  /** Sources read so far. */
  sourcesRead: number;
  /** Time so far, already in words: "4 min". */
  elapsed: string;
  /** What it is doing this moment, such as "Reading reuters.com". Shown while running. */
  activity?: string;
  onStop?: () => void;
  /** Opens the finished report. */
  onOpenReport?: () => void;
  onRetry?: () => void;
  labels?: ResearchRunLabels;
  /** Level of the part's heading, so it fits the page outline. Default 3. */
  headingLevel?: HeadingLevel;
  className?: string;
}

/**
 * A deep research run, which can take many minutes. While it runs it shows the phases (done, now, next), how many
 * sources it has read and for how long, and what it is reading this moment; Stop is always there. Screen readers
 * hear each new phase, not every source. When it finishes, the card says what it did in one line and opens the report.
 */
export function ResearchRun({ question, status, phases, sourcesRead, elapsed, activity, onStop, onOpenReport, onRetry, labels, headingLevel = 3, className }: ResearchRunProps) {
  const l = {
    heading: "Research", sources: (n: number) => (n === 1 ? "1 source read" : `${n} sources read`), elapsed: (t: string) => t, stop: "Stop", open: "Open report",
    doneSummary: (n: number, t: string) => `Read ${n} sources in ${t}.`, stopped: "Stopped. The report covers what was read so far.", failed: "The research stopped because of an error.",
    retry: "Try again", phaseNow: (p: string) => `Now: ${p}`, ...labels,
  };
  const uid = useId();
  const H = headingTag(headingLevel);
  const active = phases.find((p) => p.state === "active");
  // Announce each new phase once, not each source.
  const [said, setSaid] = useState("");
  const last = useRef<string | undefined>(undefined);
  useEffect(() => { if (status === "running" && active && active.id !== last.current) { last.current = active.id; setSaid(l.phaseNow(active.label)); } }, [status, active]);
  const running = status === "running";
  return (
    <section aria-labelledby={`${uid}-h`} aria-busy={running || undefined} className={cn("rounded-card border border-line bg-surface p-4", className)}>
      <div className="flex items-start gap-2.5">
        <SearchIcon aria-hidden width={18} height={18} className="mt-0.5 shrink-0 text-fg-muted" />
        <div className="min-w-0 flex-1">
          <H id={`${uid}-h`} className="m-0 text-small leading-4 font-medium text-fg-muted">{l.heading}</H>
          <p className="m-0 mt-1 text-body leading-6 font-medium text-fg">{question}</p>
        </div>
      </div>

      <ol className="mt-4 space-y-2">
        {phases.map((p) => (
          <li key={p.id} className="flex items-center gap-2.5" aria-current={p.state === "active" ? "step" : undefined}>
            <span aria-hidden className={cn("grid size-5 shrink-0 place-items-center rounded-full",
              p.state === "done" ? "bg-success-soft text-success-fg" : p.state === "active" ? "border-2 border-lime" : "border border-line-strong")}>
              {p.state === "done" && <CheckIcon width={12} height={12} />}
              {p.state === "active" && <span className={cn("size-2 rounded-full bg-lime", running && "motion-safe:animate-pulse")} />}
            </span>
            <span className={cn("text-body leading-5", p.state === "waiting" ? "text-fg-muted" : "text-fg", p.state === "active" && "font-medium")}>{p.label}</span>
            <span className="sr-only">{p.state === "done" ? "(done)" : p.state === "active" ? "(now)" : "(next)"}</span>
          </li>
        ))}
      </ol>

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2">
        <p className="m-0 text-small leading-5 text-fg-muted tabular-nums">{l.sources(sourcesRead)} · {l.elapsed(elapsed)}</p>
        {running && activity && <p className="m-0 min-w-0 flex-1 truncate text-small leading-5 text-fg-muted" title={activity}>{activity}</p>}
      </div>

      {status === "done" && <p className="m-0 mt-3 text-body leading-6 text-fg">{l.doneSummary(sourcesRead, elapsed)}</p>}
      {status === "stopped" && <p className="m-0 mt-3 text-body leading-6 text-fg">{l.stopped}</p>}
      {status === "failed" && <p className="m-0 mt-3 inline-flex items-center gap-1.5 text-body leading-6 text-danger-fg"><AlertIcon aria-hidden width={15} height={15} />{l.failed}</p>}

      <div className="mt-4 flex flex-wrap gap-2">
        {running && onStop && <Button size="sm" variant="secondary" onClick={onStop}>{l.stop}</Button>}
        {(status === "done" || status === "stopped") && onOpenReport && <Button size="sm" onClick={onOpenReport}>{l.open}</Button>}
        {status === "failed" && onRetry && <Button size="sm" variant="secondary" onClick={onRetry}>{l.retry}</Button>}
      </div>
      <p role="status" className="sr-only">{status === "done" ? l.doneSummary(sourcesRead, elapsed) : status === "stopped" ? l.stopped : status === "failed" ? l.failed : said}</p>
    </section>
  );
}
