Tattva for Figma 0.29.1

To use it in Figma (desktop app):
1. Unzip this folder.
2. In Figma, open Plugins > Development > Import plugin from manifest...
3. Pick manifest.json from this folder.
4. Run it from Plugins > Development > Tattva.

Add to file: creates colour variables (Light and Dark) for one of Tattva's seven themes, and optionally
corner, spacing and type-size variables and text styles. Running it again updates them.
Insert parts: adds any of Tattva's parts as Figma components, with colours linked to the Tattva
variables. Each part's properties match its React props: style, size, on/off settings, text and, for controls,
State (hover, pressed, focus, disabled), so one instance switches everything from the properties panel.
Check design: checks the selected frames or the page for contrast, text size, the AI colour used as text,
tap size and colours that are not Tattva tokens.

Guidance for every part: https://lkb00.github.io/tattva/
