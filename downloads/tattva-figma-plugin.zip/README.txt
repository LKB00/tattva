Tattva for Figma 0.17.3

To use it in Figma (desktop app):
1. Unzip this folder.
2. In Figma, open Plugins > Development > Import plugin from manifest...
3. Pick manifest.json from this folder.
4. Run it from Plugins > Development > Tattva.

Add to file: creates colour variables (Light and Dark) for one of Tattva's seven themes, and optionally
corner, spacing and type-size variables and text styles. Running it again updates them.
Insert parts: adds Tattva's free parts as Figma components with their variants, with colours linked to
the Tattva variables. Pro parts come with Tattva Pro: https://lkb00.github.io/tattva/pricing/
Check design: checks the selected frames or the page for contrast, text size, the AI colour used as text,
tap size and colours that are not Tattva tokens.

Guidance for every part: https://lkb00.github.io/tattva/
