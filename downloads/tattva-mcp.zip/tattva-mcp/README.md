# Tattva MCP server

Lets an AI coding tool (Claude Code, Cursor, Claude Desktop and others) look up Tattva parts, colours and rules, plan a build, and check its own code. It only reads. It never changes your project.

## What you need
Node.js 18 or newer. Check with `node --version` in a terminal. Get it from https://nodejs.org if it is missing.

## Connect it (about two minutes)
1. Unzip this folder somewhere you will keep it, for example your home folder.
2. Find the full path to `mcp-server.mjs` in that folder. In a terminal, `pwd` inside the folder shows it.
3. Connect your tool:

**Claude Code:** run this once in a terminal, with your own path:

    claude mcp add tattva -- node /full/path/to/mcp-server.mjs

**Cursor:** create `.cursor/mcp.json` in your project (or use Settings, then MCP):

    { "mcpServers": { "tattva": { "command": "node", "args": ["/full/path/to/mcp-server.mjs"] } } }

**Claude Desktop:** open Settings, then Developer, then Edit Config, and add:

    { "mcpServers": { "tattva": { "command": "node", "args": ["/full/path/to/mcp-server.mjs"] } } }

4. Restart the tool. Ask it: "Use Tattva to build a chat assistant for my bank." It should ask you a few questions first.

## Where it gets its information
From https://lkb00.github.io/tattva/ when it starts, so it needs an internet connection. It can read every part's guidance and the free parts' code. The code for Pro parts comes with the Pro download.

## Tools it gives your AI
search_components, get_component, list_patterns, get_themes, get_tokens, start_project, plan_build, review_code.

More: https://lkb00.github.io/tattva/#connect-ai
