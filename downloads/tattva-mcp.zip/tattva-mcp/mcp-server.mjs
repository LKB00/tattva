#!/usr/bin/env node
// Tattva MCP server. Zero dependencies. Speaks newline-delimited JSON-RPC 2.0 over stdio.
// Read-only: it reads public/components.json, public/tokens.dtcg.json, public/themes.json and public/llms.txt and never writes.
// Run `node scripts/export-assets.mjs` first so those files exist.
import { readFileSync, existsSync } from "node:fs";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { QUESTIONS, planBuild, reviewCode } from "./mcp-guide.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const PROTOCOL = "2025-06-18";
const SITE = "https://lkb00.github.io/tattva/";
// Settings are read as TATTVA_*; the names from before the rename (SANDSTONE_*) still work.
for (const k of ["DATA", "API", "LICENSE_KEY"]) if (!process.env[`TATTVA_${k}`] && process.env[`SANDSTONE_${k}`]) process.env[`TATTVA_${k}`] = process.env[`SANDSTONE_${k}`];
// Where the data files come from, in this order: a folder named in TATTVA_DATA; a `data` folder next to this file
// (the Pro download ships one, with the full code); `../public` (inside the Tattva repo); the live site (the small
// public download needs nothing else, so the free parts and every part's guidance still work).
const DATA_DIRS = [process.env.TATTVA_DATA, join(here, "data"), join(here, "..", "public")].filter(Boolean);
const FILES = ["components.json", "tokens.dtcg.json", "themes.json", "llms.txt"];
const data = {};
const dataDir = DATA_DIRS.find((d) => FILES.every((f) => existsSync(join(d, f))));
for (const f of FILES) {
  if (dataDir) { data[f] = readFileSync(join(dataDir, f), "utf8"); continue; }
  try {
    const r = await fetch(SITE + f);
    if (!r.ok) throw new Error(String(r.status));
    data[f] = await r.text();
  } catch (e) {
    process.stderr.write(`Tattva MCP: could not read ${f} locally or from ${SITE} (${e.message}). Check your internet connection, or set TATTVA_DATA to a folder holding the four data files.\n`);
    process.exit(1);
  }
}
// Pro and Team buyers can add their licence key instead of keeping the Pro download's data folder:
// TATTVA_LICENSE_KEY=<key from the receipt email>, and TATTVA_API=<the Tattva API address>. The API checks the
// key and sends every part with its full code. If the check fails, the server says why and carries on with the free data.
if (process.env.TATTVA_LICENSE_KEY && process.env.TATTVA_API && !process.env.TATTVA_DATA) {
  try {
    const r = await fetch(new URL("v1/pro/components.json", process.env.TATTVA_API.replace(/\/?$/, "/")), { headers: { authorization: `Bearer ${process.env.TATTVA_LICENSE_KEY.trim()}` } });
    const body = await r.text();
    if (r.ok) data["components.json"] = body;
    else process.stderr.write(`Tattva MCP: Pro code stays locked. ${JSON.parse(body).message ?? r.status}\n`);
  } catch (e) {
    process.stderr.write(`Tattva MCP: could not reach the Tattva API (${e.message}), so Pro code stays locked. The free parts and all guidance still work.\n`);
  }
}
const readJson = (rel) => JSON.parse(data[rel.replace(/^public\//, "")]);
const components = () => readJson("public/components.json").components;

const lev = (a, b) => {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
};
const norm = (s) => String(s).toLowerCase().replace(/[^a-z0-9]/g, "");
const suggest = (q, list) => {
  const n = norm(q);
  return list.map((c) => ({ c, s: norm(c.id).includes(n) || n.includes(norm(c.id)) ? 0 : lev(n, norm(c.id)) })).sort((a, b) => a.s - b.s).slice(0, 4).map((x) => x.c.id);
};

const fail = (message) => ({ isError: true, content: [{ type: "text", text: message }] });
const ok = (text, structured) => ({ content: [{ type: "text", text }], structuredContent: structured });

const tools = [
  {
    name: "search_components",
    description: "Find Tattva components by what they are for. Searches names, summaries and descriptions. Use this first when you do not know the component id. Returns up to 15 matches with id, name, category, status and a one-line summary. Read-only.",
    inputSchema: { type: "object", properties: {
      query: { type: "string", description: "Words describing what you need, for example \"ask before deleting\" or \"chart\". Leave empty to list everything in a category." },
      category: { type: "string", description: "Optional. One of: conversation, agents, trust, creating, numbers, states, controls, screens." },
      status: { type: "string", enum: ["stable", "experimental"], description: "Optional. Experimental parts rest on design reasoning only and may change." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "get_component",
    description: "Get everything needed to use one Tattva component correctly: props with types and defaults, when to use it, what to avoid, accessibility rules, the exact import line, tokens it uses and one example. Call it with an id from search_components. Read-only.",
    inputSchema: { type: "object", properties: {
      id: { type: "string", description: "Component id in kebab-case, for example \"permission-prompt\". The component name (PermissionPrompt) also works." },
      all_examples: { type: "boolean", description: "Return every example instead of the first one. Default false." },
    }, required: ["id"], additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "list_patterns",
    description: "List Tattva's patterns: short answers to situations like \"the assistant wants to do something that cannot be undone\". Each has a question, an answer and a page link. Use this to choose an approach before choosing components. Read-only.",
    inputSchema: { type: "object", properties: { query: { type: "string", description: "Optional word filter, for example \"source\" or \"undo\"." } }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "start_project",
    description: "Call this FIRST when a person wants to build something with Tattva, unless a tattva.md brief already exists in their project (then read it instead). Returns a short list of questions to ask the person, each with options and a default. Ask them in plain words, skip any the person has already answered, and accept \"defaults\". Then call plan_build with the answers. Read-only.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "plan_build",
    description: "Turn the person's answers into a build plan: setup steps, the parts to use in build order (marking which are Pro), patterns to read, warnings, and a project brief to save as tattva.md in their project. Call it after start_project. Missing answers fall back to defaults. Read-only.",
    inputSchema: { type: "object", properties: {
      product: { type: "string", enum: ["chat-assistant", "agent-console", "creative-tool", "generative-ui", "ai-dashboard"], description: "What is being built." },
      stack: { type: "string", enum: ["new-vite", "new-next", "existing"], description: "New or existing project, and framework." },
      theme: { type: "string", enum: ["lime", "teal", "indigo", "harbor", "plum", "graphite"], description: "Colour theme. Default lime." },
      mode: { type: "string", enum: ["both", "light", "dark"], description: "Light, dark or both. Default both." },
      trust: { type: "array", items: { type: "string", enum: ["sources", "confidence", "approvals", "undo", "memory", "disclosure", "feedback", "errors"] }, description: "Trust behaviours the product needs." },
      plan: { type: "string", enum: ["free", "pro"], description: "The person's plan. Default free." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "review_code",
    description: "Check code you wrote against Tattva's rules before you finish: typed hex colours, raw colour functions, Tailwind's default palette, deep imports, clickable divs, icon buttons with no label, images with no alt, lime used as text, removed focus outlines, vague destructive buttons, and parts that do not exist. Pass the file's code. Fix every error and re-run until none are left. Read-only; nothing is written.",
    inputSchema: { type: "object", properties: {
      code: { type: "string", description: "The full source of one file (TSX, JSX, CSS or HTML)." },
      filename: { type: "string", description: "Optional file name, shown in the result." },
    }, required: ["code"], additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "get_themes",
    description: "List Tattva's colour themes (lime, teal, indigo, harbor, plum, graphite, terminal) or get one in full: its AI color in light and dark, paper and ink, the two soft wash colors, how to switch to it, and every token that differs from the default. A theme changes the greys and the AI color only; amber and the status colors never change. Read-only.",
    inputSchema: { type: "object", properties: { id: { type: "string", description: "Optional theme id, for example \"indigo\". Omit to list all themes." } }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "get_tokens",
    description: "Get Tattva design tokens (colors, timing, sizes, shadows) with what each is for. Use token names in CSS as var(--name) or as Tailwind classes. Never type a hex value in generated code. Read-only.",
    inputSchema: { type: "object", properties: {
      group: { type: "string", description: "Optional group: surfaces, lines, text, actions, attention, status, direction, reserved, code, charts, size, motion, shadow. Omit to list the group names with counts." },
      mode: { type: "string", enum: ["light", "dark"], description: "Light or dark values. Default light." },
      theme: { type: "string", description: "Optional colour theme id (see get_themes), for example \"indigo\". Returns that theme's colors. Default lime." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
];

const handlers = {
  search_components({ query = "", category, status } = {}) {
    const all = components();
    const cats = [...new Set(all.map((c) => c.category).filter(Boolean))];
    if (category && !cats.includes(category)) return fail(`Unknown category "${category}". Use one of: ${cats.join(", ")}.`);
    // Plain-language search: drop filler words, match word stems, and let rare words count for more than common ones.
    const STOP = new Set("a an the and or of to for in on at by with from into is are be it its this that these those i we you your my our me us user users person people need needs want wants let lets make makes show shows showing display displays place way something thing things when while before after so can should would could will do does how what which where who ai".split(" "));
    const stem = (w) => w.replace(/(ing|ed|es|s|ly)$/, (m, x, i) => (i > 3 ? "" : m));
    const tok = (t) => String(t).toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/[\s-]+/).filter(Boolean);
    const SAME = { got: "came", get: "come", gets: "comes", citation: "source", citations: "sources", cite: "source", reference: "source", references: "sources" };
    const words = [...new Set(tok(query).filter((w) => !STOP.has(w)).map((w) => stem(SAME[w] ?? w)))].filter((w) => w.length > 1);
    const field = (c) => ({
      name: tok(`${c.id} ${c.name}`).map(stem),
      head: tok(`${c.summary} ${c.purpose ?? ""} ${(c.useFor ?? []).join(" ")}`).map(stem),
      body: tok(`${c.description} ${c.whenToUse.join(" ")}`).map(stem),
    });
    const pool = all.filter((c) => (!category || c.category === category) && (!status || c.status === status));
    const fields = new Map(pool.map((c) => [c, field(c)]));
    const df = (w) => pool.filter((c) => { const f = fields.get(c); return f.name.includes(w) || f.head.includes(w) || f.body.includes(w); }).length;
    const idf = new Map(words.map((w) => [w, Math.log(1 + pool.length / (1 + df(w)))]));
    const scored = pool.map((c) => {
      const f = fields.get(c);
      let s = 0;
      for (const w of words) s += idf.get(w) * ((f.name.includes(w) ? 5 : 0) + (f.head.includes(w) ? 3 : 0) + (f.body.includes(w) ? 1 : 0));
      return { c, s };
    }).filter((x) => !words.length || x.s > 0).sort((a, b) => b.s - a.s);
    const results = scored.slice(0, 15).map(({ c }) => ({ id: c.id, name: c.name, category: c.category, status: c.status, summary: c.summary }));
    if (!results.length) return ok(`No components match "${query}". Try fewer or simpler words, or filter by category: ${cats.join(", ")}.`, { results: [], total: 0 });
    const text = `${scored.length} match${scored.length === 1 ? "" : "es"}${scored.length > 15 ? " (showing 15)" : ""}:\n` + results.map((r) => `- ${r.id} (${r.name}, ${r.category}, ${r.status}): ${r.summary}`).join("\n") + "\nNext: call get_component with an id.";
    return ok(text, { results, total: scored.length });
  },
  get_component({ id, all_examples = false } = {}) {
    if (!id) return fail("Missing `id`. Call search_components first to find one, for example id: \"button\".");
    const all = components();
    const n = norm(id);
    let c = all.find((x) => x.id === id) ?? all.find((x) => norm(x.id) === n || norm(x.name) === n);
    if (!c) return fail(`No component called "${id}". Did you mean: ${suggest(id, all).join(", ")}? Call search_components to browse.`);
    // The docs are written for the Tattva repo (./index). In a person's project free parts come from the npm package
    // and Pro parts from the tattva folder of the Pro download.
    const toKit = (x) => String(x).replace(/from "\.\/index"/g, c.plan === "pro" ? 'from "./tattva"' : 'from "@tattva/ui"');
    c = { ...c, importPath: toKit(c.importPath) };
    const examples = (all_examples ? c.examples : c.examples.slice(0, 1)).map((e) => ({ ...e, code: toKit(e.code) }));
    // A Pro part without an unlocked licence has no code. Say so, so the assistant never writes its own version.
    const locked = c.plan === "pro" && examples.every((e) => !e.code.trim());
    const data = {
      id: c.id, name: c.name, level: c.level, category: c.category, status: c.status, lifecycle: c.lifecycle ?? null, states: c.states ?? [], summary: c.summary, description: c.description,
      importPath: c.importPath, sourcePath: c.sourcePath,
      props: c.props, variantsHint: c.variantsHint,
      purpose: c.purpose ?? null, useFor: c.useFor ?? [], notFor: c.notFor ?? [],
      whenToUse: c.whenToUse, avoid: c.avoid, accessibility: c.accessibility, accessibilityYouDo: c.accessibilityYouDo ?? [],
      tokens: c.tokens, related: c.related, composedOf: c.composedOf, codeAvailable: !locked, examples, pageUrl: c.pageUrl, markdownUrl: c.markdownUrl,
    };
    const list = (a) => a.map((x) => `- ${x}`).join("\n");
    const text = [
      `${c.name} (${c.id}, ${c.level}, ${c.status})`, c.summary,
      c.lifecycle && (c.lifecycle.stage === "deprecated" || c.lifecycle.stage === "retired") ? `WARNING: ${c.name} is ${c.lifecycle.stage}. ${c.lifecycle.note ?? ""} Use ${c.lifecycle.replacedBy} instead.` : "",
      "", c.importPath, "",
      "Props:", ...c.props.map((p) => `- ${p.name}${p.required ? " (required)" : ""}: ${p.type}${p.default ? ` = ${p.default}` : ""}. ${p.description}`), "",
      c.purpose ? `When to use it: ${c.purpose}` : "", c.notFor?.length ? `Not for:\n${list(c.notFor.map((n) => n.use ? `${n.text}: use ${n.use}` : n.text))}` : "",
      "Do:", list(c.whenToUse), "Avoid:", list(c.avoid), "Accessibility (built in):", list(c.accessibility),
      c.accessibilityYouDo?.length ? `Accessibility (you must):\n${list(c.accessibilityYouDo)}` : "",
      c.states?.length ? `States:\n${list(c.states.map((x) => `${x.name}: ${x.note}`))}` : "",
      c.related.length ? `Related: ${c.related.join(", ")}` : "",
      "", ...(locked
        ? [`Code: locked. ${c.name} is a Pro part, so this server has no code for it. Do not write your own version. Use a free part instead, or tell the person it needs Tattva Pro (set TATTVA_LICENSE_KEY to unlock it).`, ...examples.map((e) => `Example (no code): ${e.title}`)]
        : examples.flatMap((e) => [`Example: ${e.title}`, "```tsx", e.code, "```"])),
    ].filter((x) => x !== "").join("\n");
    return ok(text, data);
  },
  list_patterns({ query = "" } = {}) {
    const txt = data["llms.txt"];
    const sec = txt.split(/^## /m).find((s) => s.startsWith("Patterns")) ?? "";
    let patterns = sec.split("\n").filter((l) => l.startsWith("- ")).map((l) => {
      const m = l.match(/^- ([^:]+): (.*) \((https?:\/\/[^)]+)\)$/);
      if (!m) return null;
      const url = m[3]; const q = m[2].match(/^(.*?\?)\s*(.*)$/);
      return { id: url.split("#pattern-")[1] ?? "", title: m[1], question: q ? q[1] : "", answer: q ? q[2] : m[2], url };
    }).filter(Boolean);
    const words = String(query).toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length) patterns = patterns.filter((p) => words.some((w) => `${p.title} ${p.question} ${p.answer}`.toLowerCase().includes(w)));
    if (!patterns.length) return ok(`No patterns match "${query}". Call list_patterns with no query to see all of them.`, { patterns: [] });
    return ok(patterns.map((p) => `- ${p.title}: ${p.question} ${p.answer}\n  ${p.url}`).join("\n"), { patterns });
  },
  start_project() {
    const lines = QUESTIONS.map((q, i) => `${i + 1}. ${q.question}\n${q.options.map((o) => `   - ${o.value}: ${o.label}${(Array.isArray(q.default) ? q.default.includes(o.value) : q.default === o.value) ? "  [default]" : ""}`).join("\n")}`);
    return ok(["Before building, ask the person these questions in plain words (one message, not one at a time). Skip any they have already answered. If they say \"defaults\", use the defaults.", "", ...lines, "", "Then call plan_build with the answers. If the project already has a tattva.md brief, read it and only ask what is missing."].join("\n"), { questions: QUESTIONS });
  },
  plan_build(args = {}) {
    const r = planBuild(args, components());
    if (r.error) return fail(r.error);
    const groups = [...new Set(r.parts.map((p) => p.group))];
    const text = [
      `Plan: ${r.recipe.title}. Theme ${r.answers.theme}, ${r.answers.mode} mode, ${r.answers.plan} plan.`, "",
      "Setup:", ...r.setup.map((x, i) => `${i + 1}. ${x}`), "",
      "Run these commands, in order:", ...r.commands.map((c) => `  ${c}`), "",
      "Write these files exactly as given (overwrite the ones the template created):", ...r.files.flatMap((f) => ["", `--- ${f.path} (${f.why}) ---`, f.content.trimEnd()]), "",
      "Setup is not finished until the commands have run and every file above is written. Then you write src/App.tsx, importing parts from \"./tattva\". On the free plan the kit holds the free parts only: if the plan lists Pro parts, their code is not installed, so tell the person and do not pretend they are there. On Pro or Team, ask the person where their tattva-pro.zip is.", "",
      "Parts, in build order:", ...groups.flatMap((g) => [`${g}:`, ...r.parts.filter((p) => p.group === g).map((p) => `- ${p.name} (${p.id})${p.plan === "pro" ? " [Pro]" : ""}: ${p.why}`)]), "",
      `Patterns to read first: call list_patterns with the words ${r.patterns.map((x) => `"${x}"`).join(", ")}.`,
      ...(r.warnings.length ? ["", "Heads up:", ...r.warnings.map((w) => `- ${w}`)] : []),
      "", "Next: for each part call get_component for its props and an example, then build. When a file is done, call review_code on it and fix every error.", "", "(The brief is written to tattva.md above.)",
    ].join("\n");
    return ok(text, r);
  },
  review_code({ code, filename = "" } = {}) {
    if (typeof code !== "string" || !code.trim()) return fail("Pass the file's source as `code`.");
    const r = reviewCode(code, components(), filename);
    const label = filename ? ` in ${filename}` : "";
    if (!r.findings.length) return ok(`No problems found${label}. The code follows the Tattva rules this checker can see. It cannot judge layout or wording, so still check the result on screen.`, r);
    const text = [`${r.counts.error} error${r.counts.error === 1 ? "" : "s"}, ${r.counts.warn} warning${r.counts.warn === 1 ? "" : "s"}, ${r.counts.info} note${r.counts.info === 1 ? "" : "s"}${label}. Fix the errors and run review_code again.`, "", ...r.findings.map((f) => `line ${f.line} [${f.level}] ${f.rule}: ${f.text}\n   Fix: ${f.fix}`)].join("\n");
    return ok(text, r);
  },
  get_themes({ id } = {}) {
    const all = readJson("public/themes.json").themes;
    if (!id) {
      const lines = all.map((t) => `- ${t.id}${t.default ? " (default)" : ""}: ${t.name}, ${t.note}. AI color ${t.ai.light} (light) / ${t.ai.dark} (dark). Use: ${t.use}`);
      return ok(`Tattva colour themes. A theme changes the greys and the AI color (--lime) in light and dark. Amber and the status colors never change. Switch with data-palette on the html element.\n${lines.join("\n")}\nCall get_themes with an id for the full set of values.`, { themes: all.map(({ colors, ...t }) => t) });
    }
    const t = all.find((x) => x.id === String(id).toLowerCase());
    if (!t) return fail(`No theme called "${id}". Use one of: ${all.map((x) => x.id).join(", ")}.`);
    const n = (o) => Object.keys(o).length;
    const lines = [`${t.name}${t.default ? " (default)" : ""}: ${t.note}`, `Use: ${t.use}`, `AI color (--lime): ${t.ai.light} light, ${t.ai.dark} dark`, `Paper (--bg): ${t.paper.light} light, ${t.paper.dark} dark`, `Ink (--fg): ${t.ink.light} light, ${t.ink.dark} dark`, `Soft wash (--ai-wash-1, --ai-wash-2): ${t.wash.light?.join(", ")} light${t.wash.dark ? `; ${t.wash.dark.join(", ")} dark` : ""}`, `Tokens that differ from the default: ${n(t.colors.light)} light, ${n(t.colors.dark)} dark. Call get_tokens with theme "${t.id}" to read them. In code, keep using var(--name); never type these hex values.`];
    return ok(lines.join("\n"), t);
  },
  get_tokens({ group, mode = "light", theme } = {}) {
    if (!["light", "dark"].includes(mode)) return fail(`Unknown mode "${mode}". Use "light" or "dark".`);
    const t = readJson("public/tokens.dtcg.json");
    let themeColors = null;
    if (theme) {
      const th = readJson("public/themes.json").themes.find((x) => x.id === String(theme).toLowerCase());
      if (!th) return fail(`No theme called "${theme}". Call get_themes to see the ids.`);
      themeColors = th.colors[mode];
    }
    const cols = t.color[mode];
    const names = { surfaces: "color", lines: "color", text: "color", actions: "color", attention: "color", status: "color", code: "color", charts: "color", other: "color", size: "size", fontSize: "fontSize", motion: "duration", shadow: "shadow" };
    const flat = (g, kind, o) => Object.entries(o).filter(([k]) => !k.startsWith("$")).map(([k, v]) => {
      const val = v.$type === "color" ? v.$value.hex : v.$type === "duration" || v.$type === "dimension" ? `${v.$value.value}${v.$value.unit}` : v.$type === "cubicBezier" ? `cubic-bezier(${v.$value.join(", ")})` : v.$type === "shadow" ? (v.$extensions?.css ?? JSON.stringify(v.$value)) : JSON.stringify(v.$value);
      return { name: `--${k}`, type: v.$type, value: val, description: v.$description ?? "", group: g };
    });
    const groups = {};
    for (const [g, o] of Object.entries(cols)) groups[g] = flat(g, "color", o).map((x) => (themeColors?.[x.name] ? { ...x, value: themeColors[x.name] } : x));
    groups.size = [...flat("size", "dimension", t.size ?? {}), ...flat("size", "dimension", t.fontSize ?? {})];
    groups.motion = [...flat("motion", "duration", t.duration ?? {}), ...flat("motion", "cubicBezier", t.easing ?? {})];
    groups.shadow = flat("shadow", "shadow", t.shadow?.[mode] ?? {});
    if (!group) {
      const summary = Object.entries(groups).map(([g, a]) => ({ group: g, count: a.length }));
      return ok(`Token groups (${mode}): ${summary.map((s) => `${s.group} (${s.count})`).join(", ")}.\nCall get_tokens with a group to see names and values. Use names as var(--name). Never write hex values in components.`, { mode, groups: summary });
    }
    if (!groups[group]) return fail(`No token group called "${group}". Use one of: ${Object.keys(groups).join(", ")}.`);
    return ok(groups[group].map((x) => `${x.name} = ${x.value}${x.description ? `  (${x.description})` : ""}`).join("\n"), { mode, group, tokens: groups[group] });
  },
};

const send = (m) => process.stdout.write(JSON.stringify(m) + "\n");
const reply = (id, result) => send({ jsonrpc: "2.0", id, result });
const error = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });

function handle(msg) {
  const { id, method, params } = msg;
  const isNote = id === undefined || id === null;
  if (method === "initialize") {
    return reply(id, { protocolVersion: params?.protocolVersion ?? PROTOCOL, capabilities: { tools: { listChanged: false }, prompts: { listChanged: false } }, serverInfo: { name: "tattva", version: "0.1.0" },
      instructions: "Tattva is a design system for AI products. To build something: (1) if the project has a tattva.md brief, read it; otherwise call start_project and ask the person its questions, then call plan_build, then run its commands and write its files exactly as given before anything else. (2) For each part call get_component, then import from the package index. (3) Use tokens, never hex values. The AI colour (--lime) is a fill, never text; amber means a person has to act. (4) If nothing fits what the person asked for, say so and ask; never invent a part, a prop or a colour. (5) Before finishing, call review_code on every file you wrote and fix all errors. Parts marked Pro have free previews but code that needs a Pro or Team plan; tell the person before using them." });
  }
  if (method === "notifications/initialized" || method?.startsWith("notifications/")) return;
  if (method === "ping") return reply(id, {});
  if (method === "tools/list") return reply(id, { tools });
  if (method === "prompts/list") return reply(id, { prompts: [{ name: "build", title: "Build with Tattva", description: "Start a guided build: a few questions, then a plan, then a check of the code.", arguments: [{ name: "idea", description: "Optional: what you want to build, in a sentence.", required: false }] }] });
  if (method === "prompts/get") {
    if (params?.name !== "build") return error(id, -32602, `Unknown prompt "${params?.name}". Available: build.`);
    const idea = params?.arguments?.idea ? ` The person wants to build: ${params.arguments.idea}.` : "";
    return reply(id, { description: "Build with Tattva", messages: [{ role: "user", content: { type: "text", text: `Help me build a product with the Tattva design system.${idea} Start by calling the start_project tool and ask me its questions, then call plan_build, then build it part by part, and run review_code on every file before you finish.` } }] });
  }
  if (method === "tools/call") {
    const h = handlers[params?.name];
    if (!h) return reply(id, fail(`Unknown tool "${params?.name}". Available tools: ${tools.map((t) => t.name).join(", ")}.`));
    try { return reply(id, h(params.arguments ?? {})); } catch (e) { return reply(id, fail(String(e.message ?? e))); }
  }
  if (!isNote) error(id, -32601, `Method not found: ${method}`);
}

createInterface({ input: process.stdin }).on("line", (line) => {
  if (!line.trim()) return;
  let msg;
  try { msg = JSON.parse(line); } catch { return error(null, -32700, "Parse error: send one JSON-RPC message per line."); }
  try { handle(msg); } catch (e) { if (msg.id !== undefined) error(msg.id, -32603, String(e.message ?? e)); }
});
