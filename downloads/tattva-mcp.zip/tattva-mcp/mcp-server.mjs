#!/usr/bin/env node
// Tattva MCP server. Zero dependencies. Speaks newline-delimited JSON-RPC 2.0 over stdio.
// Read-only: it reads public/components.json, public/tokens.dtcg.json, public/themes.json, public/llms.txt and (when
// present) public/changelog.json, and never writes. Inside a project it also reads the installed @tattva/ui version,
// and files that review_code is asked to check, and only files under the folder it was started in.
// Run `node scripts/export-assets.mjs` first so those files exist.
import { readFileSync, existsSync, realpathSync } from "node:fs";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve, sep } from "node:path";
import { PLAIN_WORDS, QUESTIONS, buildPrompt, planBuild, reviewCode } from "./mcp-guide.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const PROTOCOL = "2025-06-18";
const SITE = "https://lkb00.github.io/tattva/";
// Settings are read as TATTVA_*; the names from before the rename (SANDSTONE_*) still work.
for (const k of ["DATA", "API", "LICENSE_KEY"]) if (!process.env[`TATTVA_${k}`] && process.env[`SANDSTONE_${k}`]) process.env[`TATTVA_${k}`] = process.env[`SANDSTONE_${k}`];
// Where the data files come from, in this order: a folder named in TATTVA_DATA; a `data` folder next to this file
// (the Pro download ships one, with the full code); `../public` (inside the Tattva repo); the live site (the small
// public download needs nothing else, so the free parts and every part's guidance still work).
const DATA_DIRS = [process.env.TATTVA_DATA, join(here, "data"), join(here, "..", "public")].filter(Boolean);
const FILES = ["components.json", "tokens.dtcg.json", "themes.json", "llms.txt"];
const data = {};
const dataDir = DATA_DIRS.find((d) => FILES.every((f) => existsSync(join(d, f))));
for (const f of FILES) {
  if (dataDir) { data[f] = readFileSync(join(dataDir, f), "utf8"); continue; }
  try {
    const r = await fetch(SITE + f);
    if (!r.ok) throw new Error(String(r.status));
    data[f] = await r.text();
  } catch (e) {
    process.stderr.write(`Tattva MCP: could not read ${f} locally or from ${SITE} (${e.message}). Check your internet connection, or set TATTVA_DATA to a folder holding the four data files.\n`);
    process.exit(1);
  }
}
const VERSION = (() => { for (const p of [join(here, "package.json"), join(here, "..", "package.json")]) { try { return JSON.parse(readFileSync(p, "utf8")).version; } catch {} } return "0.0.0"; })();
// The @tattva/ui the project has installed, read on each call so an install during the session counts.
const installed = () => { try { return JSON.parse(readFileSync(join(process.cwd(), "node_modules", "@tattva", "ui", "package.json"), "utf8")).version; } catch { return null; } };
const ver = (v) => String(v).split(".").map((x) => Number.parseInt(x, 10) || 0).concat([0, 0, 0]).slice(0, 3);
const newer = (a, b) => { const x = ver(a), y = ver(b); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i]; return false; };
/** Said when the part arrived after the installed version, so the import would fail. */
const needs = (c) => { const v = installed(); return v && c.since && newer(c.since, v) ? `${c.name} arrived in @tattva/ui ${c.since}; this project has ${v}. Run \`npm install @tattva/ui@latest\` first, or the import will fail.` : ""; };
// The release notes, for whats_new. Optional: an older site or data folder may not have them yet.
let changelog = null;
const changelogData = async () => {
  if (changelog) return changelog;
  const local = dataDir && join(dataDir, "changelog.json");
  try { changelog = JSON.parse(local && existsSync(local) ? readFileSync(local, "utf8") : await (await fetch(SITE + "changelog.json")).text()); } catch { changelog = null; }
  return changelog;
};
const readJson = (rel) => JSON.parse(data[rel.replace(/^public\//, "")]);
const components = () => readJson("public/components.json").components;

const lev = (a, b) => {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
};
const norm = (s) => String(s).toLowerCase().replace(/[^a-z0-9]/g, "");
const suggest = (q, list) => {
  const n = norm(q);
  const words = String(q).toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2);
  // Close spellings first; then parts whose id shares a word and whose summary mentions another, such as "hotel-card" to result-card.
  const near = list.map((c) => ({ c, s: norm(c.id).includes(n) || n.includes(norm(c.id)) ? 0 : lev(n, norm(c.id)) })).sort((a, b) => a.s - b.s);
  const close = near.filter((x) => x.s <= 2).map((x) => x.c.id);
  const byWords = list.map((c) => { const id = c.id.split("-"), text = `${c.summary} ${c.description ?? ""}`.toLowerCase(); return { id: c.id, s: words.filter((w) => id.includes(w)).length * 2 + words.filter((w) => text.includes(w)).length }; })
    .filter((x) => x.s > 2).sort((a, b) => b.s - a.s).map((x) => x.id);
  return [...new Set([...close, ...byWords, ...near.map((x) => x.c.id)])].slice(0, 4);
};

/** reviewCode, plus one thing only the server knows: parts the installed @tattva/ui does not have yet. */
const review = (src, filename) => {
  const r = reviewCode(src, components(), filename, readJson("public/components.json").exports ?? []);
  // Old names of renamed parts still work, but say what to change them to.
  for (const ren of readJson("public/components.json").renamed ?? []) for (const m of String(src).matchAll(new RegExp(`\\b${ren.from}\\b`, "g"))) r.findings.push({ line: String(src).slice(0, m.index).split("\n").length, rule: "renamed-part", level: "warn", text: ren.from, fix: `${ren.from} was renamed to ${ren.to} in ${ren.since}, the name other design systems use. It still works until ${ren.removeIn}; change it to ${ren.to}.` });
  const byName = new Map(components().map((c) => [c.name, c]));
  for (const m of String(src).matchAll(/import\s*\{([^}]+)\}\s*from\s*["']@tattva\/ui["']/g)) {
    const line = String(src).slice(0, m.index).split("\n").length;
    for (const raw of m[1].split(",")) { const c = byName.get(raw.trim().split(/\s+as\s+/)[0]); const msg = c && needs(c); if (msg) r.findings.push({ line, rule: "needs-upgrade", level: "error", text: c.name, fix: msg }); }
  }
  r.findings.sort((x, y) => x.line - y.line);
  r.counts = { error: r.findings.filter((f) => f.level === "error").length, warn: r.findings.filter((f) => f.level === "warn").length, info: r.findings.filter((f) => f.level === "info").length };
  return r;
};

const fail = (message) => ({ isError: true, content: [{ type: "text", text: message }] });
const ok = (text, structured) => ({ content: [{ type: "text", text }], structuredContent: structured });

const tools = [
  {
    name: "search_components",
    description: "Find Tattva components by what they are for. Searches names, summaries and descriptions. Use this first when you do not know the component id. Returns up to 15 matches with id, name, category, status and a one-line summary. Read-only.",
    inputSchema: { type: "object", properties: {
      query: { type: "string", description: "Words describing what you need, for example \"ask before deleting\" or \"chart\". Leave empty to list everything in a category." },
      category: { type: "string", description: `Optional. One of: ${[...new Set(components().map((c) => c.category).filter(Boolean))].join(", ")}.` },
      status: { type: "string", enum: ["stable", "experimental"], description: "Optional. Experimental parts rest on design reasoning only and may change." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "get_component",
    description: "Get everything needed to use one Tattva component correctly: props with types and defaults, when to use it, what to avoid, accessibility rules, the exact import line, tokens it uses and one example. Call it with an id from search_components. Read-only.",
    inputSchema: { type: "object", properties: {
      id: { type: "string", description: "Component id in kebab-case, for example \"permission-prompt\". The component name (PermissionPrompt) also works." },
      ids: { type: "array", items: { type: "string" }, description: "Several ids at once, instead of id, for example [\"result-card\", \"card-row\"]." },
      brief: { type: "boolean", description: "Only the summary, the import line and the props. Use it when you already know how a part behaves. Default false." },
      all_examples: { type: "boolean", description: "Return every example instead of the first one. Default false." },
    }, required: ["id"], additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "list_patterns",
    description: "List Tattva's patterns: short answers to situations like \"the assistant wants to do something that cannot be undone\". Each has a question, an answer and a page link. Use this to choose an approach before choosing components. Read-only.",
    inputSchema: { type: "object", properties: { query: { type: "string", description: "Optional word filter, for example \"source\" or \"undo\"." } }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "start_project",
    description: "Call this FIRST when a person wants to build something with Tattva, unless a tattva.md brief already exists in their project (then read it instead). Returns a short list of questions to ask the person, each with options and a default. Ask them in plain words, skip any the person has already answered, and accept \"defaults\". Then call plan_build with the answers and the person's idea in their words. Read-only.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "plan_build",
    description: "Turn the person's answers into a build plan: setup steps, the parts to use in build order, patterns to read, warnings, and a project brief to save as tattva.md in their project. Call it after start_project. Missing answers fall back to defaults. Read-only.",
    inputSchema: { type: "object", properties: {
      product: { type: "string", enum: ["chat-assistant", "agent-console", "creative-tool", "generative-ui", "ai-dashboard"], description: "What is being built." },
      idea: { type: "string", description: "The person's idea in their own words, for example \"an assistant that finds hotels\". Used to add parts the product type alone misses, such as result cards." },
      stack: { type: "string", enum: ["new-vite", "new-next", "existing", "no-code"], description: "New or existing project, and framework; no-code for a builder such as Lovable, v0 or Bolt." },
      theme: { type: "string", enum: ["lime", "teal", "indigo", "harbor", "plum", "graphite", "terminal"], description: "Colour theme. Default lime." },
      mode: { type: "string", enum: ["both", "light", "dark"], description: "Light, dark or both. Default both." },
      trust: { type: "array", items: { type: "string", enum: ["sources", "confidence", "approvals", "undo", "memory", "disclosure", "feedback", "errors"] }, description: "Trust behaviours the product needs." },
      plan: { type: "string", enum: ["free", "pro"], description: "Kept for older callers; every part is free, so it changes nothing." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "review_code",
    description: "Check code you wrote against Tattva's rules before you finish: typed hex colours, raw colour functions, Tailwind's default palette, deep imports, clickable divs, icon buttons with no label, images with no alt, lime used as text, removed focus outlines, vague destructive buttons, and parts that do not exist. Pass the file's code. Fix every error and re-run until none are left. Read-only; nothing is written.",
    inputSchema: { type: "object", properties: {
      code: { type: "string", description: "The full source of one file (TSX, JSX, CSS or HTML). Send the whole file, never a shortened copy; or use paths." },
      filename: { type: "string", description: "Optional file name, shown in the result." },
      paths: { type: "array", items: { type: "string" }, description: "Instead of code: file paths in the project, such as [\"src/App.tsx\"]. The server reads them itself, whole. Only files inside the project folder." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "get_themes",
    description: "List Tattva's colour themes (lime, teal, indigo, harbor, plum, graphite, terminal) or get one in full: its AI color in light and dark, paper and ink, the two soft wash colors, how to switch to it, and every token that differs from the default. A theme changes the greys and the AI color only; amber and the status colors never change. Read-only.",
    inputSchema: { type: "object", properties: { id: { type: "string", description: "Optional theme id, for example \"indigo\". Omit to list all themes." } }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "get_tokens",
    description: "Get Tattva design tokens (colors, timing, sizes, shadows) with what each is for. Use token names in CSS as var(--name) or as Tailwind classes. Never type a hex value in generated code. Read-only.",
    inputSchema: { type: "object", properties: {
      group: { type: "string", description: "Optional group: surfaces, lines, text, actions, attention, status, direction, reserved, code, charts, size, motion, shadow. Omit to list the group names with counts." },
      mode: { type: "string", enum: ["light", "dark"], description: "Light or dark values. Default light." },
      theme: { type: "string", description: "Optional colour theme id (see get_themes), for example \"indigo\". Returns that theme's colors. Default lime." },
      query: { type: "string", description: "Optional: find tokens by what they are for, across all groups, for example \"card background\" or \"text on lime\"." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  },
  {
    name: "whats_new",
    description: "What changed in Tattva since a version: the parts added and updated in each release, in plain words. Use it before upgrading a project, or to learn what a newer @tattva/ui adds. Read-only.",
    inputSchema: { type: "object", properties: {
      since: { type: "string", description: "The version to start after, for example \"0.27.1\". Default: the version installed in this project, or the last three releases." },
    }, additionalProperties: false },
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true },
  },
];

const handlers = {
  search_components({ query = "", category, status } = {}) {
    const all = components();
    const cats = [...new Set(all.map((c) => c.category).filter(Boolean))];
    if (category && !cats.includes(category)) return fail(`Unknown category "${category}". Use one of: ${cats.join(", ")}.`);
    // Plain-language search: drop filler words, match word stems, and let rare words count for more than common ones.
    const STOP = new Set("a an the and or of to for in on at by with from into is are be it its this that these those i we you your my our me us user users person people need needs want wants let lets make makes show shows showing display displays place way something thing things when while before after so can should would could will do does how what which where who ai".split(" "));
    const stem = (w) => w.replace(/(ing|ed|es|s|ly)$/, (m, x, i) => (i > 3 ? "" : m));
    const tok = (t) => String(t).toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/[\s-]+/).filter(Boolean);
    const SAME = { got: "came", get: "come", gets: "comes", citation: "source", citations: "sources", cite: "source", reference: "source", references: "sources" };
    const raw = tok(query).filter((w) => !STOP.has(w));
    // Two words written apart can be one name: "heat map" finds heatmap, "check list" finds checklist.
    const joined = raw.slice(1).map((w, i) => raw[i] + w);
    const words = [...new Set([...raw, ...joined].map((w) => stem(SAME[w] ?? w)))].filter((w) => w.length > 1);
    const field = (c) => ({
      name: tok(`${c.id} ${c.name}`).map(stem),
      aka: tok((c.aka ?? []).join(" ")).map(stem),
      head: tok(`${c.summary} ${c.purpose ?? ""} ${(c.useFor ?? []).join(" ")}`).map(stem),
      body: tok(`${c.description} ${c.whenToUse.join(" ")}`).map(stem),
    });
    const pool = all.filter((c) => (!category || c.category === category) && (!status || c.status === status));
    const fields = new Map(pool.map((c) => [c, field(c)]));
    const df = (w) => pool.filter((c) => { const f = fields.get(c); return f.name.includes(w) || f.aka.includes(w) || f.head.includes(w) || f.body.includes(w); }).length;
    const idf = new Map(words.map((w) => [w, Math.log(1 + pool.length / (1 + df(w)))]));
    const scored = pool.map((c) => {
      const f = fields.get(c);
      let s = 0;
      for (const w of words) s += idf.get(w) * ((f.name.includes(w) ? 5 : 0) + (f.aka.includes(w) ? 4 : 0) + (f.head.includes(w) ? 3 : 0) + (f.body.includes(w) ? 1 : 0));
      // The whole query is one of the part's other names ("accordion", "kpi", "chat input"): rank it with the name.
      const phrase = String(query).toLowerCase().trim();
      if (phrase && (c.aka ?? []).includes(phrase)) s += 50;
      return { c, s };
    }).filter((x) => !words.length || x.s > 0).sort((a, b) => b.s - a.s);
    // Keep the matches that are close to the best one (and never fewer than five); a single shared common word is not a
    // match worth reading.
    const top = scored[0]?.s ?? 0;
    const strong = words.length ? scored.filter((x, i) => i < 5 || x.s >= top * 0.35) : scored;
    const matched = (c) => { const f = fields.get(c); return words.filter((w) => f.name.includes(w) || f.aka.includes(w) || f.head.includes(w) || f.body.includes(w)); };
    const results = strong.slice(0, 15).map(({ c }) => ({ id: c.id, name: c.name, category: c.category, status: c.status, summary: c.summary, since: c.since ?? null, matched: matched(c), needsUpgrade: needs(c) || null }));
    if (!results.length) return ok(`No components match "${query}". Try fewer or simpler words, or filter by category: ${cats.join(", ")}.`, { results: [], total: 0 });
    const text = `${strong.length} match${strong.length === 1 ? "" : "es"}${strong.length > 15 ? " (showing the best 15)" : ""}:\n` + results.map((r) => `- ${r.id} (${r.name}, ${r.category}): ${r.summary}${words.length ? ` [matched: ${r.matched.join(", ")}]` : ""}${r.needsUpgrade ? ` [needs @tattva/ui ${r.since}]` : ""}`).join("\n") + "\nNext: call get_component with an id, or with ids for several.";
    return ok(text, { results, total: strong.length });
  },
  get_component({ id, ids, brief = false, all_examples = false } = {}) {
    if (Array.isArray(ids) && ids.length) {
      const list = ids.slice(0, 12).map((x) => handlers.get_component({ id: x, brief, all_examples }));
      if (list.every((r) => r.isError)) return fail(list.map((r) => r.content[0].text).join("\n"));
      return ok(list.map((r) => r.content[0].text).join("\n\n---\n\n") + (ids.length > 12 ? `\n\nOnly the first 12 of ${ids.length} ids were read. Ask again for the rest.` : ""), { components: list.map((r) => r.structuredContent ?? { error: r.content[0].text }) });
    }
    if (!id) return fail("Missing `id`. Call search_components first to find one, for example id: \"button\". For several parts at once, pass ids.");
    const all = components();
    // An old name or id of a renamed part opens the part under its new name, with a note.
    const ren = (readJson("public/components.json").renamed ?? []).find((r) => norm(r.from) === norm(id) || r.fromId === id);
    if (ren) id = ren.toId;
    const n = norm(id);
    let c = all.find((x) => x.id === id) ?? all.find((x) => norm(x.id) === n || norm(x.name) === n);
    if (!c) return fail(`No component called "${id}". Did you mean: ${suggest(id, all).join(", ")}? Call search_components to browse.`);
    // The docs are written for the Tattva repo (./index). In a person's project free parts come from the npm package
    // and Pro parts from the tattva folder of the Pro download.
    const toKit = (x) => String(x).replace(/from "\.\/index"/g, c.plan === "pro" ? 'from "./tattva"' : 'from "@tattva/ui"');
    c = { ...c, importPath: toKit(c.importPath) };
    const examples = (all_examples ? c.examples : c.examples.slice(0, 1)).map((e) => ({ ...e, code: toKit(e.code) }));
    // A Pro part without an unlocked licence has no code. Say so, so the assistant never writes its own version.
    const locked = c.plan === "pro" && examples.every((e) => !e.code.trim());
    const data = {
      id: c.id, name: c.name, level: c.level, category: c.category, status: c.status, lifecycle: c.lifecycle ?? null, states: c.states ?? [], summary: c.summary, description: c.description,
      importPath: c.importPath, sourcePath: c.sourcePath,
      props: c.props, variantsHint: c.variantsHint,
      purpose: c.purpose ?? null, useFor: c.useFor ?? [], notFor: c.notFor ?? [],
      whenToUse: c.whenToUse, avoid: c.avoid, accessibility: c.accessibility, accessibilityYouDo: c.accessibilityYouDo ?? [],
      tokens: c.tokens, related: c.related, composedOf: c.composedOf, codeAvailable: !locked, examples, pageUrl: c.pageUrl, markdownUrl: c.markdownUrl,
    };
    const list = (a) => a.map((x) => `- ${x}`).join("\n");
    const upgrade = needs(c);
    const renameNote = ren ? `${ren.from} was renamed to ${ren.to} in ${ren.since}. The old name still works until ${ren.removeIn}; use ${ren.to} in new code.` : "";
    data.since = c.since ?? null; data.needsUpgrade = upgrade || null;
    if (brief) return ok([`${c.name} (${c.id}): ${c.summary}`, upgrade ? `WARNING: ${upgrade}` : "", c.importPath, "Props:", ...c.props.map((p) => `- ${p.name}${p.required ? " (required)" : ""}: ${p.type}${p.default ? ` = ${p.default}` : ""}. ${p.description}`)].filter(Boolean).join("\n"), data);
    const text = [
      `${c.name} (${c.id}, ${c.level}, ${c.status})`, c.summary, c.aka?.length ? `Also known as: ${c.aka.join(", ")}.` : "",
      c.lifecycle && (c.lifecycle.stage === "deprecated" || c.lifecycle.stage === "retired") ? `WARNING: ${c.name} is ${c.lifecycle.stage}. ${c.lifecycle.note ?? ""} Use ${c.lifecycle.replacedBy} instead.` : "",
      upgrade ? `WARNING: ${upgrade}` : "", renameNote,
      "", c.importPath, "",
      "Props:", ...c.props.map((p) => `- ${p.name}${p.required ? " (required)" : ""}: ${p.type}${p.default ? ` = ${p.default}` : ""}. ${p.description}`), "",
      c.purpose ? `When to use it: ${c.purpose}` : "", c.notFor?.length ? `Not for:\n${list(c.notFor.map((n) => n.use ? `${n.text}: use ${n.use}` : n.text))}` : "",
      "Do:", list(c.whenToUse), "Avoid:", list(c.avoid), "Accessibility (built in):", list(c.accessibility),
      c.accessibilityYouDo?.length ? `Accessibility (you must):\n${list(c.accessibilityYouDo)}` : "",
      c.states?.length ? `States:\n${list(c.states.map((x) => `${x.name}: ${x.note}`))}` : "",
      c.related.length ? `Related: ${c.related.join(", ")}` : "",
      "", ...(locked
        ? [`Code: locked. ${c.name} is a Pro part, so this server has no code for it. Do not write your own version. Tell the person in plain words that this part is part of Tattva Pro, the paid plan (https://lkb00.github.io/tattva/#pricing), and use a simple stand-in marked with a comment naming the part, so they can swap it in later. If they already have Pro, they can add their key to unlock it (TATTVA_LICENSE_KEY).`, ...examples.map((e) => `Example (no code): ${e.title}`)]
        : examples.flatMap((e) => [`Example: ${e.title}`, "```tsx", e.code, "```"])),
    ].filter((x) => x !== "").join("\n");
    return ok(text, data);
  },
  list_patterns({ query = "" } = {}) {
    const txt = data["llms.txt"];
    const sec = txt.split(/^## /m).find((s) => s.startsWith("Patterns")) ?? "";
    let patterns = sec.split("\n").filter((l) => l.startsWith("- ")).map((l) => {
      const m = l.match(/^- ([^:]+): (.*) \((https?:\/\/[^)]+)\)$/);
      if (!m) return null;
      const url = m[3]; const q = m[2].match(/^(.*?\?)\s*(.*)$/);
      return { id: url.split("#pattern-")[1] ?? "", title: m[1], question: q ? q[1] : "", answer: q ? q[2] : m[2], url };
    }).filter(Boolean);
    const words = String(query).toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length) patterns = patterns.filter((p) => words.some((w) => `${p.title} ${p.question} ${p.answer}`.toLowerCase().includes(w)));
    if (!patterns.length) return ok(`No patterns match "${query}". Call list_patterns with no query to see all of them.`, { patterns: [] });
    return ok(patterns.map((p) => `- ${p.title}: ${p.question} ${p.answer}\n  ${p.url}`).join("\n"), { patterns });
  },
  start_project() {
    const isDefault = (q, o) => (Array.isArray(q.default) ? q.default.includes(o.value) : q.default === o.value);
    const lines = QUESTIONS.map((q, i) => `Question ${i + 1} of ${QUESTIONS.length}${q.multiple ? " (pick any)" : ""}: ${q.question}\n${q.options.map((o) => `   - ${o.value}: ${o.label}${isDefault(q, o) ? "  [default]" : ""}`).join("\n")}`);
    // One question at a time reads as a conversation, not a form. Questions the request already answers are skipped.
    return ok([
      "Ask the person these questions ONE AT A TIME, in plain words, and wait for each answer before the next.",
      "- First say, in one short line, that a few quick questions will shape the build and that they can say \"defaults\" at any point to skip the rest.",
      "- Skip any question their request already answers (\"a dark app that finds hotels\" answers what it is and light or dark). Do not ask it again.",
      "- If your tool can show clickable choices (for example AskUserQuestion in Claude Code), use them for each question: the options below in plain words, the default first and marked as recommended, several allowed where it says pick any. Otherwise write the question with its options as a short numbered list.",
      "- If they say \"defaults\", \"you choose\" or similar, stop asking and use the defaults for every question left.",
      "- Ask only these questions. Do not add your own.",
      "", ...lines, "",
      "Then call plan_build with the answers and the person's idea in their words. If the project already has a tattva.md brief, read it and only ask what is missing.",
    ].join("\n"), { questions: QUESTIONS, ask: "one-at-a-time" });
  },
  plan_build(args = {}) {
    const r = planBuild(args, components());
    if (r.error) return fail(r.error);
    for (const p of r.parts) { const c = components().find((x) => x.id === p.id); const msg = c && needs(c); if (msg) r.warnings.push(msg); }
    // A no-code builder has no terminal and no files to write: the person pastes one prompt into it instead.
    if (r.answers.stack === "no-code") {
      const prompt = buildPrompt(r);
      return ok([`Plan: ${r.recipe.title} in a no-code AI builder. Theme ${r.answers.theme}, ${r.answers.mode} mode.`, "",
        "Give the person this prompt to paste into their builder (Lovable, v0, Bolt or similar), in one message, as it is. Nothing needs installing on their computer.", "",
        "```text", prompt, "```", "",
        ...(r.warnings.length ? ["Heads up:", ...r.warnings.map((w) => `- ${w}`), ""] : []),
        "Then: when the builder shows its result, ask the person to paste the main file back here and call review_code on it.", "", PLAIN_WORDS].join("\n"), { ...r, prompt });
    }
    const groups = [...new Set(r.parts.map((p) => p.group))];
    const text = [
      `Plan: ${r.recipe.title}. Theme ${r.answers.theme}, ${r.answers.mode} mode.`, "",
      "Setup:", ...r.setup.map((x, i) => `${i + 1}. ${x}`), "",
      "Run these commands, in order:", ...r.commands.map((c) => `  ${c}`), "",
      "Write these files exactly as given (overwrite the ones the template created):", ...r.files.flatMap((f) => ["", `--- ${f.path} (${f.why}) ---`, f.content.trimEnd()]), "",
      "Setup is not finished until the commands have run and every file above is written. Then you write src/App.tsx, importing parts from \"@tattva/ui\".", "",
      "Parts, in build order:", ...groups.flatMap((g) => [`${g}:`, ...r.parts.filter((p) => p.group === g).map((p) => `- ${p.name} (${p.id})${p.plan === "pro" ? " [Pro]" : ""}: ${p.why}`)]), "",
      `Patterns to read first: call list_patterns with the words ${r.patterns.map((x) => `"${x}"`).join(", ")}.`,
      ...(r.warnings.length ? ["", "Heads up:", ...r.warnings.map((w) => `- ${w}`)] : []),
      "", "Next: call get_component with ids (several at once) for the parts' props and examples, then build. When a file is done, call review_code with paths so it reads the whole file, and fix every error.", "",
      "Make it answer for real (after the screen works): Tattva is the interface only, so the replies start as sample data. Explain this to the person in plain words, then:",
      "1. Ask which AI provider they want to use. Do not choose one or create an account for them.",
      "2. They create an API key on the provider's site. The key goes on a server, never in the browser code or in a file the app ships: add a small server route (for example /api/chat) that holds the key and calls the model.",
      "3. The app sends the person's message to that route and shows the reply as it streams in, in Message with streaming on. Keep the sources and feedback parts working with the real replies.",
      "4. Never ask the person to paste the key into the chat.", "",
      "(The brief is written to tattva.md above.)", "", PLAIN_WORDS,
    ].join("\n");
    return ok(text, r);
  },
  review_code({ code, filename = "", paths } = {}) {
    if (Array.isArray(paths) && paths.length) {
      // Read the files whole, so nothing is skipped. Only files inside the folder the server was started in.
      const root = process.cwd();
      const parts = [], all = [];
      for (const rel of paths.slice(0, 30)) {
        const abs = resolve(root, String(rel));
        if (abs !== root && !abs.startsWith(root + sep)) { parts.push(`${rel}: skipped, it is outside the project folder.`); continue; }
        let src;
        // A link inside the project can point outside it; follow it and check again.
        try { const real = realpathSync(abs), realRoot = realpathSync(root); if (real !== realRoot && !real.startsWith(realRoot + sep)) { parts.push(`${rel}: skipped, it points outside the project folder.`); continue; } } catch {}
        try { src = readFileSync(abs, "utf8"); } catch { parts.push(`${rel}: could not read it. Check the path, relative to ${root}.`); continue; }
        if (src.length > 400_000) { parts.push(`${rel}: skipped, it is too large to be a source file.`); continue; }
        const r = review(src, String(rel));
        all.push(r);
        parts.push(r.findings.length ? [`${rel}: ${r.counts.error} error(s), ${r.counts.warn} warning(s), ${r.counts.info} note(s)`, ...r.findings.map((f) => `  line ${f.line} [${f.level}] ${f.rule}: ${f.text}\n     Fix: ${f.fix}`)].join("\n") : `${rel}: no problems found.`);
      }
      const errors = all.reduce((n, r) => n + r.counts.error, 0);
      const head = errors ? `${errors} error(s) in ${all.filter((r) => r.counts.error).length} of ${all.length} file(s). Fix the errors and run review_code again.` : `No errors in ${all.length} file(s).`;
      return ok([head, "", ...parts, "", "This checker cannot judge layout or wording, so still look at the result on screen."].join("\n"), { files: all });
    }
    if (typeof code !== "string" || !code.trim()) return fail("Pass the file's source as `code`, or file paths as `paths`.");
    const r = review(code, filename);
    const label = filename ? ` in ${filename}` : "";
    if (!r.findings.length) return ok(`No problems found${label}. The code follows the Tattva rules this checker can see. It cannot judge layout or wording, so still check the result on screen.`, r);
    const text = [`${r.counts.error} error${r.counts.error === 1 ? "" : "s"}, ${r.counts.warn} warning${r.counts.warn === 1 ? "" : "s"}, ${r.counts.info} note${r.counts.info === 1 ? "" : "s"}${label}. Fix the errors and run review_code again.`, "", ...r.findings.map((f) => `line ${f.line} [${f.level}] ${f.rule}: ${f.text}\n   Fix: ${f.fix}`)].join("\n");
    return ok(text, r);
  },
  get_themes({ id } = {}) {
    const all = readJson("public/themes.json").themes;
    if (!id) {
      const lines = all.map((t) => `- ${t.id}${t.default ? " (default)" : ""}: ${t.name}, ${t.note}. AI color ${t.ai.light} (light) / ${t.ai.dark} (dark). Use: ${t.use}`);
      return ok(`Tattva colour themes. A theme changes the greys and the AI color (--lime) in light and dark. Amber and the status colors never change. Switch with data-palette on the html element.\n${lines.join("\n")}\nCall get_themes with an id for the full set of values.`, { themes: all.map(({ colors, ...t }) => t) });
    }
    const t = all.find((x) => x.id === String(id).toLowerCase());
    if (!t) return fail(`No theme called "${id}". Use one of: ${all.map((x) => x.id).join(", ")}.`);
    const n = (o) => Object.keys(o).length;
    const lines = [`${t.name}${t.default ? " (default)" : ""}: ${t.note}`, `Use: ${t.use}`, `AI color (--lime): ${t.ai.light} light, ${t.ai.dark} dark`, `Paper (--bg): ${t.paper.light} light, ${t.paper.dark} dark`, `Ink (--fg): ${t.ink.light} light, ${t.ink.dark} dark`, `Soft wash (--ai-wash-1, --ai-wash-2): ${t.wash.light?.join(", ")} light${t.wash.dark ? `; ${t.wash.dark.join(", ")} dark` : ""}`, `Tokens that differ from the default: ${n(t.colors.light)} light, ${n(t.colors.dark)} dark. Call get_tokens with theme "${t.id}" to read them. In code, keep using var(--name); never type these hex values.`];
    return ok(lines.join("\n"), t);
  },
  get_tokens({ group, mode = "light", theme, query } = {}) {
    if (!["light", "dark"].includes(mode)) return fail(`Unknown mode "${mode}". Use "light" or "dark".`);
    const t = readJson("public/tokens.dtcg.json");
    let themeColors = null;
    if (theme) {
      const th = readJson("public/themes.json").themes.find((x) => x.id === String(theme).toLowerCase());
      if (!th) return fail(`No theme called "${theme}". Call get_themes to see the ids.`);
      themeColors = th.colors[mode];
    }
    const cols = t.color[mode];
    const names = { surfaces: "color", lines: "color", text: "color", actions: "color", attention: "color", status: "color", code: "color", charts: "color", other: "color", size: "size", fontSize: "fontSize", motion: "duration", shadow: "shadow" };
    const flat = (g, kind, o) => Object.entries(o).filter(([k]) => !k.startsWith("$")).map(([k, v]) => {
      const val = v.$type === "color" ? v.$value.hex : v.$type === "duration" || v.$type === "dimension" ? `${v.$value.value}${v.$value.unit}` : v.$type === "cubicBezier" ? `cubic-bezier(${v.$value.join(", ")})` : v.$type === "shadow" ? (v.$extensions?.css ?? JSON.stringify(v.$value)) : JSON.stringify(v.$value);
      return { name: `--${k}`, type: v.$type, value: val, description: v.$description ?? "", group: g };
    });
    const groups = {};
    for (const [g, o] of Object.entries(cols)) groups[g] = flat(g, "color", o).map((x) => (themeColors?.[x.name] ? { ...x, value: themeColors[x.name] } : x));
    groups.size = [...flat("size", "dimension", t.size ?? {}), ...flat("size", "dimension", t.fontSize ?? {})];
    groups.motion = [...flat("motion", "duration", t.duration ?? {}), ...flat("motion", "cubicBezier", t.easing ?? {})];
    groups.shadow = flat("shadow", "shadow", t.shadow?.[mode] ?? {});
    if (query) {
      const words = String(query).toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 1);
      let hits = Object.values(groups).flat().map((x) => { const hay = `${x.name} ${x.description} ${x.group}`.toLowerCase(); return { x, s: words.filter((w) => hay.includes(w)).length + words.filter((w) => x.name.includes(w)).length }; })
        .filter((h) => h.s > 0).sort((a, b) => b.s - a.s);
      const best = hits[0]?.s ?? 0;
      hits = hits.filter((h) => h.s >= Math.max(1, best - 1)).slice(0, 10).map((h) => h.x);
      if (!hits.length) return ok(`No tokens match "${query}". Call get_tokens with no group to see the groups.`, { mode, tokens: [] });
      return ok(hits.map((x) => `${x.name} = ${x.value}  (${x.group}${x.description ? `: ${x.description}` : ""})`).join("\n") + "\nUse the name as var(--name), never the value.", { mode, tokens: hits });
    }
    if (!group) {
      const summary = Object.entries(groups).map(([g, a]) => ({ group: g, count: a.length }));
      return ok(`Token groups (${mode}): ${summary.map((s) => `${s.group} (${s.count})`).join(", ")}.\nCall get_tokens with a group to see names and values. Use names as var(--name). Never write hex values in components.`, { mode, groups: summary });
    }
    if (!groups[group]) return fail(`No token group called "${group}". Use one of: ${Object.keys(groups).join(", ")}.`);
    return ok(groups[group].map((x) => `${x.name} = ${x.value}${x.description ? `  (${x.description})` : ""}`).join("\n"), { mode, group, tokens: groups[group] });
  },
};

handlers.whats_new = async ({ since } = {}) => {
  const log = await changelogData();
  if (!log?.releases?.length) return fail("The release notes could not be read. See https://lkb00.github.io/tattva/changelog/ instead.");
  const from = since ?? installed();
  const list = from ? log.releases.filter((r) => newer(r.version, from)) : log.releases.slice(0, 3);
  if (!list.length) return ok(`Nothing newer than ${from}. The latest release is ${log.releases[0].version}.`, { releases: [] });
  const name = (id) => components().find((c) => c.id === id)?.name ?? id;
  const text = [from ? `Changes after ${from}${since ? "" : " (the version this project has)"}:` : "The last three releases:", "",
    ...list.flatMap((r) => [`${r.version}: ${r.title}`, ...(r.added?.length ? [`  New parts: ${r.added.map(name).join(", ")}`] : []), ...(r.updated?.length && r.updated.length <= 20 ? [`  Updated: ${r.updated.map(name).join(", ")}`] : r.updated?.length ? [`  Updated: ${r.updated.length} parts`] : []), ...r.items.map((i) => `  - ${i.text}`), ""]),
    from && newer(log.releases[0].version, from) ? `To upgrade: npm install @tattva/ui@${log.releases[0].version}` : ""].join("\n").trim();
  return ok(text, { releases: list });
};

const send = (m) => process.stdout.write(JSON.stringify(m) + "\n");
const reply = (id, result) => send({ jsonrpc: "2.0", id, result });
const error = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });

function handle(msg) {
  const { id, method, params } = msg;
  const isNote = id === undefined || id === null;
  if (method === "initialize") {
    return reply(id, { protocolVersion: params?.protocolVersion ?? PROTOCOL, capabilities: { tools: { listChanged: false }, prompts: { listChanged: false } }, serverInfo: { name: "tattva", version: VERSION },
      instructions: "Tattva is a design system for AI products. To build something: (1) if the project has a tattva.md brief, read it; otherwise call start_project and ask the person its questions one at a time (with clickable choices where your tool has them), then call plan_build with the answers and the idea in their words, then run its commands and write its files exactly as given before anything else. (2) Call get_component for the parts (ids reads several at once), then import from the package index. If it warns that the installed @tattva/ui is too old, upgrade it first. (3) Use tokens, never hex values. The AI colour (--lime) is a fill, never text; amber means a person has to act. (4) If nothing fits what the person asked for, say so and ask; never invent a part, a prop or a colour. (5) Before finishing, call review_code with paths for every file you wrote, so each is read whole, and fix all errors. (6) The person may not be a developer. When something is blocked or missing, tell them in plain words what you could not do, what it means for them and the one thing to do next; never show error codes or words like proxy, registry, policy or token. " + PLAIN_WORDS });
  }
  if (method === "notifications/initialized" || method?.startsWith("notifications/")) return;
  if (method === "ping") return reply(id, {});
  if (method === "tools/list") return reply(id, { tools });
  if (method === "prompts/list") return reply(id, { prompts: [{ name: "build", title: "Build with Tattva", description: "Start a guided build: a few questions, then a plan, then a check of the code.", arguments: [{ name: "idea", description: "Optional: what you want to build, in a sentence.", required: false }] }] });
  if (method === "prompts/get") {
    if (params?.name !== "build") return error(id, -32602, `Unknown prompt "${params?.name}". Available: build.`);
    const idea = params?.arguments?.idea ? ` The person wants to build: ${params.arguments.idea}.` : "";
    return reply(id, { description: "Build with Tattva", messages: [{ role: "user", content: { type: "text", text: `Help me build a product with the Tattva design system.${idea} Start by calling the start_project tool and ask me its questions, then call plan_build, then build it part by part, and run review_code on every file before you finish.` } }] });
  }
  if (method === "tools/call") {
    const h = handlers[params?.name];
    if (!h) return reply(id, fail(`Unknown tool "${params?.name}". Available tools: ${tools.map((t) => t.name).join(", ")}.`));
    // Handlers may be async (whats_new reads the release notes); answer when each settles.
    return Promise.resolve().then(() => h(params.arguments ?? {})).then((r) => reply(id, r), (e) => reply(id, fail(String(e.message ?? e))));
  }
  if (!isNote) error(id, -32601, `Method not found: ${method}`);
}

// Started by hand in a terminal, the server would wait in silence and look stuck. Say what it is and what to do.
// Stderr only: an AI tool reads stdout, so this never reaches it.
if (process.stdin.isTTY) process.stderr.write(`\nTattva MCP server ${VERSION} is working.\n\nIt talks to your AI tool, not to you, so nothing more will happen here. Press Ctrl+C to stop it.\n\nNext: add it to your AI tool instead.\n  Claude Code:  claude mcp add tattva -- npx -y @tattva/mcp\n  Cursor, Claude Desktop and others: https://lkb00.github.io/tattva/connect-ai/\nThen ask your AI tool: "Use Tattva to help me build ..."\n\n`);
createInterface({ input: process.stdin }).on("line", (line) => {
  if (!line.trim()) return;
  let msg;
  try { msg = JSON.parse(line); } catch { return error(null, -32700, "Parse error: send one JSON-RPC message per line."); }
  try { handle(msg); } catch (e) { if (msg.id !== undefined) error(msg.id, -32603, String(e.message ?? e)); }
});
