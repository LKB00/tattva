// check_screen for the Tattva MCP server: opens the person's running app at phone and desktop sizes, saves
// screenshots the assistant can look at, and reports what a code review cannot see: text that spills out of its box,
// sideways scrolling, controls on top of each other, tap targets too small for a finger, buttons with no name, images
// with no description, errors in the browser, requests that failed, and content that jumps after it loads.
// It only opens addresses on this computer and never changes the app. It needs Playwright with Chromium in the
// project (npm install -D playwright && npx playwright install chromium), or CHROMIUM_PATH and playwright-core.
import { createRequire } from "node:module";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const LOCAL = /^(localhost|127\.0\.0\.1|\[::1\]|0\.0\.0\.0|[a-z0-9-]+\.local|[a-z0-9-]+\.localhost)$/i;

/** Playwright's chromium from the person's project first, then from beside this file (inside the Tattva repo). */
async function loadChromium() {
  for (const base of [join(process.cwd(), "package.json"), join(here, "..", "package.json"), join(here, "package.json")]) {
    const req = createRequire(base);
    for (const name of ["playwright", "playwright-core", "@playwright/test"]) {
      try { const mod = await import(pathToFileURL(req.resolve(name)).href); const c = mod.chromium ?? mod.default?.chromium; if (c) return c; } catch { /* not here */ }
    }
  }
  return null;
}

export const SIZES = { phone: { width: 390, height: 844, mobile: true }, desktop: { width: 1280, height: 800, mobile: false } };

/** What runs inside the page: every check reads the page as drawn, nothing is changed. */
function inspect() {
  const out = { sideways: false, spills: [], overlaps: [], small: [], unnamed: [], noAlt: [], hiddenFocusable: [] };
  const vw = document.documentElement.clientWidth;
  out.sideways = document.documentElement.scrollWidth > vw + 1;
  // Seen by a person: has a size, and neither it nor a parent is invisible, inert or hidden from assistive tech.
  const shown = (el) => { for (let p = el; p && p !== document.documentElement; p = p.parentElement) { const cs = getComputedStyle(p); if (Number(cs.opacity) === 0 || cs.visibility === "hidden" || cs.display === "none") return false; } return true; };
  const switchedOff = (el) => !!el.closest("[inert], [aria-hidden='true']");
  const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && shown(el) && !switchedOff(el); };
  const label = (el) => (el.getAttribute("aria-label") || el.getAttribute("title") || el.textContent || el.getAttribute("alt") || el.getAttribute("placeholder") || "").trim().replace(/\s+/g, " ").slice(0, 60);
  const where = (el) => { let s = el.tagName.toLowerCase(); if (el.id) s += `#${el.id}`; const cls = (el.getAttribute("class") || "").trim().split(/\s+/).filter(Boolean).slice(0, 2); if (cls.length) s += "." + cls.join("."); return s; };
  // Inside something that scrolls or clips on purpose: content past its edge is meant to be there.
  const scrolls = (el) => { for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) { const cs = getComputedStyle(p); if (/(auto|scroll|hidden|clip)/.test(cs.overflowX) || /(auto|scroll|hidden|clip)/.test(cs.overflow)) return true; } return false; };
  // Pinned bars (fixed or sticky) sit over the page by design; overlap with them is not a fault.
  const pinned = (el) => { for (let p = el; p && p !== document.body; p = p.parentElement) if (/fixed|sticky/.test(getComputedStyle(p).position)) return true; return false; };
  // Hidden on purpose until it is needed, such as a "Skip to content" link (1px until focused).
  const srOnly = (el) => { const r = el.getBoundingClientRect(); return r.width <= 2 || r.height <= 2; };
  // Text that runs past its box (and is not inside something meant to scroll or to cut text off).
  for (const el of document.querySelectorAll("body *")) {
    if (out.spills.length >= 12) break;
    if (!visible(el) || !el.childNodes.length || ![...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())) continue;
    const cs = getComputedStyle(el);
    if (cs.textOverflow === "ellipsis" || /hidden|clip/.test(cs.overflowX) || scrolls(el)) continue;
    if (el.scrollWidth > el.clientWidth + 2 && cs.whiteSpace !== "normal" || el.getBoundingClientRect().right > vw + 1) out.spills.push({ where: where(el), text: label(el) });
  }
  const controls = [...document.querySelectorAll('a[href], button, input, select, textarea, [role="button"], [role="link"], [role="checkbox"], [role="tab"], [tabindex]:not([tabindex="-1"])')].filter((el) => visible(el) && !srOnly(el));
  // WCAG 2.2 target size: under 24px is still fine when no other control is within the 24px circle around it.
  const crowded = (el, r) => { const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    return controls.some((o) => { if (o === el || o.contains(el) || el.contains(o)) return false; const q = o.getBoundingClientRect(); const dx = Math.max(q.left - cx, 0, cx - q.right), dy = Math.max(q.top - cy, 0, cy - q.bottom); return Math.hypot(dx, dy) < 12; }); };
  for (const el of controls) {
    const r = el.getBoundingClientRect();
    if (out.small.length < 12 && (r.width < 24 || r.height < 24) && !(el.tagName === "A" && getComputedStyle(el).display === "inline") && crowded(el, r)) out.small.push({ where: where(el), text: label(el), size: `${Math.round(r.width)}x${Math.round(r.height)}` });
    if (out.unnamed.length < 12 && !label(el) && !el.getAttribute("aria-labelledby") && !(el.labels && el.labels.length)) out.unnamed.push({ where: where(el) });
  }
  // Two controls drawn on top of each other: more than a third of the smaller one covered.
  for (let i = 0; i < controls.length && out.overlaps.length < 8; i++) for (let j = i + 1; j < controls.length; j++) {
    const a = controls[i], b = controls[j]; if (a.contains(b) || b.contains(a) || pinned(a) || pinned(b)) continue;
    const r = a.getBoundingClientRect(), s = b.getBoundingClientRect();
    const w = Math.min(r.right, s.right) - Math.max(r.left, s.left), h = Math.min(r.bottom, s.bottom) - Math.max(r.top, s.top);
    if (w > 0 && h > 0 && w * h > 0.33 * Math.min(r.width * r.height, s.width * s.height)) { out.overlaps.push({ a: `${where(a)} "${label(a)}"`, b: `${where(b)} "${label(b)}"` }); break; }
  }
  // Invisible to the eye but still reachable with Tab: a keyboard user lands on something they cannot see.
  for (const el of document.querySelectorAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])')) {
    if (out.hiddenFocusable.length >= 8) break;
    const r = el.getBoundingClientRect();
    if (r.width > 2 && r.height > 2 && !shown(el) && !switchedOff(el) && !el.disabled && getComputedStyle(el).display !== "none") out.hiddenFocusable.push({ where: where(el), text: label(el) });
  }
  for (const img of document.querySelectorAll("img")) if (out.noAlt.length < 12 && visible(img) && !img.hasAttribute("alt")) out.noAlt.push({ where: where(img), src: (img.getAttribute("src") || "").slice(0, 80) });
  return out;
}

/** Opens the page at each size and gathers what is wrong. Returns findings and screenshot paths. */
export async function checkScreen({ url, sizes = ["phone", "desktop"], dark = false, wait = 800, outDir } = {}) {
  let u;
  try { u = new URL(String(url)); } catch { return { error: `"${url}" is not an address. Start the app (for example npm run dev) and pass the address it prints, such as http://localhost:5173.` }; }
  if (!/^https?:$/.test(u.protocol) || !LOCAL.test(u.hostname)) return { error: `check_screen only opens the app running on this computer (localhost). "${u.host}" is not local.` };
  const chromium = await loadChromium();
  if (!chromium) return { error: "No browser for checks in this project. Install one once with: npm install -D playwright && npx playwright install chromium. Then call check_screen again." };
  let browser;
  try { browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined }); }
  catch (e) { return { error: `The browser would not start (${String(e.message).split("\n")[0]}). Run: npx playwright install chromium` }; }
  const dir = outDir ?? join(process.cwd(), ".tattva", "screens");
  mkdirSync(dir, { recursive: true });
  // Screenshots are working files: keep them out of the person's git history.
  const ignore = join(dir, "..", ".gitignore");
  if (!outDir && !existsSync(ignore)) writeFileSync(ignore, "# Screenshots from Tattva's check_screen\n*\n");
  const results = [];
  try {
    for (const name of sizes) {
      const vp = SIZES[name]; if (!vp) continue;
      const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, isMobile: vp.mobile, hasTouch: vp.mobile, deviceScaleFactor: 1, colorScheme: dark ? "dark" : "light" });
      const page = await ctx.newPage();
      const errors = [], failed = [];
      page.on("pageerror", (e) => errors.push(String(e.message).split("\n")[0]));
      // "Failed to load resource" repeats a failed request, which is listed with its address below instead.
      page.on("console", (m) => { if (m.type() === "error" && !/^Failed to load resource/.test(m.text())) errors.push(m.text().split("\n")[0].slice(0, 200)); });
      // Browsers ask every site for /favicon.ico; a missing one is not the app's problem.
      page.on("response", (r) => { const p = new URL(r.url()); if (r.status() >= 400 && p.host === u.host && p.pathname !== "/favicon.ico") failed.push(`${r.status()} ${p.pathname}`); });
      // Watch for layout shifts: content that jumps after it first appears.
      await page.addInitScript(() => { window.__tattvaShift = 0; try { new PerformanceObserver((l) => { for (const e of l.getEntries()) if (!e.hadRecentInput) window.__tattvaShift += e.value; }).observe({ type: "layout-shift", buffered: true }); } catch {} });
      let loadError = null;
      try { await page.goto(u.href, { waitUntil: "load", timeout: 20000 }); await page.waitForTimeout(wait); }
      catch (e) { loadError = String(e.message).split("\n")[0]; }
      if (loadError) { results.push({ size: name, loadError }); await ctx.close(); continue; }
      const found = await page.evaluate(inspect);
      const shift = await page.evaluate(() => window.__tattvaShift ?? 0);
      // Keyboard: the first few Tab stops must show where focus is.
      const noFocusRing = [];
      for (let i = 0; i < 12; i++) {
        await page.keyboard.press("Tab");
        // The ring may be on the field itself or on the box around it (a focus-within outline), up to three levels up.
        const f = await page.evaluate(() => { const el = document.activeElement; if (!el || el === document.body) return null;
          const ringed = (n) => { const cs = getComputedStyle(n); return (cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0) || (cs.boxShadow && cs.boxShadow !== "none"); };
          for (let n = el, i = 0; n && i < 4; n = n.parentElement, i++) if (ringed(n)) return null;
          return (el.getAttribute("aria-label") || el.getAttribute("placeholder") || el.textContent || el.tagName).trim().slice(0, 40); });
        if (f && !noFocusRing.includes(f)) noFocusRing.push(f);
      }
      const shot = join(dir, `${name}${dark ? "-dark" : ""}.png`);
      await page.keyboard.press("Escape").catch(() => {});
      await page.evaluate(() => { document.activeElement?.blur?.(); window.scrollTo(0, 0); });
      await page.screenshot({ path: shot, fullPage: true });
      results.push({ size: name, width: vp.width, screenshot: shot, ...found, shift: Math.round(shift * 1000) / 1000, errors: [...new Set(errors)].slice(0, 8), failed: [...new Set(failed)].slice(0, 8), noFocusRing: noFocusRing.slice(0, 6) });
      await ctx.close();
    }
  } finally { await browser.close(); }
  return { url: u.href, results };
}

/** The findings in plain words, most serious first. */
export function describe(r) {
  if (r.error) return r.error;
  const lines = [];
  let problems = 0;
  for (const s of r.results) {
    if (s.loadError) { lines.push(`${s.size}: the page did not load (${s.loadError}). Is the app running at ${r.url}?`); problems++; continue; }
    const items = [];
    if (s.errors.length) items.push(`errors in the browser: ${s.errors.join(" | ")}`);
    if (s.failed.length) items.push(`requests that failed: ${s.failed.join(", ")}`);
    if (s.sideways) items.push("the page scrolls sideways: something is wider than the screen");
    if (s.spills.length) items.push(`text spills out of its box: ${s.spills.map((x) => `"${x.text}" (${x.where})`).join(", ")}`);
    if (s.overlaps.length) items.push(`controls on top of each other: ${s.overlaps.map((x) => `${x.a} and ${x.b}`).join("; ")}`);
    if (s.unnamed.length) items.push(`buttons or links with no name for screen readers: ${s.unnamed.map((x) => x.where).join(", ")}`);
    if (s.hiddenFocusable.length) items.push(`invisible but reachable with Tab (mark hidden parts inert): ${s.hiddenFocusable.map((x) => `"${x.text || x.where}"`).join(", ")}`);
    if (s.noAlt.length) items.push(`images with no alt: ${s.noAlt.map((x) => x.src || x.where).join(", ")}`);
    if (s.size === "phone" && s.small.length) items.push(`tap targets smaller than 24px: ${s.small.map((x) => `"${x.text || x.where}" ${x.size}`).join(", ")}`);
    if (s.noFocusRing.length) items.push(`no visible focus when tabbing to: ${s.noFocusRing.map((x) => `"${x}"`).join(", ")}`);
    if (s.shift > 0.1) items.push(`content jumps after it loads (layout shift ${s.shift}); reserve space for pictures and late content`);
    problems += items.length;
    lines.push(`${s.size} (${s.width}px): ${items.length ? "" : "no problems found."}`, ...items.map((x) => `  - ${x}`), `  screenshot: ${s.screenshot}`);
  }
  const head = problems ? `${problems} problem${problems === 1 ? "" : "s"} found on screen. Fix them, then call check_screen again.` : "Nothing wrong found on screen at these sizes.";
  return [head, "", ...lines, "", "Look at the screenshots too (open the files): this check cannot judge whether the layout and wording are right."].join("\n");
}
