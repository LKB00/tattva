// Guidance for the Tattva MCP server: the starting questions, the build recipes and the code checker.
// Pure functions, no dependencies. mcp-server.mjs imports this file, so keep the two files together.

/** The questions an agent asks the person before building. Every question has a default, so "defaults" is a valid answer. */
export const QUESTIONS = [
  { id: "product", question: "What are you building?", default: "chat-assistant",
    options: [
      { value: "chat-assistant", label: "A chat assistant (a thread, a message box, sources and confidence)" },
      { value: "agent-console", label: "An agent console (plans, steps, approvals, diffs, a needs-you inbox)" },
      { value: "creative-tool", label: "A creative AI tool (prompt, variations, canvas, history)" },
      { value: "generative-ui", label: "An app where the AI builds interface on the fly" },
      { value: "ai-dashboard", label: "A dashboard for an AI product (usage, cost, charts, tables)" },
    ] },
  { id: "stack", question: "Is this a new project or an existing app, and which framework?", default: "new-vite",
    options: [
      { value: "new-vite", label: "New project with React and Vite" },
      { value: "new-next", label: "New project with Next.js" },
      { value: "existing", label: "Add it to an existing React app that uses Tailwind CSS v4" },
      { value: "no-code", label: "A no-code AI builder such as Lovable, v0 or Bolt (nothing to install)" },
    ] },
  { id: "theme", question: "Which colour theme?", default: "lime",
    options: [
      { value: "lime", label: "Lime: warm paper, fresh lime" },
      { value: "teal", label: "Teal: cool paper, calm teal" },
      { value: "indigo", label: "Indigo: soft violet-blue" },
      { value: "harbor", label: "Harbor: steady, trusted blue" },
      { value: "plum", label: "Plum: warm berry pink" },
      { value: "graphite", label: "Graphite: no colour, the AI is marked by label and icon" },
      { value: "terminal", label: "Terminal: near-black and dense, with a sky-blue AI colour, for trading and data screens" },
    ] },
  { id: "mode", question: "Light, dark, or both?", default: "both",
    options: [{ value: "both", label: "Both, following the person's device" }, { value: "light", label: "Light only" }, { value: "dark", label: "Dark only" }] },
  { id: "trust", question: "Which trust behaviours does the product need? (pick any)", default: ["sources", "feedback"], multiple: true,
    options: [
      { value: "sources", label: "Show sources and citations" },
      { value: "confidence", label: "Show how sure the AI is" },
      { value: "approvals", label: "Ask before the AI acts (approvals)" },
      { value: "undo", label: "Undo and checkpoints" },
      { value: "memory", label: "Memory the person can see and edit" },
      { value: "disclosure", label: "Clear AI labels and disclosure" },
      { value: "feedback", label: "Thumbs up and down feedback" },
      { value: "errors", label: "Calm error, refusal and rate-limit states" },
    ] },
  { id: "plan", question: "Which plan are you on?", default: "free",
    options: [{ value: "free", label: "Free: the basic building blocks and a plain chat" }, { value: "pro", label: "Pro or Team: every part" }] },
];

/** Parts per product, in the order to build them. `core` is always used; `why` is one plain line. Ids are checked against components.json. */
export const RECIPES = {
  "chat-assistant": {
    title: "Chat assistant",
    screen: "thread-template",
    core: [["message-list", "The scrolling thread."], ["message", "One turn: the person's bubble or the assistant's text."], ["composer", "The message box."], ["markdown", "Renders the assistant's formatting safely."], ["thinking-block", "Shows the assistant is working, and what it did."], ["typing-indicator", "A quiet sign a reply is on the way."], ["suggestion-chips", "Starter prompts and follow-ups."], ["message-actions", "Copy, retry and rate under a reply."], ["conversation-list", "Past chats in the sidebar."], ["model-picker", "Lets the person choose a model."]],
    patterns: ["source", "uncertain", "undo", "mistake"],
  },
  "agent-console": {
    title: "Agent console",
    screen: "split-canvas-template",
    core: [["agent-session-list", "All runs, with what each needs."], ["plan-card", "The plan, before the agent starts."], ["step-timeline", "What the agent did, in order."], ["tool-call-card", "One tool call and its result."], ["permission-prompt", "Asks before an action that matters."], ["needs-you-inbox", "Everything waiting on a person, in one place."], ["agent-question-card", "The agent asks a question mid-task."], ["takeover-bar", "Lets the person take control."], ["diff-view", "Shows exactly what changed."], ["checkpoint-list", "Go back to an earlier point."], ["budget-control", "Limits cost and time."], ["re-entry-recap", "Catches the person up when they return."]],
    patterns: ["approval", "ask before", "undo", "work as it happens"],
  },
  "creative-tool": {
    title: "Creative AI tool",
    screen: "split-canvas-template",
    core: [["prompt-box", "Where the person describes what they want."], ["variant-grid", "Several options to choose from."], ["canvas-panel", "The working area."], ["parameter-panel", "Controls such as size, style and strength."], ["generation-progress", "Honest progress while it makes the result."], ["version-history", "Every earlier result, so nothing is lost."], ["variation-actions", "More like this, upscale, edit."], ["suggestion-bar", "Ideas to try next."], ["media-grid", "A library of results."]],
    patterns: ["undo", "mistake", "work as it happens"],
  },
  "generative-ui": {
    title: "Generative interface",
    screen: "thread-template",
    core: [["gen-ui-renderer", "Draws interface the AI describes."], ["generated-surface", "The frame generated content lives in."], ["sandboxed-frame", "Keeps untrusted generated content safe."], ["message-list", "The thread beside it."], ["composer", "The message box."], ["markdown", "Formatted text."], ["ai-label", "Marks what the AI made."]],
    patterns: ["ask before", "undo"],
  },
  "ai-dashboard": {
    title: "AI product dashboard",
    screen: "app-shell",
    core: [["stat-tile", "One headline number."], ["usage-meter", "How much has been used."], ["context-meter", "How full the AI's memory window is."], ["line-chart", "A trend over time."], ["bar-chart", "Compare amounts."], ["data-table", "Rows people can sort and read."], ["chart-frame", "Title, caption and a table view for every chart."], ["timeline", "Events in order."]],
    patterns: ["uncertain"],
  },
};

/** Extra parts for each trust behaviour the person asked for. */
export const TRUST = {
  sources: [["citation-marker", "The small numbered marker in the text."], ["source-list", "The sources behind an answer."], ["source-card", "One source."]],
  confidence: [["confidence-indicator", "Shows how sure the AI is, with a word as well as a colour."]],
  approvals: [["permission-prompt", "Asks before an action that matters."], ["approval-prompt", "A simple yes or no on one step."]],
  undo: [["revert-toggle", "Switch back to the earlier version."], ["checkpoint-list", "Return to an earlier point."], ["version-pager", "Step between versions of a reply."], ["action-log", "A record of what the agent did, with a timed undo."]],
  memory: [["memory-notice", "Tells the person something was remembered."], ["memory-list", "See, edit and delete memories."]],
  disclosure: [["ai-label", "Marks AI-made content."], ["ai-disclosure", "A plain statement that the person is talking to an AI."], ["ai-badge", "A small badge for AI features."]],
  feedback: [["feedback-bar", "Thumbs up and down with a reason."]],
  errors: [["error-state", "Says what went wrong and what to do."], ["refusal-notice", "Explains a refusal kindly."], ["rate-limit-notice", "Explains a limit and when it lifts."], ["callout", "A calm note inside a page."]],
};

const SITE = "https://lkb00.github.io/tattva";
const FONTS = `<link href="https://fonts.googleapis.com/css2?family=Geist:wght@400..700&family=Geist+Mono:wght@400..600&display=swap" rel="stylesheet" />`;

const setupSteps = (a) => {
  const steps = [];
  const stack = a.stack;
  if (stack === "no-code") {
    steps.push("Paste the prompt into your AI builder. It carries your choices and the rules, so you do not need to explain the design system.");
    steps.push(`If the builder cannot install packages, give it the one-file source of every free part: ${SITE}/downloads/tattva-free-source.md, and ask it to copy the parts it needs into the project.`);
    steps.push(`Add the colours: ${SITE}/downloads/tokens.css goes in the project's global stylesheet.${a.theme && a.theme !== "lime" ? ` Then set data-palette="${a.theme}" on the html element.` : ""}`);
    steps.push("Pro parts cannot be installed by a builder. If the plan lists them, use the free parts or ask for a plain stand-in and swap in the Pro part later.");
    return steps;
  }
  if (stack === "new-vite") steps.push("Create the app: `npm create vite@latest my-app -- --template react-ts`, then add Tailwind CSS v4: `npm install tailwindcss @tailwindcss/vite` and add the plugin to vite.config.");
  else if (stack === "new-next") steps.push("Create the app: `npx create-next-app@latest` (TypeScript and Tailwind CSS v4 on), then keep the Tattva files under `src/`.");
  else steps.push("Check the app uses React 18+ and Tailwind CSS v4. Tattva's tokens are written for v4.");
  if (a.plan === "free") steps.push(`Install the free parts and the tokens from npm: \`npm install @tattva/ui\`. Create \`src/tattva.css\` holding \`@import "@tattva/ui/tokens.css";\` and \`@source "../node_modules/@tattva/ui/dist";\` (the tokens load Tailwind, so this replaces your own \`@import "tailwindcss";\`; the @source line lets Tailwind see the classes the parts use) and import it once at the top of the app entry (\`import "./tattva.css";\`).`);
  else steps.push(`Add the tokens: download ${SITE}/downloads/tokens.css, save it as \`src/tokens/tokens.css\` and import it once at the top of the app entry (\`import "./tokens/tokens.css";\`).`);
  steps.push(`Load the fonts (Geist and Geist Mono) by adding this to the page head: ${FONTS}`);
  if (a.theme && a.theme !== "lime") steps.push(`Set the colour theme on the root element: \`<html data-palette="${a.theme}">\`.`);
  if (a.mode === "dark") steps.push('Dark only: add `class="dark"` to the `<html>` element.');
  else if (a.mode === "both") steps.push('Light and dark: toggle `class="dark"` on `<html>`, starting from `matchMedia("(prefers-color-scheme: dark)")` so it follows the device.');
  if (a.plan === "free") steps.push("Import every part from the package only (`import { Message } from \"@tattva/ui\"`), never from a deep path. Pro parts are not in the package; they come with a Pro or Team plan.");
  else steps.push("Install all the parts from the Pro zip: the person got `tattva-pro.zip` when they bought Pro or Team (check their email or the store's download page). Ask them for its path; do not look for it online. Unzip it so that its `tattva` folder lands in `src/` and its `tokens.css` replaces `src/tokens/tokens.css`. Import from that folder only (`import { ApprovalPrompt } from \"./tattva\"`, adjusting the relative path).");
  return steps;
};

/** Files an agent can write as they are, so setup does not depend on it remembering the steps. */
const setupFiles = (a, brief) => {
  const files = [{ path: "tattva.md", why: "The project brief. Read it first in every session.", content: brief + "\n" }];
  if (a.stack === "new-vite") {
    const dark = a.mode === "dark" ? ' class="dark"' : "";
    const palette = a.theme && a.theme !== "lime" ? ` data-palette="${a.theme}"` : "";
    const script = a.mode === "both" ? `
    <script>
      (function () {
        if (matchMedia("(prefers-color-scheme: dark)").matches) document.documentElement.classList.add("dark");
      })();
    </script>` : "";
    files.push(
      { path: "vite.config.ts", why: "React and Tailwind CSS v4.", content: `import { defineConfig } from "vite";\nimport react from "@vitejs/plugin-react";\nimport tailwindcss from "@tailwindcss/vite";\n\nexport default defineConfig({ plugins: [react(), tailwindcss()] });\n` },
      { path: "index.html", why: `Fonts, ${a.theme === "lime" ? "the default theme" : `the ${a.theme} theme`}${a.mode === "both" ? " and light/dark that follows the device" : a.mode === "dark" ? " and dark mode" : ""}.`, content: `<!doctype html>\n<html lang="en"${dark}${palette}>\n  <head>\n    <meta charset="UTF-8" />\n    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n    <title>My app</title>\n    <link rel="preconnect" href="https://fonts.googleapis.com" />\n    ${FONTS}${script}\n  </head>\n  <body>\n    <div id="root"></div>\n    <script type="module" src="/src/main.tsx"></script>\n  </body>\n</html>\n` },
      { path: "src/main.tsx", why: "Loads the tokens and renders App. You write src/App.tsx.", content: `import { StrictMode } from "react";\nimport { createRoot } from "react-dom/client";\nimport "${a.plan === "free" ? "./tattva.css" : "./tokens/tokens.css"}";\nimport { App } from "./App";\n\ncreateRoot(document.getElementById("root")!).render(<StrictMode><App /></StrictMode>);\n` },
    );
    if (a.plan === "free") files.push({ path: "src/tattva.css", why: "The Tattva tokens (they load Tailwind) and the package's classes.", content: `@import "@tattva/ui/tokens.css";\n@source "../node_modules/@tattva/ui/dist";\n` });
  }
  return files;
};

const setupCommands = (a) => a.stack === "no-code" ? [] : [
  ...(a.stack === "new-vite" ? ["npm create vite@latest my-app -- --template react-ts", "cd my-app && npm install && npm install tailwindcss @tailwindcss/vite"] : []),
  ...(a.plan === "free" ? ["npm install @tattva/ui"] : [`mkdir -p src/tokens && curl -fsSL ${SITE}/downloads/tokens.css -o src/tokens/tokens.css`, "unzip -oq <path to tattva-pro.zip> 'tattva/*' -d src && unzip -oqj <path to tattva-pro.zip> tokens.css -d src/tokens"]),
  ...(a.stack === "new-vite" ? ["rm -f src/index.css src/App.css"] : []),
];

/** Builds the plan for an agent: setup, parts in order (with Pro marks), patterns to read and a brief to save. */
export function planBuild(rawAnswers, components) {
  const byId = new Map(components.map((c) => [c.id, c]));
  const a = { product: "chat-assistant", stack: "new-vite", theme: "lime", mode: "both", trust: ["sources", "feedback"], plan: "free", ...Object.fromEntries(Object.entries(rawAnswers ?? {}).filter(([, v]) => v !== undefined && v !== null && v !== "")) };
  if (typeof a.trust === "string") a.trust = a.trust.split(/[,\s]+/).filter(Boolean);
  const recipe = RECIPES[a.product];
  if (!recipe) return { error: `Unknown product "${a.product}". Use one of: ${Object.keys(RECIPES).join(", ")}.` };
  const warnings = [];
  const themes = ["lime", "teal", "indigo", "harbor", "plum", "graphite", "terminal"];
  if (!themes.includes(a.theme)) { warnings.push(`Unknown theme "${a.theme}"; using lime. Themes: ${themes.join(", ")}.`); a.theme = "lime"; }
  const unknownTrust = a.trust.filter((t) => !TRUST[t]);
  if (unknownTrust.length) warnings.push(`Ignored unknown trust behaviours: ${unknownTrust.join(", ")}. Known: ${Object.keys(TRUST).join(", ")}.`);
  const seen = new Set();
  const parts = [];
  const add = (list, group) => {
    for (let [id, why] of list) {
      if (seen.has(id)) continue; seen.add(id);
      let c = byId.get(id);
      if (!c) { warnings.push(`The part "${id}" was not found in this copy of Tattva, so it is left out.`); continue; }
      const stage = c.lifecycle?.stage ?? c.status ?? "stable";
      if ((stage === "deprecated" || stage === "retired") && c.lifecycle?.replacedBy && byId.get(c.lifecycle.replacedBy)) {
        warnings.push(`${c.name} is ${stage}; using ${byId.get(c.lifecycle.replacedBy).name} instead.`);
        c = byId.get(c.lifecycle.replacedBy); id = c.id;
        if (seen.has(id)) continue; seen.add(id);
      }
      parts.push({ id, name: c.name, group, why, plan: c.plan ?? "free", stage: c.lifecycle?.stage ?? c.status ?? "stable", importLine: c.importPath });
    }
  };
  add([[recipe.screen, `The page layout (${recipe.title}).`]], "Screen");
  add(recipe.core, recipe.title);
  for (const t of a.trust.filter((x) => TRUST[x])) add(TRUST[t], `Trust: ${t}`);
  const pro = parts.filter((p) => p.plan === "pro");
  if (a.plan === "free" && pro.length) warnings.push(`${pro.length} of ${parts.length} parts are Pro (${pro.slice(0, 6).map((p) => p.name).join(", ")}${pro.length > 6 ? ", ..." : ""}). Their previews and guidance are free, but their code comes with Pro or Team: ${SITE}/#pricing. Tell the person before relying on them, and offer the free parts first.`);
  const brief = [
    "# Tattva project brief", "",
    "Saved by the Tattva MCP server. Read this first in every session so the product stays consistent.", "",
    `- Product: ${recipe.title}`, `- Stack: ${a.stack}`, `- Theme: ${a.theme}${a.theme === "lime" ? " (default)" : ` (data-palette="${a.theme}")`}`, `- Mode: ${a.mode}`,
    `- Trust behaviours: ${a.trust.join(", ") || "none"}`, `- Plan: ${a.plan}`, "",
    "## Parts", ...parts.map((p) => `- ${p.name}${p.plan === "pro" ? " (Pro)" : ""}: ${p.why}`), "",
    "## Rules", "- Import from the package index only.", "- Use tokens (`var(--surface)`), never hex values.", "- The AI colour (`--lime`) is a fill, never text. Amber means a person has to act.",
    "- Every control has an accessible name. Status is never colour alone.", "- Run `review_code` on each file before finishing.",
  ].join("\n");
  return { answers: a, recipe: { product: a.product, title: recipe.title, screen: recipe.screen }, setup: setupSteps(a), commands: setupCommands(a), files: setupFiles(a, brief), parts, patterns: recipe.patterns, warnings, brief };
}

/**
 * The one prompt a person pastes into an AI tool, from a plan. Written to the AI, not to the person.
 * The Build brief page and the tests use this same function.
 */
export function buildPrompt(plan) {
  const a = plan.answers;
  const noCode = a.stack === "no-code";
  const pro = plan.parts.filter((p) => p.plan === "pro");
  const setup = noCode
    ? [
        `If you can install packages, run npm install @tattva/ui, put @import "@tattva/ui/tokens.css"; and @source "../node_modules/@tattva/ui/dist"; at the top of the main stylesheet (they replace @import "tailwindcss";), and import every part from "@tattva/ui". If you cannot install packages, read ${SITE}/downloads/tattva-free-source.md, which holds the source of every free part in one file, recreate the parts you need under src/tattva/ with the same file names, and import from there.`,
        `If you used the source file, add the colours from ${SITE}/downloads/tokens.css to the project's global stylesheet.${a.theme && a.theme !== "lime" ? ` Set data-palette="${a.theme}" on the html element.` : ""}${a.mode === "both" ? " Toggle the dark class on the html element to follow the device's colour scheme." : a.mode === "dark" ? " Add the dark class to the html element." : ""}`,
      ]
    : plan.setup;
  return [
    `I want to build: ${plan.recipe.title}.`,
    "",
    `Use the Tattva design system. Read its guide first: ${SITE}/llms.txt (it links to a page for every part). Theme: ${a.theme}. Mode: ${a.mode === "both" ? "light and dark, following the device" : a.mode}.`,
    "",
    "Setup:",
    ...setup.map((x, i) => `${i + 1}. ${x}`),
    "",
    "Use these parts, in this order:",
    ...plan.parts.map((p) => `- ${p.name}${p.plan === "pro" ? " (Pro)" : ""}: ${p.why}`),
    ...(pro.length ? ["", `Parts marked (Pro) have a free preview and guidance, but their code is not available to you. Build the screen from the free parts, and for each Pro part use a simple plain stand-in built from free parts, with a comment naming the Pro part so I can swap it in later.`] : []),
    "",
    "Rules:",
    "- Import parts and icons only from the tattva folder, never from a deep path (icons are named like SendIcon and CopyIcon). Never write hex colours; use the tokens (var(--surface), var(--fg)).",
    "- The AI colour marks AI only, and is never used as text. Amber means a person has to act.",
    "- Every button and icon has a clear name. Status is never colour alone.",
    "- If no part fits something I ask for, tell me and ask. Do not invent parts, props or colours.",
    "",
    "Project brief (save it as tattva.md and read it first next time):",
    plan.brief,
  ].join("\n");
}

/** The checks run by review_code. Each has a rule name, how serious it is, a test for one line, and how to fix it. */
const CHECKS = [
  { rule: "no-hex", level: "error", test: (l) => /(?<![\w&])#[0-9a-fA-F]{3,8}\b/.test(l.replace(/\b(?:href|to|xlinkHref)=["']#[^"']*["']/g, "").replace(/url\(#[^)]*\)/g, "")) && !/^\s*(\/\/|\*|\/\*)/.test(l) && /(color|bg-|text-|border|fill|stroke|background|style|className|#[0-9a-fA-F]{6}\b)/.test(l), fix: "Use a token: `var(--surface)`, `var(--fg)` or a class such as `bg-surface` and `text-fg-muted`. Ask get_tokens for the right name." },
  { rule: "no-color-function", level: "error", test: (l) => /\b(rgb|rgba|hsl|hsla|oklch)\(/.test(l) && !/var\(|--/.test(l) && !/^\s*(\/\/|\*)/.test(l), fix: "Use a token instead of a raw colour function." },
  { rule: "no-default-palette", level: "error", test: (l) => /\b(?:bg|text|border|ring|fill|stroke|from|to|via)-(?:red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|slate|gray|zinc|neutral|stone)-\d{2,3}\b/.test(l), fix: "Tailwind's default palette is not part of Tattva. Use classes built from tokens, such as `bg-surface`, `text-fg`, `border-line`, `bg-lime-soft`." },
  { rule: "no-deep-import", level: "error", test: (l) => /from\s+["'][^"']*\/(?:atoms|molecules|organisms|templates|pages)\/[^"']*["']/.test(l), fix: "Import from the package index: `import { Message } from \"./index\"`." },
  { rule: "no-div-click", level: "error", test: (l) => /<(?:div|span)\b[^>]*\bonClick=/.test(l) && !/role=["']button["']/.test(l), fix: "Use a real `<button>` (or Tattva's Button). A clickable div cannot be reached with the keyboard." },
  { rule: "lime-as-text", level: "error", test: (l) => /\btext-lime\b|color:\s*var\(--lime\)/.test(l), fix: "The AI colour is a fill, never text colour. Put dark text on it (`text-on-lime`)." },
  { rule: "focus-removed", level: "warn", test: (l) => /\b(?:focus:)?outline-none\b|outline:\s*none/.test(l) && !/focus-visible|ring/.test(l), fix: "Do not remove the focus outline. Tattva already draws one; keep it, or replace it with a visible ring." },
  { rule: "vague-destructive", level: "warn", test: (l) => />\s*(?:Delete|Remove|Discard|Reset)\s*</.test(l), fix: "Say the effect: \"Delete project Atlas\", not \"Delete\"." },
  { rule: "raw-html", level: "warn", test: (l) => /dangerouslySetInnerHTML/.test(l), fix: "Avoid raw HTML from the AI. Use Markdown, or put untrusted content in SandboxedFrame." },
  { rule: "amber-check", level: "info", test: (l) => /\b(?:text|bg|border)-attention\b|var\(--attention/.test(l), fix: "Amber means a person has to act. Use it only for a \"needs you\" state, not for warnings or decoration." },
  { rule: "colour-only-status", level: "info", test: (l) => /\b(?:text|bg)-(?:success|danger)\b/.test(l) && !/<(?:Icon|svg)|aria-label|sr-only/.test(l), fix: "Status must not rely on colour alone. Pair it with an icon and a word." },
];

/** Checks a piece of code against Tattva's rules. Returns findings with line numbers. */
export function reviewCode(code, components = [], filename = "") {
  const lines = String(code).split("\n");
  const findings = [];
  lines.forEach((line, i) => {
    for (const c of CHECKS) if (c.test(line)) findings.push({ line: i + 1, rule: c.rule, level: c.level, text: line.trim().slice(0, 140), fix: c.fix });
  });
  // Tag checks: read the whole opening tag, so props on several lines are seen.
  const src = String(code);
  const tagOf = (from) => { let depth = 0; for (let k = from; k < src.length; k++) { const ch = src[k]; if (ch === "{") depth++; else if (ch === "}") depth--; else if (ch === ">" && depth === 0) return src.slice(from, k + 1); } return src.slice(from, from + 400); };
  for (const [re, attr, rule, fix] of [
    [/<IconButton\b/g, /\blabel=/, "icon-button-label", "Every IconButton needs a `label` that names what it does, such as `label=\"Copy reply\"`."],
    [/<img\b/g, /\balt=/, "img-alt", "Give every image an `alt`, or `alt=\"\"` if it is decoration."],
  ]) for (const m of src.matchAll(re)) { const tag = tagOf(m.index); if (!attr.test(tag) && !/\{\.\.\.\w+\}/.test(tag)) findings.push({ line: src.slice(0, m.index).split("\n").length, rule, level: "error", text: tag.split("\n")[0].trim().slice(0, 140), fix }); }
  // Parts that are on their way out.
  for (const c of components) {
    const l = c.lifecycle; if (!l || (l.stage !== "deprecated" && l.stage !== "retired")) continue;
    const re = new RegExp(`<${c.name}\\b`, "g");
    for (const m of src.matchAll(re)) findings.push({ line: src.slice(0, m.index).split("\n").length, rule: `${l.stage}-part`, level: l.stage === "retired" ? "error" : "warn", text: `<${c.name}>`, fix: `${c.name} is ${l.stage}${l.removeIn ? ` (removed in ${l.removeIn})` : ""}. ${l.note ?? ""} Use ${components.find((x) => x.id === l.replacedBy)?.name ?? l.replacedBy} instead.` });
  }
  // Names imported from the package index must exist.
  const names = new Set(components.map((c) => c.name));
  const ids = components.map((c) => c.id);
  for (const m of String(code).matchAll(/import\s*\{([^}]+)\}\s*from\s*["']([^"']+)["']/g)) {
    if (!/(^|\/)(index|tattva)$/.test(m[2]) && !/tattva/.test(m[2])) continue;
    const at = String(code).slice(0, m.index).split("\n").length;
    for (const raw of m[1].split(",")) {
      const n = raw.trim().split(/\s+as\s+/)[0];
      if (!n || names.has(n) || !/^[A-Z]/.test(n)) continue;
      const near = ids.map((id) => ({ id, d: lev(n.toLowerCase(), id.replace(/-/g, "")) })).sort((x, y) => x.d - y.d)[0];
      findings.push({ line: at, rule: "unknown-part", level: "error", text: raw.trim(), fix: `"${n}" is not a Tattva part.${near && near.d <= 6 ? ` Did you mean "${components.find((c) => c.id === near.id).name}"?` : ""} Call search_components to find the right one.` });
    }
  }
  findings.sort((x, y) => x.line - y.line);
  const order = { error: 0, warn: 1, info: 2 };
  return { filename, findings, counts: { error: findings.filter((f) => f.level === "error").length, warn: findings.filter((f) => f.level === "warn").length, info: findings.filter((f) => f.level === "info").length }, order };
}

function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
