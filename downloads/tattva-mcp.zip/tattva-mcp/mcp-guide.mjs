// Guidance for the Tattva MCP server: the starting questions, the build recipes and the code checker.
// Pure functions, no dependencies. mcp-server.mjs imports this file, so keep the two files together.

/** The questions an agent asks the person before building. Every question has a default, so "defaults" is a valid answer. */
/**
 * How an AI tool should talk to the person when something is blocked or missing. One text, used in llms.txt, the MCP
 * instructions, the plan_build result and the pasted build prompt, so every route says the same thing. The person may
 * not be a developer: they should never have to read an error code to know what to do next.
 */
export const PLAIN_WORDS = [
  "How to talk to the person (read this before you reply)",
  "The person using you may not be a developer. When something is blocked or not available, tell them in plain words, never the technical detail.",
  "1. Say three short things, in this order: what you could not do; what that means for them; the ONE thing they can do next.",
  "2. Never show error codes (403, 404, 429) or words like proxy, registry, policy, sandbox, firewall, no-proxy list, token, MCP or fetch. Keep that detail to yourself unless they ask.",
  "3. Do not narrate your attempts. Try once, switch to the fallback, then report the result.",
  "4. End with what is done, what is a stand-in, and what they should do next.",
  "Examples of how to say it:",
  "- Cannot install: \"I cannot download Tattva's code from inside this tool. Please upload the file tattva-free-source.md (https://lkb00.github.io/tattva/downloads/tattva-free-source.md) here, or tell me to read the small pieces at https://lkb00.github.io/tattva/downloads/source/index.md, and I will build your screen from it.\"",
  "- Cannot open the website: \"This tool cannot open the Tattva website, so I could only read a summary. If you can, paste the page or upload the file here, or switch on web access for this tool.\"",
].join("\n");

export const QUESTIONS = [
  { id: "product", question: "What are you building?", default: "chat-assistant",
    options: [
      { value: "chat-assistant", label: "A chat assistant (a thread, a message box, sources and confidence)" },
      { value: "agent-console", label: "An agent console (plans, steps, approvals, diffs, a needs-you inbox)" },
      { value: "creative-tool", label: "A creative AI tool (prompt, variations, canvas, history)" },
      { value: "generative-ui", label: "An app where the AI builds interface on the fly" },
      { value: "ai-dashboard", label: "A dashboard for an AI product (usage, cost, charts, tables)" },
    ] },
  { id: "stack", question: "Is this a new project or an existing app, and which framework?", default: "new-vite",
    options: [
      { value: "new-vite", label: "New project with React and Vite" },
      { value: "new-next", label: "New project with Next.js" },
      { value: "existing", label: "Add it to an existing React app that uses Tailwind CSS v4" },
      { value: "no-code", label: "A no-code AI builder such as Lovable, v0 or Bolt (nothing to install)" },
    ] },
  { id: "theme", question: "Which colour theme?", default: "lime",
    options: [
      { value: "lime", label: "Lime: warm paper, fresh lime" },
      { value: "teal", label: "Teal: cool paper, calm teal" },
      { value: "indigo", label: "Indigo: soft violet-blue" },
      { value: "harbor", label: "Harbor: steady, trusted blue" },
      { value: "plum", label: "Plum: warm berry pink" },
      { value: "graphite", label: "Graphite: no colour, the AI is marked by label and icon" },
      { value: "terminal", label: "Terminal: near-black and dense, with a sky-blue AI colour, for trading and data screens" },
    ] },
  { id: "mode", question: "Light, dark, or both?", default: "both",
    options: [{ value: "both", label: "Both, following the person's device" }, { value: "light", label: "Light only" }, { value: "dark", label: "Dark only" }] },
  { id: "trust", question: "What should people see that helps them trust the answers? (pick any)", default: ["sources", "feedback"], multiple: true,
    options: [
      { value: "sources", label: "Sources: small numbers in the answer that link to where each fact came from" },
      { value: "confidence", label: "Confidence: a short note when the AI is not sure" },
      { value: "approvals", label: "Approvals: the AI asks before it does something, such as booking or paying" },
      { value: "undo", label: "Undo: a way back after the AI changes something" },
      { value: "memory", label: "Memory: a list of what the AI remembers, which people can edit" },
      { value: "disclosure", label: "AI labels: a clear mark on anything the AI wrote" },
      { value: "feedback", label: "Feedback: thumbs up and down under each answer" },
      { value: "errors", label: "Calm errors: a plain message and a next step when something goes wrong" },
    ] },
];

/** Parts per product, in the order to build them. `core` is always used; `why` is one plain line. Ids are checked against components.json. */
export const RECIPES = {
  "chat-assistant": {
    title: "Chat assistant",
    screen: "thread-template",
    core: [["empty-state", "The first screen, before any message: what the assistant can do, in one heading and one line."], ["message-list", "The scrolling thread."], ["message", "One turn: the person's bubble or the assistant's text."], ["composer", "The message box."], ["markdown", "Renders the assistant's formatting safely."], ["thinking-block", "Shows the assistant is working, and what it did."], ["typing-indicator", "A quiet sign a reply is on the way."], ["suggestion-chips", "Starter prompts and follow-ups."], ["message-actions", "Copy, retry and rate under a reply."], ["conversation-list", "Past chats in the sidebar."], ["model-picker", "Lets the person choose a model."]],
    patterns: ["source", "uncertain", "undo", "mistake"],
  },
  "agent-console": {
    title: "Agent console",
    screen: "split-canvas-template",
    core: [["agent-session-list", "All runs, with what each needs."], ["plan-card", "The plan, before the agent starts."], ["step-timeline", "What the agent did, in order."], ["tool-call-card", "One tool call and its result."], ["permission-prompt", "Asks before an action that matters."], ["approval-inbox", "Everything waiting on a person, in one place."], ["agent-question-card", "The agent asks a question mid-task."], ["takeover-bar", "Lets the person take control."], ["diff-view", "Shows exactly what changed."], ["checkpoint-list", "Go back to an earlier point."], ["budget-control", "Limits cost and time."], ["catch-up-summary", "Catches the person up when they return."]],
    patterns: ["approval", "ask before", "undo", "work as it happens"],
  },
  "creative-tool": {
    title: "Creative AI tool",
    screen: "split-canvas-template",
    core: [["prompt-box", "Where the person describes what they want."], ["variant-grid", "Several options to choose from."], ["canvas-panel", "The working area."], ["parameter-panel", "Controls such as size, style and strength."], ["generation-progress", "Honest progress while it makes the result."], ["version-history", "Every earlier result, so nothing is lost."], ["variation-actions", "More like this, upscale, edit."], ["suggestion-bar", "Ideas to try next."], ["media-grid", "A library of results."]],
    patterns: ["undo", "mistake", "work as it happens"],
  },
  "generative-ui": {
    title: "Generative interface",
    screen: "thread-template",
    core: [["gen-ui-renderer", "Draws interface the AI describes."], ["generated-surface", "The frame generated content lives in."], ["sandboxed-frame", "Keeps untrusted generated content safe."], ["message-list", "The thread beside it."], ["composer", "The message box."], ["markdown", "Formatted text."], ["ai-label", "Marks what the AI made."]],
    patterns: ["ask before", "undo"],
  },
  "ai-dashboard": {
    title: "AI product dashboard",
    screen: "app-shell",
    core: [["stat-tile", "One headline number."], ["usage-meter", "How much has been used."], ["context-meter", "How full the AI's memory window is."], ["line-chart", "A trend over time."], ["bar-chart", "Compare amounts."], ["data-table", "Rows people can sort and read."], ["chart-frame", "Title, caption and a table view for every chart."], ["timeline", "Events in order."]],
    patterns: ["uncertain"],
  },
};

/** Extra parts for each trust behaviour the person asked for. */
export const TRUST = {
  sources: [["citation-marker", "The small numbered marker in the text."], ["source-list", "The sources behind an answer."], ["source-card", "One source."]],
  confidence: [["confidence-indicator", "Shows how sure the AI is, with a word as well as a colour."]],
  approvals: [["permission-prompt", "Asks before an action that matters."], ["approval-prompt", "A simple yes or no on one step."]],
  undo: [["revert-toggle", "Switch back to the earlier version."], ["checkpoint-list", "Return to an earlier point."], ["version-pager", "Step between versions of a reply."], ["action-log", "A record of what the agent did, with a timed undo."]],
  memory: [["memory-notice", "Tells the person something was remembered."], ["memory-list", "See, edit and delete memories."]],
  disclosure: [["ai-label", "Marks AI-made content."], ["ai-disclosure", "A plain statement that the person is talking to an AI."], ["ai-badge", "A small badge for AI features."]],
  feedback: [["feedback-bar", "Thumbs up and down with a reason."]],
  errors: [["error-state", "Says what went wrong and what to do."], ["refusal-notice", "Explains a refusal kindly."], ["rate-limit-notice", "Explains a limit and when it lifts."], ["callout", "A calm note inside a page."]],
};

/*
 * The site map: the screens a product needs, how people move between them, the main journey, and what each screen
 * shows when it is empty, loading or failed. Proposed before building, for the person to approve or change, and saved
 * in tattva.md so every later session builds to the same map. `kind`: top (a tab on a phone, a sidebar item on a
 * desktop), inside (part of another screen), panel (a sheet on a phone, a side panel on a desktop), dialog.
 */
const ST = {
  list: (thing) => ({ empty: `"No ${thing} yet." One line on how they appear, and the first step.`, loading: "Placeholder rows (Skeleton) in the shape of the list.", error: `"Could not load your ${thing}." ErrorState with Retry.` }),
  detail: (thing) => ({ empty: `(always opens with a ${thing})`, loading: "Placeholders for the picture and facts.", error: `"Could not load this ${thing}." ErrorState with Retry.` }),
};
export const SITEMAPS = {
  "chat-assistant": {
    journey: ["Ask", "the answer streams in", "follow up", "find the chat again later"],
    screens: [
      { name: "Ask", kind: "top", purpose: "Start a conversation in your own words.", layout: "thread-template", parts: ["empty-state", "suggestion-chips", "composer"],
        states: { empty: "Heading, one line on what it can do, three starters.", loading: "(nothing to load)", error: "ErrorState with Retry; the message stays in the box." } },
      { name: "Conversation", kind: "inside", purpose: "Read the answer and keep asking.", layout: "thread-template", parts: ["message-list", "message", "typing-indicator", "composer", "feedback-bar"],
        states: { empty: "(always has the first message)", loading: "Typing indicator, then the answer streams in.", error: "The part that arrived stays; a calm note says the rest failed, with Retry." } },
      { name: "History", kind: "top", purpose: "Find and reopen earlier chats.", layout: "app-shell", parts: ["conversation-list", "empty-state"], states: ST.list("chats") },
    ],
  },
  "agent-console": {
    journey: ["Give a task", "approve the plan", "watch the steps", "answer what needs you", "review the changes"],
    screens: [
      { name: "Runs", kind: "top", purpose: "Every task the agent is working on, and which ones need you.", layout: "split-canvas-template", parts: ["agent-session-list", "empty-state"], states: ST.list("runs") },
      { name: "Plan", kind: "inside", purpose: "What the agent will do, to approve or change before it starts.", layout: "split-canvas-template", parts: ["plan-card"],
        states: { empty: "(always has a task)", loading: "\"Making a plan\" with a Spinner; Stop stays available.", error: "\"Could not make a plan.\" Plain reason, Try again, and the task stays." } },
      { name: "Run", kind: "inside", purpose: "Each step as it happens, with its tool calls.", layout: "split-canvas-template", parts: ["step-timeline", "tool-call-card", "activity-trace"],
        states: { empty: "(starts with the first step)", loading: "The current step is marked as working; Stop is always visible.", error: "The failed step says what went wrong and offers Retry or Skip; earlier steps stay." } },
      { name: "Needs you", kind: "top", purpose: "Everything waiting for a person's answer, oldest first.", layout: "app-shell", parts: ["approval-inbox", "permission-prompt"],
        states: { empty: "\"Nothing needs you.\" The agent keeps working.", loading: "Placeholder rows.", error: "\"Could not load what needs you.\" Retry; nothing is approved by default." } },
      { name: "Changes", kind: "panel", purpose: "What the agent changed, to keep or undo.", layout: "split-canvas-template", parts: ["diff-view"], states: ST.detail("change") },
    ],
  },
  "creative-tool": {
    journey: ["Describe it", "pick from the options", "adjust", "keep a version", "export"],
    screens: [
      { name: "Start", kind: "top", purpose: "Describe what to make, or start from an example.", layout: "split-canvas-template", parts: ["starter-gallery", "prompt-box"],
        states: { empty: "Examples to start from and an empty prompt box.", loading: "Example placeholders.", error: "Examples hide; the prompt box still works." } },
      { name: "Studio", kind: "inside", purpose: "Compare options and adjust the chosen one.", layout: "split-canvas-template", parts: ["variant-grid", "canvas-panel", "parameter-panel", "generation-progress"],
        states: { empty: "(always has a prompt)", loading: "GenerationProgress with an honest estimate and Stop.", error: "Options that finished stay; the failed one says why, with Try again." } },
      { name: "History", kind: "panel", purpose: "Earlier versions, to go back to.", layout: "split-canvas-template", parts: ["version-history"], states: ST.list("versions") },
      { name: "Export", kind: "dialog", purpose: "Save or share the finished piece.", layout: "dialog", parts: ["share-panel"],
        states: { empty: "(always has something to export)", loading: "The button shows it is working and cannot be pressed twice.", error: "A plain reason and another way to save." } },
    ],
  },
  "generative-ui": {
    journey: ["Ask", "the AI builds a view", "use it", "confirm anything it would do"],
    screens: [
      { name: "Ask", kind: "top", purpose: "Say what you need in your own words.", layout: "thread-template", parts: ["message-list", "composer", "empty-state"],
        states: { empty: "Heading, one line on what it can build, three starters.", loading: "Typing indicator.", error: "ErrorState with Retry; the message stays in the box." } },
      { name: "Generated view", kind: "inside", purpose: "The interface the AI built for this request.", layout: "thread-template", parts: ["generated-surface", "gen-ui-renderer", "sandboxed-frame"],
        states: { empty: "(always has a request)", loading: "The frame fills in as it streams; placeholders for what is still coming.", error: "A plain note and the answer as text instead." } },
      { name: "Confirm", kind: "dialog", purpose: "Anything the generated view would do is confirmed first.", layout: "dialog", parts: ["inline-confirm"],
        states: { empty: "(always has an action)", loading: "Confirm shows it is working.", error: "A plain reason; nothing was done." } },
    ],
  },
  "ai-dashboard": {
    journey: ["See the headline numbers", "open one for detail", "set a limit"],
    screens: [
      { name: "Overview", kind: "top", purpose: "The few numbers that matter, and their trend.", layout: "app-shell", parts: ["stat-tile", "line-chart", "usage-meter", "data-freshness"],
        states: { empty: "\"No usage yet.\" One line on when numbers appear.", loading: "Tile and chart placeholders in their final size.", error: "\"Could not load the numbers.\" Retry, and when the last good numbers are from." } },
      { name: "Details", kind: "top", purpose: "Every row behind a number, to sort and compare.", layout: "app-shell", parts: ["chart-frame", "bar-chart", "data-table"], states: ST.list("rows") },
      { name: "Limits", kind: "top", purpose: "Budgets and alerts.", layout: "app-shell", parts: ["budget-control"],
        states: { empty: "\"No limits set.\" One line on what a limit does.", loading: "Placeholders.", error: "\"Could not save the limit.\" The old limit still applies." } },
    ],
  },
};

const RESULT_WORDS = /\b(hotels?|flights?|products?|shops?|shopping|stores?|restaurants?|places?|homes?|apartments?|rooms?|cars?|jobs?|courses?|recipes?|events?|tickets?|listings?|plans?|options|recommend\w*|compare|choose|booking|travel|trips?)\b/i;

/** Proposes the site map for a product. Same answers as planBuild; returns screens, navigation, journey and Markdown. */
export function planSitemap(rawAnswers, components) {
  const a = { product: "chat-assistant", trust: ["sources", "feedback"], ...Object.fromEntries(Object.entries(rawAnswers ?? {}).filter(([, v]) => v !== undefined && v !== null && v !== "")) };
  if (typeof a.trust === "string") a.trust = a.trust.split(/[,\s]+/).filter(Boolean);
  const base = SITEMAPS[a.product];
  if (!base) return { error: `Unknown product "${a.product}". Use one of: ${Object.keys(SITEMAPS).join(", ")}.` };
  const screens = base.screens.map((s) => ({ ...s, parts: [...s.parts] }));
  const journey = [...base.journey];
  const idea = String(a.idea ?? "");
  const conv = screens.find((s) => s.name === "Conversation" || s.name === "Generated view");
  if (a.trust.includes("sources") && conv) conv.parts.push("source-list");
  // Answers that recommend things to choose between get results, a details panel and, with approvals, a review step.
  if (RESULT_WORDS.test(idea) && (a.product === "chat-assistant" || a.product === "generative-ui")) {
    const at = screens.indexOf(conv) + 1;
    screens.splice(at, 0,
      { name: "Results", kind: "inside", purpose: "Compare the options the answer suggests.", layout: "thread-template", parts: ["card-row", "result-card", "fact-list"],
        states: { empty: "\"Nothing matches.\" One line on what to change, such as a bigger budget or another area.", loading: "Card placeholders (ResultCard loading).", error: "Cards that arrived stay; a note says the rest failed." } },
      { name: "Details", kind: "panel", purpose: "Everything about one option before deciding.", layout: "sheet", parts: ["media-grid", "fact-list", "sections", ...(a.trust.includes("sources") ? ["source-list"] : [])], states: ST.detail("option") });
    journey.splice(1, 1, "options as cards", "open one");
  }
  // Agent consoles already have Needs you, and generated views already confirm each action.
  if (a.trust.includes("approvals") && a.product !== "agent-console" && a.product !== "generative-ui") {
    screens.push(
      { name: "Review and approve", kind: "dialog", purpose: "Check exactly what will happen, then approve or say no.", layout: "dialog", parts: ["approval-prompt", "receipt"],
        states: { empty: "(always has an action)", loading: "Approve shows it is working and cannot be pressed twice.", error: "A plain reason and the next step; nothing was done or charged." } },
      { name: "Done", kind: "inside", purpose: "Proof it went through, and what happens next.", layout: screens[0].layout, parts: ["receipt", "callout"],
        states: { empty: "(always follows an approval)", loading: "(nothing to load)", error: "(shown only after success)" } });
    // Before "find it again later", which stays the last step.
    const end = /^find/.test(journey.at(-1)) ? journey.pop() : null;
    journey.push("review and approve", "see the receipt", ...(end ? [end] : []));
  }
  if (a.trust.includes("memory")) screens.push({ name: "Memory", kind: "top", purpose: "What the AI remembers, to edit or delete.", layout: "app-shell", parts: ["memory-list", "empty-state"], states: ST.list("memories") });
  if (a.trust.includes("undo") && a.product !== "agent-console") screens.push({ name: "Activity", kind: "panel", purpose: "What the AI changed, with undo.", layout: "sheet", parts: ["action-log"], states: ST.list("changes") });
  if (a.product === "agent-console" && a.trust.includes("undo")) screens.find((s) => s.name === "Changes").parts.push("action-log");

  const byId = new Map((components ?? []).map((c) => [c.id, c]));
  const nameOf = (id) => byId.get(id)?.name ?? id;
  const warnings = [];
  for (const s of screens) s.parts = [...new Set(s.parts)].filter((id) => byId.size === 0 || byId.has(id) || (warnings.push(`The part "${id}" was not found, so it is left out of ${s.name}.`), false));
  const tops = screens.filter((s) => s.kind === "top");
  const panels = screens.filter((s) => s.kind === "panel"), dialogs = screens.filter((s) => s.kind === "dialog");
  const opens = (xs) => `${list(xs.map((s) => s.name))} ${xs.length === 1 ? "opens as a sheet" : "open as sheets"} from the bottom; Back closes ${xs.length === 1 ? "it" : "them"}.`;
  const list = (xs) => xs.length < 2 ? xs.join("") : `${xs.slice(0, -1).join(", ")} and ${xs.at(-1)}`;
  const navigation = {
    phone: tops.length <= 1 ? `One screen, no tabs.${panels.length ? ` ${opens(panels)}` : ""}`
      : `${tops.length <= 4 ? `${tops.length} tabs at the bottom` : "A menu button at the top"}: ${list(tops.map((s) => s.name))}.${panels.length ? ` ${opens(panels)}` : ""}`,
    desktop: `${tops.length > 1 ? `A sidebar with ${list(tops.map((s) => s.name))}` : "One main area"}.${panels.length ? ` ${list(panels.map((s) => s.name))} open${panels.length === 1 ? "s" : ""} in a side panel, so the main view stays.` : ""}`,
    dialogs: dialogs.length ? `${list(dialogs.map((s) => s.name))} ${dialogs.length === 1 ? "is the only dialog" : "are the only dialogs"}. Nothing else interrupts.` : "No dialogs. Nothing interrupts.",
  };
  const where = { top: "main screen", inside: "inside another screen", panel: "sheet on a phone, side panel on a desktop", dialog: "dialog" };
  const markdown = [
    "## Site map", "",
    "Approved before building. Build every screen below, with its empty, loading and error states. Change this section, not the code, when the map changes.", "",
    "### Screens", ...screens.map((s, i) => `${i + 1}. **${s.name}** (${where[s.kind]}): ${s.purpose} Layout: ${nameOf(s.layout === "sheet" ? "sheet" : s.layout)}. Parts: ${s.parts.map(nameOf).join(", ")}.`), "",
    "### Navigation", `- Phone: ${navigation.phone}`, `- Desktop: ${navigation.desktop}`, `- ${navigation.dialogs}`, "",
    "### Main journey", journey.join(" → ") + ".", "",
    "### Each screen's states", "| Screen | Empty | Loading | Error |", "|---|---|---|---|",
    ...screens.map((s) => `| ${s.name} | ${s.states.empty} | ${s.states.loading} | ${s.states.error} |`),
  ].join("\n");
  return { product: a.product, screens: screens.map((s) => ({ ...s, partNames: s.parts.map(nameOf) })), navigation, journey, warnings, markdown };
}

const SITE = "https://lkb00.github.io/tattva";
const FONTS = `<link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400..700&family=Geist+Mono:wght@400..600&display=swap" rel="stylesheet" />`;

const setupSteps = (a) => {
  const steps = [];
  const stack = a.stack;
  if (stack === "no-code") {
    steps.push("Paste the prompt into your AI builder. It carries your choices and the rules, so you do not need to explain the design system.");
    steps.push(`If the builder cannot install packages, give it the one-file source of every free part: ${SITE}/downloads/tattva-free-source.md, and ask it to copy the parts it needs into the project. If the tool shortens long pages, give it the index of small pieces instead: ${SITE}/downloads/source/index.md.`);
    steps.push(`Add the colours: ${SITE}/downloads/tokens.css goes in the project's global stylesheet.${a.theme && a.theme !== "lime" ? ` Then set data-palette="${a.theme}" on the html element.` : ""}`);
    return steps;
  }
  if (stack === "new-vite") steps.push("Create the app: `npm create vite@latest my-app -- --template react-ts`, then add Tailwind CSS v4: `npm install tailwindcss @tailwindcss/vite` and add the plugin to vite.config.");
  else if (stack === "new-next") steps.push("Create the app: `npx create-next-app@latest` (TypeScript and Tailwind CSS v4 on), then keep the Tattva files under `src/`.");
  else steps.push("Check the app uses React 18+ and Tailwind CSS v4. Tattva's tokens are written for v4.");
  if (a.plan === "free") steps.push(`Install the parts and the tokens from npm: \`npm install @tattva/ui\`. Create \`src/tattva.css\` holding \`@import "@tattva/ui/tokens.css";\` and \`@source "../node_modules/@tattva/ui/dist";\` (the tokens load Tailwind, so this replaces your own \`@import "tailwindcss";\`; the @source line lets Tailwind see the classes the parts use) and import it once at the top of the app entry (\`import "./tattva.css";\`).`);
  else steps.push(`Add the tokens: download ${SITE}/downloads/tokens.css, save it as \`src/tokens/tokens.css\` and import it once at the top of the app entry (\`import "./tokens/tokens.css";\`).`);
  steps.push(`Load the fonts (Inter and Geist Mono) by adding this to the page head: ${FONTS}`);
  if (a.theme && a.theme !== "lime") steps.push(`Set the colour theme on the root element: \`<html data-palette="${a.theme}">\`.`);
  if (a.mode === "dark") steps.push('Dark only: add `class="dark"` to the `<html>` element.');
  else if (a.mode === "both") steps.push('Light and dark: toggle `class="dark"` on `<html>`, starting from `matchMedia("(prefers-color-scheme: dark)")` so it follows the device.');
  if (a.plan === "free") steps.push("Import every part from the package only (`import { Message } from \"@tattva/ui\"`), never from a deep path.");
  else steps.push("Install all the parts from the Pro zip: the person got `tattva-pro.zip` when they bought Pro or Team (check their email or the store's download page). Ask them for its path; do not look for it online. Unzip it so that its `tattva` folder lands in `src/` and its `tokens.css` replaces `src/tokens/tokens.css`. Import from that folder only (`import { ApprovalPrompt } from \"./tattva\"`, adjusting the relative path).");
  return steps;
};

/** Files an agent can write as they are, so setup does not depend on it remembering the steps. */
const setupFiles = (a, brief) => {
  const files = [{ path: "tattva.md", why: "The project brief. Read it first in every session.", content: brief + "\n" }];
  if (a.stack === "new-vite") {
    const dark = a.mode === "dark" ? ' class="dark"' : "";
    const palette = a.theme && a.theme !== "lime" ? ` data-palette="${a.theme}"` : "";
    const script = a.mode === "both" ? `
    <script>
      (function () {
        if (matchMedia("(prefers-color-scheme: dark)").matches) document.documentElement.classList.add("dark");
      })();
    </script>` : "";
    files.push(
      { path: "vite.config.ts", why: "React and Tailwind CSS v4.", content: `import { defineConfig } from "vite";\nimport react from "@vitejs/plugin-react";\nimport tailwindcss from "@tailwindcss/vite";\n\nexport default defineConfig({ plugins: [react(), tailwindcss()] });\n` },
      { path: "index.html", why: `Fonts, ${a.theme === "lime" ? "the default theme" : `the ${a.theme} theme`}${a.mode === "both" ? " and light/dark that follows the device" : a.mode === "dark" ? " and dark mode" : ""}.`, content: `<!doctype html>\n<html lang="en"${dark}${palette}>\n  <head>\n    <meta charset="UTF-8" />\n    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n    <title>My app</title>\n    <link rel="preconnect" href="https://fonts.googleapis.com" />\n    ${FONTS}${script}\n  </head>\n  <body>\n    <div id="root"></div>\n    <script type="module" src="/src/main.tsx"></script>\n  </body>\n</html>\n` },
      { path: "src/main.tsx", why: "Loads the tokens and renders App. You write src/App.tsx.", content: `import { StrictMode } from "react";\nimport { createRoot } from "react-dom/client";\nimport "${a.plan === "free" ? "./tattva.css" : "./tokens/tokens.css"}";\nimport { App } from "./App";\n\ncreateRoot(document.getElementById("root")!).render(<StrictMode><App /></StrictMode>);\n` },
    );
    if (a.plan === "free") files.push({ path: "src/tattva.css", why: "The Tattva tokens (they load Tailwind) and the package's classes.", content: `@import "@tattva/ui/tokens.css";\n@source "../node_modules/@tattva/ui/dist";\n` });
  }
  return files;
};

const setupCommands = (a) => a.stack === "no-code" ? [] : [
  ...(a.stack === "new-vite" ? ["npm create vite@latest my-app -- --template react-ts", "cd my-app && npm install && npm install tailwindcss @tailwindcss/vite"] : []),
  ...(a.plan === "free" ? ["npm install @tattva/ui"] : [`mkdir -p src/tokens && curl -fsSL ${SITE}/downloads/tokens.css -o src/tokens/tokens.css`, "unzip -oq <path to tattva-pro.zip> 'tattva/*' -d src && unzip -oqj <path to tattva-pro.zip> tokens.css -d src/tokens"]),
  ...(a.stack === "new-vite" ? ["rm -f src/index.css src/App.css"] : []),
];

/** Builds the plan for an agent: setup, parts in order (with Pro marks), patterns to read and a brief to save. */
export function planBuild(rawAnswers, components) {
  const byId = new Map(components.map((c) => [c.id, c]));
  const a = { product: "chat-assistant", stack: "new-vite", theme: "lime", mode: "both", trust: ["sources", "feedback"], plan: "free", ...Object.fromEntries(Object.entries(rawAnswers ?? {}).filter(([, v]) => v !== undefined && v !== null && v !== "")) };
  if (typeof a.trust === "string") a.trust = a.trust.split(/[,\s]+/).filter(Boolean);
  const recipe = RECIPES[a.product];
  if (!recipe) return { error: `Unknown product "${a.product}". Use one of: ${Object.keys(RECIPES).join(", ")}.` };
  const warnings = [];
  const themes = ["lime", "teal", "indigo", "harbor", "plum", "graphite", "terminal"];
  if (!themes.includes(a.theme)) { warnings.push(`Unknown theme "${a.theme}"; using lime. Themes: ${themes.join(", ")}.`); a.theme = "lime"; }
  const unknownTrust = a.trust.filter((t) => !TRUST[t]);
  if (unknownTrust.length) warnings.push(`Ignored unknown trust behaviours: ${unknownTrust.join(", ")}. Known: ${Object.keys(TRUST).join(", ")}.`);
  const seen = new Set();
  const parts = [];
  const add = (list, group) => {
    for (let [id, why] of list) {
      if (seen.has(id)) continue; seen.add(id);
      let c = byId.get(id);
      if (!c) { warnings.push(`The part "${id}" was not found in this copy of Tattva, so it is left out.`); continue; }
      const stage = c.lifecycle?.stage ?? c.status ?? "stable";
      if ((stage === "deprecated" || stage === "retired") && c.lifecycle?.replacedBy && byId.get(c.lifecycle.replacedBy)) {
        warnings.push(`${c.name} is ${stage}; using ${byId.get(c.lifecycle.replacedBy).name} instead.`);
        c = byId.get(c.lifecycle.replacedBy); id = c.id;
        if (seen.has(id)) continue; seen.add(id);
      }
      parts.push({ id, name: c.name, group, why, plan: c.plan ?? "free", stage: c.lifecycle?.stage ?? c.status ?? "stable", importLine: c.importPath });
    }
  };
  add([[recipe.screen, `The page layout (${recipe.title}).`]], "Screen");
  add(recipe.core, recipe.title);
  for (const t of a.trust.filter((x) => TRUST[x])) add(TRUST[t], `Trust: ${t}`);
  // The idea in the person's words. When answers recommend things to choose between (hotels, products, flights), the
  // reply needs result cards, not only text.
  const idea = String(a.idea ?? "");
  if (/\b(hotels?|flights?|products?|shops?|shopping|stores?|restaurants?|places?|homes?|apartments?|rooms?|cars?|jobs?|courses?|recipes?|events?|tickets?|listings?|plans?|options|recommend\w*|compare|choose|booking|travel|trips?)\b/i.test(idea))
    add([["result-card", "One thing the answer recommends, such as a hotel: picture, name, facts, price and one action."], ["card-row", "Several results side by side; a swipe row on a phone."], ["fact-list", "Short facts such as Check-in: 3pm, inside a result or on its own."]], "Results in the answer");
  const pro = parts.filter((p) => p.plan === "pro");
  if (a.plan === "free" && pro.length) warnings.push(`${pro.length} of ${parts.length} parts are Pro (${pro.slice(0, 6).map((p) => p.name).join(", ")}${pro.length > 6 ? ", ..." : ""}). Their previews and guidance are free, but their code comes with Pro or Team: ${SITE}/#pricing. Tell the person before relying on them, and offer the free parts first.`);
  // The site map the person approved (passed back as Markdown), or the proposed one.
  const sitemap = typeof a.sitemap === "string" && a.sitemap.trim() ? a.sitemap.trim() : planSitemap(a, components).markdown ?? "";
  const brief = [
    "# Tattva project brief", "",
    "Saved by the Tattva MCP server. Read this first in every session so the product stays consistent.", "",
    `- Product: ${recipe.title}`, ...(idea ? [`- Idea: ${idea}`] : []), `- Stack: ${a.stack}`, `- Theme: ${a.theme}${a.theme === "lime" ? " (default)" : ` (data-palette="${a.theme}")`}`, `- Mode: ${a.mode}`,
    `- Trust behaviours: ${a.trust.join(", ") || "none"}`, "",
    "## Parts", ...parts.map((p) => `- ${p.name}${p.plan === "pro" ? " (Pro)" : ""}: ${p.why}`), "",
    "## Rules", "- Import from the package index only.", "- Use tokens (`var(--surface)`), never hex values.", "- The AI colour (`--lime`) is a fill, never text. Amber means a person has to act.",
    "- Every control has an accessible name. Status is never colour alone.", "- Run `review_code` on each file before finishing.",
    ...(sitemap ? ["", sitemap] : []),
  ].join("\n");
  return { answers: a, recipe: { product: a.product, title: recipe.title, screen: recipe.screen }, setup: setupSteps(a), commands: setupCommands(a), files: setupFiles(a, brief), parts, patterns: recipe.patterns, warnings, brief };
}

/**
 * The one prompt a person pastes into an AI tool, from a plan. Written to the AI, not to the person.
 * The Build brief page and the tests use this same function.
 */
export function buildPrompt(plan) {
  const a = plan.answers;
  const noCode = a.stack === "no-code";
  const pro = plan.parts.filter((p) => p.plan === "pro");
  const setup = noCode
    ? [
        `If you can install packages, run npm install @tattva/ui, put @import "@tattva/ui/tokens.css"; and @source "../node_modules/@tattva/ui/dist"; at the top of the main stylesheet (they replace @import "tailwindcss";), and import every part from "@tattva/ui". If you cannot install packages, read ${SITE}/downloads/tattva-free-source.md, which holds the source of every free part in one file (if you only get a summary of it, read the small pieces listed in ${SITE}/downloads/source/index.md instead, one by one), recreate the parts you need under src/tattva/ with the same file names, and import from there.`,
        `If you used the source file, add the colours from ${SITE}/downloads/tokens.css to the project's global stylesheet.${a.theme && a.theme !== "lime" ? ` Set data-palette="${a.theme}" on the html element.` : ""}${a.mode === "both" ? " Toggle the dark class on the html element to follow the device's colour scheme." : a.mode === "dark" ? " Add the dark class to the html element." : ""}`,
      ]
    : plan.setup;
  return [
    `I want to build: ${plan.recipe.title}${a.idea ? `, for this idea: ${a.idea}` : ""}.`,
    "",
    PLAIN_WORDS,
    "",
    `Use the Tattva design system. Read its guide first: ${SITE}/llms.txt (it links to a page for every part). Theme: ${a.theme}. Mode: ${a.mode === "both" ? "light and dark, following the device" : a.mode}.`,
    "",
    "Setup:",
    ...setup.map((x, i) => `${i + 1}. ${x}`),
    "",
    "Use these parts, in this order:",
    ...plan.parts.map((p) => `- ${p.name}${p.plan === "pro" ? " (Pro)" : ""}: ${p.why}`),
    ...(pro.length ? ["", `Parts marked (Pro) have a free preview and guidance, but their code is not available to you. Build the screen from the free parts, and for each Pro part use a simple plain stand-in built from free parts, with a comment naming the Pro part so I can swap it in later.`] : []),
    "",
    "Rules:",
    "- Import parts and icons only from the tattva folder, never from a deep path (icons are named like SendIcon and CopyIcon). Never write hex colours; use the tokens (var(--surface), var(--fg)).",
    "- The AI colour marks AI only, and is never used as text. Amber means a person has to act.",
    "- Every button and icon has a clear name. Status is never colour alone.",
    "- If no part fits something I ask for, tell me and ask. Do not invent parts, props or colours.",
    "- Build every screen in the site map in the brief below, with its empty, loading and error states and the navigation it describes. Show me the map first if you would change it.",
    "",
    "Project brief (save it as tattva.md and read it first next time):",
    plan.brief,
  ].join("\n");
}

/** The checks run by review_code. Each has a rule name, how serious it is, a test for one line, and how to fix it. */
const CHECKS = [
  { rule: "no-hex", level: "error", test: (l) => /(?<![\w&])#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})\b/.test(l.replace(/\b(?:href|to|xlinkHref)=["']#[^"']*["']/g, "").replace(/url\(#[^)]*\)/g, "")) && !/^\s*(\/\/|\*|\/\*)/.test(l) && /(color|bg-|text-|border|fill|stroke|background|style|className|#[0-9a-fA-F]{6}\b)/.test(l), fix: "Use a token: `var(--surface)`, `var(--fg)` or a class such as `bg-surface` and `text-fg-muted`. Ask get_tokens for the right name." },
  { rule: "no-color-function", level: "error", test: (l) => /\b(rgb|rgba|hsl|hsla|oklch)\(/.test(l) && !/var\(|--/.test(l) && !/^\s*(\/\/|\*)/.test(l), fix: "Use a token instead of a raw colour function." },
  { rule: "no-default-palette", level: "error", test: (l) => /\b(?:bg|text|border|ring|fill|stroke|from|to|via)-(?:red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|slate|gray|zinc|neutral|stone)-\d{2,3}\b/.test(l), fix: "Tailwind's default palette is not part of Tattva. Use classes built from tokens, such as `bg-surface`, `text-fg`, `border-line`, `bg-lime-soft`." },
  { rule: "no-deep-import", level: "error", test: (l) => /from\s+["'][^"']*\/(?:atoms|molecules|organisms|templates|pages)\/[^"']*["']/.test(l) || /from\s+["']@tattva\/ui\/(?!tokens\.css["']|scenes\/)[^"']+["']/.test(l), fix: "Import from the package itself: `import { ApprovalPrompt } from \"@tattva/ui\"` (or the tattva folder's index if you copied the source), never from a file inside it." },
  { rule: "no-raw-size", level: "warn", test: (l) => /\b[a-z]+(?:-[a-z]+)*-\[-?\d+(?:\.\d+)?px\]/.test(l) && !/^\s*(\/\/|\*)/.test(l), fix: "Use the spacing scale (`p-3`, `gap-4`) or a token, not a typed pixel size, so sizes stay in step with the system." },
  { rule: "no-div-click", level: "error", test: (l) => /<(?:div|span)\b[^>]*\bonClick=/.test(l) && !/role=["']button["']/.test(l), fix: "Use a real `<button>` (or Tattva's Button). A clickable div cannot be reached with the keyboard." },
  { rule: "lime-as-text", level: "error", test: (l) => /\btext-lime\b|color:\s*var\(--lime\)/.test(l), fix: "The AI colour is a fill, never text colour. Put dark text on it (`text-on-lime`)." },
  { rule: "focus-removed", level: "warn", test: (l) => /\b(?:focus:)?outline-none\b|outline:\s*none/.test(l) && !/focus-visible|ring/.test(l), fix: "Do not remove the focus outline. Tattva already draws one; keep it, or replace it with a visible ring." },
  { rule: "vague-destructive", level: "warn", test: (l) => />\s*(?:Delete|Remove|Discard|Reset)\s*</.test(l), fix: "Say the effect: \"Delete project Atlas\", not \"Delete\"." },
  { rule: "raw-html", level: "warn", test: (l) => /dangerouslySetInnerHTML/.test(l), fix: "Avoid raw HTML from the AI. Use Markdown, or put untrusted content in SandboxedFrame." },
  { rule: "amber-check", level: "info", test: (l) => /\b(?:text|bg|border)-attention\b|var\(--attention/.test(l), fix: "Amber means a person has to act. Use it only for a \"needs you\" state, not for warnings or decoration." },
  { rule: "colour-only-status", level: "info", test: (l) => /\b(?:text|bg)-(?:success|danger)\b/.test(l) && !/<(?:Icon|svg)|aria-label|sr-only/.test(l), fix: "Status must not rely on colour alone. Pair it with an icon and a word." },
];

/** Checks a piece of code against Tattva's rules. Returns findings with line numbers. */
export function reviewCode(code, components = [], filename = "", exportsList = []) {
  const lines = String(code).split("\n");
  const findings = [];
  lines.forEach((line, i) => {
    for (const c of CHECKS) if (c.test(line)) findings.push({ line: i + 1, rule: c.rule, level: c.level, text: line.trim().slice(0, 140), fix: c.fix });
  });
  // Tag checks: read the whole opening tag, so props on several lines are seen.
  const src = String(code);
  // Quotes are skipped, so a ">" inside a prop value ("Account > Payment") does not end the tag.
  const tagOf = (from) => { let depth = 0, quote = ""; for (let k = from; k < src.length; k++) { const ch = src[k]; if (quote) { if (ch === quote) quote = ""; continue; } if ((ch === '"' || ch === "'") && depth === 0) quote = ch; else if (ch === "{") depth++; else if (ch === "}") depth--; else if (ch === ">" && depth === 0) return src.slice(from, k + 1); } return src.slice(from, from + 400); };
  for (const [re, attr, rule, fix] of [
    [/<IconButton\b/g, /\blabel=/, "icon-button-label", "Every IconButton needs a `label` that names what it does, such as `label=\"Copy reply\"`."],
    [/<img\b/g, /\balt=/, "img-alt", "Give every image an `alt`, or `alt=\"\"` if it is decoration."],
  ]) for (const m of src.matchAll(re)) { const tag = tagOf(m.index); if (!attr.test(tag) && !/\{\.\.\.\w+\}/.test(tag)) findings.push({ line: src.slice(0, m.index).split("\n").length, rule, level: "error", text: tag.split("\n")[0].trim().slice(0, 140), fix }); }
  // A plain <button> with only an icon inside and no name: screen readers say just "button".
  for (const m of src.matchAll(/<button\b/g)) {
    const tag = tagOf(m.index);
    if (/aria-label(?:ledby)?=|\btitle=|\{\.\.\.\w+\}/.test(tag) || tag.endsWith("/>")) continue;
    const end = src.indexOf("</button>", m.index + tag.length);
    if (end < 0) continue;
    const inner = src.slice(m.index + tag.length, end).replace(/\{[^{}]*<[^{}]*\}/g, "").replace(/<[^>]*>/g, "").replace(/\{[^}]*\}/g, (x) => (/</.test(x) ? "" : "text")).trim();
    if (!inner) findings.push({ line: src.slice(0, m.index).split("\n").length, rule: "icon-button-label", level: "error", text: tag.split("\n")[0].trim().slice(0, 140), fix: "This button has only an icon and no name. Use Tattva's IconButton with a `label`, or add `aria-label=\"Delete booking\"`." });
  }
  // Props on Tattva parts: unknown names, missing required ones, and values outside a fixed set.
  const byName = new Map(components.map((c) => [c.name, c]));
  const SKIP = /^(?:key|ref|className|style|id|children|role|tabIndex|title|hidden|aria-[\w-]+|data-[\w-]+)$/;
  // A tag, not a type argument: Record<Field, string> and useState<Field>() follow a name, a JSX tag never does.
  const isTs = /\.(?:ts|mts|cts)$/.test(filename);
  for (const m of isTs ? [] : src.matchAll(/(?<![\w$.\])])<([A-Z][A-Za-z0-9]*)\b/g)) {
    const c = byName.get(m[1]); if (!c?.props?.length) continue;
    const tag = tagOf(m.index), line = src.slice(0, m.index).split("\n").length;
    // A spread can carry any prop, and a bare "..." is shorthand for "and the other props".
    if (/\{\s*\.\.\./.test(tag) || /\s(?:\.\.\.|…)(?=[\s/>])/.test(tag)) continue;
    const attrs = new Map();
    const inner = tag.slice(m[0].length);
    for (let k = 0; k < inner.length;) {
      const rest = inner.slice(k);
      // Comments between props: // to the end of the line, or /* ... */.
      const cm = /^\s*(?:\/\/[^\n]*|\/\*[\s\S]*?\*\/)/.exec(rest);
      if (cm) { k += cm[0].length; continue; }
      const am = /^\s*([A-Za-z_][\w-]*)(\s*=\s*)?/.exec(rest);
      if (!am || !am[1]) { k++; continue; }
      k += am[0].length;
      let value = true;
      if (am[2]) {
        const q = inner[k];
        if (q === '"' || q === "'") { const e = inner.indexOf(q, k + 1); if (e < 0) break; value = inner.slice(k + 1, e); k = e + 1; }
        else if (q === "{") { let d = 0, e = k; for (; e < inner.length; e++) { if (inner[e] === "{") d++; else if (inner[e] === "}" && --d === 0) break; } if (e >= inner.length) break; const expr = inner.slice(k + 1, e).trim(); const lit = /^(["'`])([^"'`]*)\1$/.exec(expr); value = lit ? lit[2] : null; k = e + 1; }
      }
      attrs.set(am[1], value);
    }
    const known = new Map(c.props.filter((p) => /^[A-Za-z_]\w*$/.test(p.name)).map((p) => [p.name, p]));
    const acceptsAny = c.props.some((p) => p.name.startsWith("..."));
    const hasChildren = !tag.endsWith("/>");
    for (const [name, value] of attrs) {
      const p = known.get(name);
      // Standard attributes (title, id, aria-*) are skipped unless the part defines them as its own props.
      if (!p && (SKIP.test(name) || /^on[A-Z]/.test(name) && !known.size)) continue;
      if (!p) { if (!/^on[A-Z]/.test(name) && !acceptsAny) findings.push({ line, rule: "unknown-prop", level: "warn", text: `<${c.name} ${name}>`, fix: `${c.name} has no prop "${name}". Its props: ${[...known.keys()].join(", ")}. Call get_component for details.` }); continue; }
      const allowed = c.variantsHint?.[name];
      if (allowed && typeof value === "string" && !allowed.map(String).includes(value)) findings.push({ line, rule: "bad-prop-value", level: "error", text: `<${c.name} ${name}="${value}">`, fix: `${name} takes one of: ${allowed.join(", ")}.` });
      if (typeof value === "string" && /^(?:\.{2,}|…|todo|tbd|lorem\b.*|placeholder|xxx+)$/i.test(value.trim())) findings.push({ line, rule: "placeholder-text", level: "warn", text: `<${c.name} ${name}="${value}">`, fix: `Write the real words for ${name}. ${c.name} shows them to people, and its docs ask for real values, not placeholders.` });
    }
    for (const p of known.values()) if (p.required && !attrs.has(p.name) && !(p.name === "children" && hasChildren)) findings.push({ line, rule: "missing-prop", level: "error", text: `<${c.name}>`, fix: `${c.name} needs \`${p.name}\` (${p.type}). ${p.description}` });
  }
  // Copy: an exclamation mark in visible text reads as shouting in an interface.
  for (const m of src.matchAll(/>([^<>{}]*[A-Za-z][^<>{}]*!)\s*</g)) if (!/!=/.test(m[1])) findings.push({ line: src.slice(0, m.index).split("\n").length, rule: "exclamation", level: "info", text: m[1].trim().slice(0, 80), fix: "Say it calmly, without an exclamation mark: \"Book now\" rather than \"Book now!\"." });
  // Parts that are on their way out.
  for (const c of components) {
    const l = c.lifecycle; if (!l || (l.stage !== "deprecated" && l.stage !== "retired")) continue;
    const re = new RegExp(`<${c.name}\\b`, "g");
    for (const m of src.matchAll(re)) findings.push({ line: src.slice(0, m.index).split("\n").length, rule: `${l.stage}-part`, level: l.stage === "retired" ? "error" : "warn", text: `<${c.name}>`, fix: `${c.name} is ${l.stage}${l.removeIn ? ` (removed in ${l.removeIn})` : ""}. ${l.note ?? ""} Use ${components.find((x) => x.id === l.replacedBy)?.name ?? l.replacedBy} instead.` });
  }
  // Names imported from the package index must exist.
  const names = new Set([...components.map((c) => c.name), ...exportsList]);
  const ids = components.map((c) => c.id);
  for (const m of String(code).matchAll(/import\s*\{([^}]+)\}\s*from\s*["']([^"']+)["']/g)) {
    if (!/(^|\/)(index|tattva)$/.test(m[2]) && !/tattva/.test(m[2])) continue;
    const at = String(code).slice(0, m.index).split("\n").length;
    for (const raw of m[1].split(",")) {
      const n = raw.trim().split(/\s+as\s+/)[0];
      if (!n || names.has(n) || !/^[A-Z]/.test(n)) continue;
      if (!exportsList.length && /Icon$/.test(n)) continue; // no export list: trust icon names rather than flag them
      const near = ids.map((id) => ({ id, d: lev(n.toLowerCase(), id.replace(/-/g, "")) })).sort((x, y) => x.d - y.d)[0];
      findings.push({ line: at, rule: "unknown-part", level: "error", text: raw.trim(), fix: `"${n}" is not a Tattva part.${near && near.d <= 6 ? ` Did you mean "${components.find((c) => c.id === near.id).name}"?` : ""} Call search_components to find the right one.` });
    }
  }
  findings.sort((x, y) => x.line - y.line);
  const order = { error: 0, warn: 1, info: 2 };
  return { filename, findings, counts: { error: findings.filter((f) => f.level === "error").length, warn: findings.filter((f) => f.level === "warn").length, info: findings.filter((f) => f.level === "info").length }, order };
}

function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
